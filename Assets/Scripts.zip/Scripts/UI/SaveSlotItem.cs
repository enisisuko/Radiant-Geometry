using UnityEngine;

namespace FadedDreams.UI
{
    /// <summary>
    /// Placeholder for multi-slot save support (extend as needed).
    /// </summary>
    public class SaveSlotItem : MonoBehaviour { }
}
