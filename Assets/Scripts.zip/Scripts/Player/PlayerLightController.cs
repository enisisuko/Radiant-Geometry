using UnityEngine;
using UnityEngine.Events;
#if UNITY_RENDERING_UNIVERSAL
using UnityEngine.Rendering.Universal; // Light2D
#endif
using FadedDreams.Core;
using FadedDreams.World;

namespace FadedDreams.Player
{
    /// <summary>
    /// 第一章用：
    /// - 左键长按蓄能（≤3s，每秒10能量）。必须蓄满3秒才可释放，否则松开取消；
    /// - 蓄满后：自动停止“蓄力特效”，切换为“蓄满完成特效”；
    /// - 松开（且已蓄满）：0.25s 内强度×2、半径=15，随后3s 回落；
    /// - 能量：上限100；暗处每秒-7；在光下缓慢恢复（非瞬满）。
    /// - 蓄力/蓄满/释放分别播放对应特效。
    /// </summary>
    public class PlayerLightController : MonoBehaviour
    {
        [Header("Energy")]
        public float maxEnergy = 100f;
        public float currentEnergy = 100f;
        [Tooltip("暗处每秒流失")]
        public float drainPerSecondInDark = 7f;
        [Tooltip("在光照内每秒恢复（缓慢回满）")]
        public float regenPerSecondNearLight = 20f;

        [Header("Light Sensing")]
        [Tooltip("认为“被光照到”的半径")]
        public float nearLightRadius = 2.5f;
        [Tooltip("只检测这些层的碰撞体以判断是否在光下（避免命中自己/地形）")]
        public LayerMask detectLightsMask = ~0;
        [Tooltip("认为“有光”的最小Light2D强度阈值")]
        public float minSenseIntensity = 0.15f;

        [Header("Charge & Burst")]
        [Tooltip("蓄能每秒消耗")]
        public float chargeCostPerSecond = 10f;
        [Tooltip("最多可蓄的秒数（必须蓄满方可释放）")]
        public float maxChargeSeconds = 3f;
        [Tooltip("释放瞬间爆发持续时长")]
        public float burstDuration = 0.25f;
        [Tooltip("爆发后回落到正常的时长")]
        public float decayDuration = 3f;
        [Tooltip("爆发时强度倍率")]
        public float burstIntensityMultiplier = 2f;
        [Tooltip("爆发期内半径提升到该值")]
        public float burstRadius = 15f;

        [Header("Baseline Light Mapping")]
        [Tooltip("能量=100% 时的基础强度")]
        public float baseIntensityAtFullEnergy = 1.2f;
        [Tooltip("能量=0% 时的基础强度")]
        public float baseIntensityAtZero = 0.1f;
        [Tooltip("能量=100% 时基础半径")]
        public float baseRadiusAtFullEnergy = 8f;
        [Tooltip("能量=0% 时基础半径")]
        public float baseRadiusAtZero = 2.5f;
        [Tooltip("蓄能中的额外强度加成（线性叠加：charge01 * extraIntensityWhileCharging）")]
        public float extraIntensityWhileCharging = 0.6f;

        [Header("Color States")]
        public bool hasRed, hasGreen, hasBlue;
        public enum LightMode { None, Red, Green, Blue, White }
        public LightMode mode = LightMode.None;

        [Header("Events")]
        public UnityEvent onDeath;
        public UnityEvent onEnergyChanged;
        public UnityEvent onModeChanged;

        // ✅ 新增：进入“大光圈爆发窗口”时派发（供敌人/特效订阅）
        public UnityEvent onBurstStart;

        // ✅ 新增：公开只读属性，表示是否处于“大光圈爆发窗口”
        public bool IsInBurstWindow => _inBurst && _burstT <= burstDuration;

        [Header("VFX")]
        public Transform vfxAnchor;            // 建议拖到玩家身上的空物体
        public GameObject chargeVfxPrefab;     // 蓄力特效预制体（按住开始播放）
        public GameObject releaseVfxPrefab;    // 释放特效预制体（成功释放时播放）
        public float releaseVfxAutoKill = 3f;  // 无自毁组件时的兜底销毁时间

        public GameObject chargedVfxPrefab;    // ✅ 蓄满完成特效（达到 maxChargeSeconds 时切换）
        public float chargedVfxAutoKill = 0f;  // 0 表示不自动销毁（循环类指示灯可常驻，松开或爆发会清理）

#if UNITY_RENDERING_UNIVERSAL
        public Light2D playerLight2D; // 直接拖引用（推荐）
#endif
        [Tooltip("若未启用URP，可拖有 intensity/pointLightOuterRadius 的组件")]
        public Component light2DAny;

        // —— 内部状态 ——
        float _chargeTimer = 0f;
        bool _isCharging = false;
        bool _inBurst = false;
        float _burstT = 0f;
        float _decayT = 0f;

        float _baselineIntensity = 1f;
        float _baselineRadius = 5f;

        GameObject _chargeVfxInst;
        GameObject _chargedVfxInst;   // ✅ 蓄满完成特效实例
        bool _chargedReady = false;   // ✅ 是否已达到蓄满并切为完成态

        public float Energy => Mathf.Clamp01(maxEnergy > 0 ? currentEnergy / maxEnergy : 0f);

        private void Start()
        {
            UpdateMode(LightMode.None);
            PushLightByEnergy(0f);
            CacheBaselineFromCurrent();
        }

        private void Update()
        {
            HandleEnergy();         // 缓慢回能/黑暗掉能
            HandleChargeAndBurst(); // 蓄力/释放与特效
            TickLightVisuals();     // 强度/半径随状态更新
        }

        void HandleEnergy()
        {
            bool lit = IsNearAnyLight();
            if (lit)
                currentEnergy += regenPerSecondNearLight * Time.deltaTime;  // 缓慢回能
            else
                currentEnergy -= drainPerSecondInDark * Time.deltaTime;     // 暗处掉能

            currentEnergy = Mathf.Clamp(currentEnergy, 0, maxEnergy);
            onEnergyChanged?.Invoke();

            if (currentEnergy <= 0f)
            {
                onDeath?.Invoke();
                GameManager.Instance.OnPlayerDeath();
            }
        }

        bool IsNearAnyLight()
        {
            var cols = Physics2D.OverlapCircleAll(transform.position, nearLightRadius, detectLightsMask);
            for (int i = 0; i < cols.Length; i++)
            {
                var c = cols[i];
                if (!c) continue;

                // 忽略自己
                if (c.transform == transform) continue;
                if (c.attachedRigidbody && c.attachedRigidbody.transform == transform) continue;
                if (c.CompareTag("Player")) continue;

                // 自定义 LightSource2D：需“正在提供光”
                var ls = c.GetComponent<LightSource2D>();
                if (ls != null && ls.ProvidesLight(minSenseIntensity)) return true;

#if UNITY_RENDERING_UNIVERSAL
                // 裸 Light2D：强度过阈值
                var l2d = c.GetComponent<Light2D>();
                if (l2d != null && l2d.intensity >= minSenseIntensity) return true;
#endif
            }
            return false;
        }

        void HandleChargeAndBurst()
        {
            if (!_inBurst)
            {
                if (Input.GetMouseButton(0))
                {
                    if (!_isCharging)
                    {
                        _isCharging = true;
                        _chargedReady = false; // 进入蓄力重置“蓄满”标记
                        if (chargeVfxPrefab && _chargeVfxInst == null)
                            _chargeVfxInst = Instantiate(chargeVfxPrefab,
                                vfxAnchor ? vfxAnchor.position : transform.position,
                                Quaternion.identity,
                                vfxAnchor ? vfxAnchor : transform);
                    }

                    if (currentEnergy > 0f)
                    {
                        float cost = chargeCostPerSecond * Time.deltaTime;
                        float canSpend = Mathf.Min(currentEnergy, cost);
                        currentEnergy -= canSpend;
                        _chargeTimer = Mathf.Min(_chargeTimer + Time.deltaTime, maxChargeSeconds);
                        onEnergyChanged?.Invoke();

                        // ✅ 达到蓄满阈值：停止“蓄力特效”，切换“蓄满完成特效”
                        if (!_chargedReady && _chargeTimer >= maxChargeSeconds)
                        {
                            _chargedReady = true;

                            if (_chargeVfxInst) { Destroy(_chargeVfxInst); _chargeVfxInst = null; }

                            if (chargedVfxPrefab && _chargedVfxInst == null)
                            {
                                _chargedVfxInst = Instantiate(chargedVfxPrefab,
                                    vfxAnchor ? vfxAnchor.position : transform.position,
                                    Quaternion.identity,
                                    vfxAnchor ? vfxAnchor : transform);
                                if (chargedVfxAutoKill > 0f) Destroy(_chargedVfxInst, chargedVfxAutoKill);
                            }
                        }
                    }
                    else
                    {
                        // 没能量，中断蓄力并清理两种特效
                        _isCharging = false;
                        _chargedReady = false;
                        _chargeTimer = 0f;
                        if (_chargeVfxInst) { Destroy(_chargeVfxInst); _chargeVfxInst = null; }
                        if (_chargedVfxInst) { Destroy(_chargedVfxInst); _chargedVfxInst = null; }
                    }
                }
                else if (_isCharging)
                {
                    // 松开
                    _isCharging = false;

                    // 清理两种蓄力类特效
                    if (_chargeVfxInst) { Destroy(_chargeVfxInst); _chargeVfxInst = null; }
                    if (_chargedVfxInst) { Destroy(_chargedVfxInst); _chargedVfxInst = null; }

                    if (_chargeTimer >= maxChargeSeconds) // ✅ 必须蓄满才触发释放
                    {
                        StartBurst();

                        if (releaseVfxPrefab)
                        {
                            var rel = Instantiate(releaseVfxPrefab,
                                vfxAnchor ? vfxAnchor.position : transform.position,
                                Quaternion.identity,
                                vfxAnchor ? vfxAnchor : transform);
                            if (releaseVfxAutoKill > 0f) Destroy(rel, releaseVfxAutoKill);
                        }
                    }
                    else
                    {
                        // ❌ 没蓄满，直接取消（不播放释放特效）
                    }

                    _chargedReady = false;
                    _chargeTimer = 0f; // 松开后清空计时
                }
            }

            if (_inBurst)
            {
                _burstT += Time.deltaTime;
                if (_burstT <= burstDuration)
                {
                    // 爆发窗口内点亮范围内不常亮光源（LightUp）
                    LightUpAllInRadius(CurrentEffectiveRadius());
                }
                else
                {
                    _decayT += Time.deltaTime;
                    if (_decayT >= decayDuration)
                    {
                        _inBurst = false;
                        _burstT = 0f;
                        _decayT = 0f;
                        _chargeTimer = 0f;
                        CacheBaselineFromCurrent();
                    }
                }
            }
        }

        void StartBurst()
        {
            // 保险：进入爆发时清理蓄力/蓄满特效
            if (_chargeVfxInst) { Destroy(_chargeVfxInst); _chargeVfxInst = null; }
            if (_chargedVfxInst) { Destroy(_chargedVfxInst); _chargedVfxInst = null; }
            _chargedReady = false;

            _inBurst = true;
            _burstT = 0f;
            _decayT = 0f;
            CacheBaselineFromCurrent();

            // ✅ 新增：通知“进入大光圈爆发窗口”
            onBurstStart?.Invoke();
        }

        void LightUpAllInRadius(float radius)
        {
            var cols = Physics2D.OverlapCircleAll(transform.position, radius, detectLightsMask);
            for (int i = 0; i < cols.Length; i++)
            {
                var ls = cols[i].GetComponent<LightSource2D>();
                if (ls != null) ls.LightUp();
            }
        }

        void CacheBaselineFromCurrent()
        {
            float e01 = Energy;
            _baselineIntensity = Mathf.Lerp(baseIntensityAtZero, baseIntensityAtFullEnergy, e01);
            _baselineRadius = Mathf.Lerp(baseRadiusAtZero, baseRadiusAtFullEnergy, e01);
        }

        void TickLightVisuals()
        {
            float bonusWhileCharging = 0f;
            if (_isCharging)
            {
                float charge01 = Mathf.InverseLerp(0f, maxChargeSeconds, _chargeTimer);
                bonusWhileCharging = charge01 * extraIntensityWhileCharging;
            }

            // 基于能量的基础值
            PushLightByEnergy(bonusWhileCharging);

            // 爆发/回落叠加
            if (_inBurst)
            {
                float intensity, radius;
                if (_burstT <= burstDuration)
                {
                    intensity = _baselineIntensity * burstIntensityMultiplier;
                    radius = Mathf.Max(_baselineRadius, burstRadius);
                }
                else
                {
                    float k = Mathf.Clamp01(_decayT / Mathf.Max(0.0001f, decayDuration));
                    float i0 = _baselineIntensity * burstIntensityMultiplier;
                    float r0 = Mathf.Max(_baselineRadius, burstRadius);
                    intensity = Mathf.Lerp(i0, _baselineIntensity, k);
                    radius = Mathf.Lerp(r0, _baselineRadius, k);
                }
                SetLight(intensity, radius);
            }
        }

        void PushLightByEnergy(float bonus)
        {
            float e01 = Energy;
            float intensity = Mathf.Lerp(baseIntensityAtZero, baseIntensityAtFullEnergy, e01) + bonus;
            float radius = Mathf.Lerp(baseRadiusAtZero, baseRadiusAtFullEnergy, e01);
            SetLight(intensity, radius);
        }

        void SetLight(float intensity, float radius)
        {
#if UNITY_RENDERING_UNIVERSAL
            if (playerLight2D)
            {
                playerLight2D.intensity = Mathf.Max(0f, intensity);
                playerLight2D.pointLightOuterRadius = Mathf.Max(0f, radius);
            }
#endif
            if (light2DAny) TrySetViaReflection(light2DAny, "intensity", Mathf.Max(0f, intensity));
            if (light2DAny) TrySetViaReflection(light2DAny, "pointLightOuterRadius", Mathf.Max(0f, radius));
        }

        void TrySetViaReflection(Component c, string name, float v)
        {
            if (!c) return;
            var t = c.GetType();
            var p = t.GetProperty(name, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic);
            if (p != null && p.CanWrite && p.PropertyType == typeof(float)) { p.SetValue(c, v, null); return; }
            var f = t.GetField(name, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic);
            if (f != null && f.FieldType == typeof(float)) { f.SetValue(c, v); }
        }

        float CurrentEffectiveRadius()
        {
#if UNITY_RENDERING_UNIVERSAL
            if (playerLight2D) return playerLight2D.pointLightOuterRadius;
#endif
            return Mathf.Lerp(baseRadiusAtZero, baseRadiusAtFullEnergy, Energy);
        }

        // 占位：根据你项目原有实现
        void UpdateMode(LightMode m) { mode = m; onModeChanged?.Invoke(); }
    }
}
