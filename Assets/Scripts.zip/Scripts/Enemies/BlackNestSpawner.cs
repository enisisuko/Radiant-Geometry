using System.Collections;
using UnityEngine;

public class BlackNestSpawner : MonoBehaviour
{
    public BlackAI blackPrefab;          // �ϡ��ڡ�Ԥ����
    public float triggerRadius = 8f;     // �������루��ҽ���ſ�ʼˢ��
    public Vector2 spawnIntervalRange = new Vector2(4f, 10f);
    public int maxAlive = 5;             // ͬʱ����ڳ�����
    public Transform spawnPoint;         // ��ѡ��������������λ��
    public LayerMask playerMask = ~0;    // ��Ҳ�

    int aliveCount = 0;
    Transform player;
    bool running;

    void Start()
    {
        var go = GameObject.FindGameObjectWithTag("Player");
        if (go) player = go.transform;
        StartCoroutine(CoRun());
    }

    IEnumerator CoRun()
    {
        while (true)
        {
            yield return null;
            if (!player || !blackPrefab) continue;

            float dist = Vector2.Distance(transform.position, player.position);
            bool shouldRun = dist <= triggerRadius;

            if (shouldRun && !running)
            {
                running = true;
                StartCoroutine(CoSpawnLoop());
            }
            else if (!shouldRun && running)
            {
                running = false; // ֹͣˢ��
            }
        }
    }

    IEnumerator CoSpawnLoop()
    {
        while (running)
        {
            if (aliveCount < maxAlive)
            {
                var pos = spawnPoint ? spawnPoint.position : transform.position;
                var inst = Instantiate(blackPrefab, pos, Quaternion.identity);
                aliveCount++;

                // 20���BlackAI���Ի٣�����˳�����ټ���
                DestroyTracker(inst.gameObject, 20f);
            }

            float wait = Random.Range(spawnIntervalRange.x, spawnIntervalRange.y);
            yield return new WaitForSeconds(wait);
        }
    }

    async void DestroyTracker(GameObject go, float fallbackSeconds)
    {
        // ���գ��ȵ����������ټ�������֧�ֱ������Ȧ�������ɱ��
        float t = 0f;
        while (go != null && t < fallbackSeconds + 1f)
        {
            await System.Threading.Tasks.Task.Yield();
            t += Time.deltaTime;
        }
        aliveCount = Mathf.Max(0, aliveCount - 1);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.black;
        Gizmos.DrawWireSphere(transform.position, triggerRadius);
    }
}
