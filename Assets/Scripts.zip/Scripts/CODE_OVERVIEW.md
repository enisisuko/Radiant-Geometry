代码总览

以下内容按照模块（目录）对 Scripts.zip 中的所有脚本文件逐一说明，包括路径、功能、主要类和方法、参数返回值、模块依赖关系，以及近期新增特性等。结构化文档便于快速定位和理解各脚本用途。

核心模块 (Scripts/Core)

Scripts/Core/GameManager.cs

功能：全局单例管理器，维护当前游戏状态（当前章节、检查点 ID 等）。继承自泛型单例基类 Singleton<GameManager>。

主要成员：

字段 CurrentChapter (int)、CurrentCheckpointId (string)：记录当前章节和检查点。

方法 SetChapter(int chapter)：设置当前章节（将 chapter 限制在 1–4 范围内）。

方法 SetCheckpoint(string checkpointId)：设置当前检查点 ID。

方法 OnPlayerDeath()：在玩家死亡时调用，从 SaveSystem 读取最后保存的场景和检查点，然后通过 SceneLoader 重新加载场景并复活玩家。

依赖：UnityEngine、FadedDreams.Utilities.Singleton（单例基类）等。

Scripts/Core/SaveData.cs

功能：存档数据模型，标记为 [Serializable]。仅用于数据存储，不含逻辑。

主要成员：

字段 lastScene (string)：记录最近保存的场景名称。

字段 lastCheckpoint (string)：记录最近保存的检查点 ID。

字段 highestChapterUnlocked (int)：记录最高解锁的章节号。

字段 discoveredCheckpoints (HashSet<string>)：已发现的所有检查点 ID 的集合，用于“继续游戏”菜单。

Scripts/Core/SaveSystem.cs

功能：全局存档管理单例，继承自 Singleton<SaveSystem>。负责读写存档数据到硬盘（使用 JSON 格式，存储路径为 Application.persistentDataPath 下的 faded_dreams_save.json）。

主要方法（皆为公有）：

SaveLastScene(string sceneName)：保存当前场景名到 SaveData.lastScene 并调用内部 Save() 写盘。

LoadLastScene(): string：加载并返回上次保存的场景名。

SaveCheckpoint(string checkpointId)：保存当前检查点 ID 到 SaveData.lastCheckpoint 并写盘。

LoadCheckpoint(): string：加载并返回上次保存的检查点 ID。

AddDiscoveredCheckpoint(string sceneName, string checkpointId)：当玩家触发检查点时调用。将场景名存为 lastScene、检查点加入 discoveredCheckpoints，并写盘。

GetCheckpoints(): IEnumerable<string>：返回已发现的所有检查点 ID 列表（用于“继续菜单”生成列表）。

UnlockChapter(int chapter)：解锁指定章节（更新 highestChapterUnlocked）。

HighestChapterUnlocked(): int：返回最高解锁章节号。

ResetAll()：清空所有存档数据。重置 SaveData 并清空 SayingBook 中的记录（通常在新游戏时调用）。

私有方法 Save()、Load()：内部调用 JsonUtility.ToJson/FromJson 进行读写。

依赖：UnityEngine.JsonUtility（JSON 序列化）、System.IO（文件读写）、UnityEngine.PlayerPrefs（SayingBook 使用）。

备注：实现了完整的存档机制，包括场景、检查点、章节和收集进度。

Scripts/Core/SayingBook.cs

功能：静态类，实现简单的“话语收集册”功能。使用 PlayerPrefs 存储玩家已收集的对话文本（“话语”）。用于记录剧情对话或文本的收集状态。

主要成员（均为静态）：

Count (int)：已收集话语条目数量，从 PlayerPrefs 读取。

Has(string id): bool：检查指定 ID 的话语是否已收集（PlayerPrefs 中是否存在 KEY_SEEN:id）。

TryCollect(string id, string text): bool：尝试收集新话语。若未收集，则将该话语的 ID 和文本以序号方式存入 PlayerPrefs（使用 KEY_ID:n, KEY_TEXT:n 存储），并标记 KEY_SEEN:id=1，更新总数。返回是否成功收集。

GetAllSayings(): List<string>：返回所有已收集的文本列表（按照收集顺序）。

Clear()：清除所有存储的条目，将收集器重置为初始状态。

依赖：UnityEngine.PlayerPrefs，确保收集持久化。

Scripts/Core/ChapterManager.cs

功能：静态工具类，根据当前场景名称判断所属章节。

主要方法：

static int ChapterFromScene(): 获取当前活动场景名字符串，检查是否包含 “chapter1”、“chapter2” 等关键字，返回对应章节号（若不匹配则返回 1）。

无需实例化，供其他模块调用以获取章节信息。

Scripts/Core/Checkpoint.cs

功能：场景内检查点组件。附加到带有触发器的 GameObject 上，用于记录和处理玩家到达检查点时的逻辑。

主要字段：

idOverride (string)：可手动指定检查点 ID；若为空则使用 GameObject 名称。最终的检查点 ID 通过属性 Id 计算获得。

activateOnStart (bool)：若设为 true，则该检查点一开始即激活（对应起始检查点）。

主要方法：

OnTriggerEnter2D(Collider2D other): 当玩家碰撞触发器时调用。检查 other 是否为玩家，如果是则调用 SaveSystem.Instance.AddDiscoveredCheckpoint(sceneName, Id) 记录检查点，弹出提示（可选）。

SpawnPlayerHere(): 在玩家复活时由 SceneLoader 调用。查找标记为 tag="Player" 的玩家对象，将其位置移动到该检查点的位置，并调用 ReadingStateController.ResetManualCooldownOnRespawn() 重置阅读冷却等。

依赖：UnityEngine.SceneManagement（获取当前场景名）、FadedDreams.Core.SaveSystem、FadedDreams.Player.AutoReadOnLowEnergy、ReadingStateController 等。

Scripts/Core/SceneLoader.cs

功能：静态场景加载控制类。负责切换场景并处理切换前的准备（如记录复活点）。

主要方法（皆为静态）：

LoadScene(string sceneName, string checkpointId = ""): 加载指定场景并传递检查点 ID。实现过程：若给定了 checkpointId，先调用该检查点的 SpawnPlayerHere()；然后调用 SceneManager.LoadScene(sceneName) 切换场景。

ReloadAtLastCheckpoint(): 从 SaveSystem 中读取最后保存的场景名和检查点 ID（若无记录则使用当前场景），然后调用 LoadScene(scene, checkpointId)。通常在玩家死亡后调用，以加载最后一次进度。

依赖：UnityEngine.SceneManagement.SceneManager，FadedDreams.Core.SaveSystem，Checkpoint 组件。

玩家模块 (Scripts/Player)

Scripts/Player/PlayerController2D.cs

功能：2D 平台游戏玩家控制器，处理玩家移动、跳跃、冲刺（dash）、飞行（Jetpack）等核心动作。

主要内容：

控制玩家水平移动和跳跃，使用地面检测（射线或碰撞器）来判断能否跳跃。FixedUpdate() 里根据输入设置水平速度，在 Update() 中处理跳跃按键。

冲刺（Dash）系统：响应冲刺按键（例如左 Shift），调用协程 Dash(float direction) 实现短暂的大速度冲刺。冲刺过程中暂停重力，结束后恢复普通状态。

冲刺资格重置（近期新增）：玩家每次冲刺后失去资格，记录 lastDashTime。如果 1 秒内未再次获得冲刺资格，则自动恢复冲刺次数；同时玩家跳跃也会立刻重置冲刺资格。该逻辑通过字段和注释标识为新添加，用于限制连续冲刺。

飞行/滑翔：调用 EnableFlight(bool enabled) 可开启/关闭飞行模式，允许玩家在空中使用上下键上下移动（模拟飞行）。

其他：下落时应用额外重力，确保跳跃落地正常；处理角色朝向翻转等。

主要方法：Awake()、Start()、Update()、FixedUpdate()、私有协程 Dash(float mx)，EnableFlight(bool enabled)（公开）。

依赖：UnityEngine、FadedDreams.Core.GameManager 等。该脚本为游戏主角的移动核心之一。

Scripts/Player/PlayerEnergyHook.cs

功能：连接玩家光能系统的辅助组件，用于控制玩家的能量流失逻辑。

主要内容：

监听并控制玩家能量是否应该减少。例如，在特定情况下暂停能量减少。

方法 SetEnergyLossPaused(bool pause)：公开接口，用于暂停或恢复玩家能量消耗。

依赖：反射等技术读取玩家 PlayerLightController 上的字段（具体实现见代码）。

Scripts/Player/PlayerHealthLight.cs

功能：管理玩家的生命值和红光能量（可能为后期更新的功能）。当玩家与敌人碰撞时扣减红光能量。

主要内容：

自动获取玩家控制组件和 RedLightController，在碰撞或触发事件（OnCollisionEnter2D、OnTriggerEnter2D）中检测到敌人后，调用 TakeDamage(float) 减少玩家能量。

具体死亡逻辑和后续处理未完全解码，但推测能量耗尽时触发玩家死亡。

主要方法：Awake()、OnCollisionEnter2D(Collision2D)、OnTriggerEnter2D(Collider2D)。

依赖：FadedDreams.Player.RedLightController、PlayerController2D。

PlayerLightController（在“玩家模块”下）：
将“能量恢复逻辑”改为“靠近光源缓慢恢复（regenPerSecondNearLight），黑暗中每秒 drainPerSecondInDark；左键长按蓄能（≤3s、每秒10），松开触发0.25s爆发（强度×2、半径=15），3s回落，并点亮半径内不常亮光源；支持 chargeVfxPrefab / releaseVfxPrefab 两段特效”。可添加字段说明：detectLightsMask、minSenseIntensity、nearLightRadius。

Scripts/Player/PlayerLightVisual.cs

功能：玩家光模式的视觉效果管理。监听 PlayerLightController 的能量和模式变化，通过反射读取相关字段，并更新角色材质、发光等视觉表现。

主要成员：私有方法 OnEnergyDirty()、OnModeDirty() 响应事件，PullEnergyAndMode() 从控制器获取当前值，ApplyVisuals() 根据模式和能量设置材质参数等。

依赖：使用反射访问 PlayerLightController，以及 UnityEngine.Material。

Scripts/Player/ReadingStateController.cs

功能：管理玩家的“阅读”状态，包括自动阅读和手动触发阅读（收集话语对话）。

主要内容：

自动阅读：当玩家低能量且处于某些条件下，会自动开始阅读新对话（触发 SayingTrigger）。

手动阅读：响应玩家按键（例如“E”）触发阅读，如果冷却已结束。

冷却管理：TriggerReadingNow() 强制触发一次阅读并开始冷却；GetManualRemainingCooldownSeconds() 返回手动阅读的剩余冷却时间；ResetManualCooldownOnRespawn() 在玩家复活时重置手动阅读冷却。

协程 CoReading(float duration) 和亮度动画 CoAnimateBrightness(...)：播放阅读期间的动画和亮度变化。

主要方法：Awake()、Update()、TriggerReadingNow(): bool、GetManualRemainingCooldownSeconds(): float、ResetManualCooldownOnRespawn()，以及私有协程等。

依赖：SayingTrigger、SayingBook、PlayerLightController 等。

Scripts/Player/RedLight/RedLightController.cs

功能：专门管理玩家的红光能量槽（生命值条）和相关事件。

主要内容：

对应 PlayerLightController 的红光模式，提供可视化的能量条逻辑。

公开接口：Set(float value)、Add(float amount) 改变红光能量，TryConsume(float amount): bool 尝试消耗红光能量（如被攻击），OnHitByDarkSprite() 被暗影精灵击中时调用。

主要方法：OnEnable() 订阅玩家能量变化事件，Set()、Add() 等调整能量，TryConsume() 消耗能量并返回是否成功，OnHitByDarkSprite() 响应特殊击中。

依赖：UnityEngine.Events，与 DarkSpriteAI 交互。

Scripts/Player/Weapons/LaserEmitter.cs

功能：玩家武器脚本，发射激光束。可实现直线激光或散射光束，对敌人和场景物体造成伤害。

主要成员：

damage (float)：激光伤害值，power (float)：激光强度，range (float)：射程，scatterCount (int)：散射次数等。

方法 StartBeam(Vector2 dirAtStart), StopBeam(): 开始/停止发射激光。

方法 DoBeam(Vector2 dir): 执行连续光线投射，检测碰撞并产生粒子特效。

DoScatter(Vector2 dir): 实现光束分裂散射效果。

复杂方法：CastBeamPath(...) 递归进行光线（可能反射）检测。

辅助：SpawnScatterHalo()、PrepareAndPlay() 控制粒子系统。

主要方法：Awake()、Update() 监听输入触发发射，及上述发射相关方法。

依赖：FadedDreams.Enemies.IDamageable（命中敌人调用 TakeDamage）、FadedDreams.Utilities 类（如用于缓存顶点缓冲 EnsureQuadSize）。

敌人模块 (Scripts/Enemies)

Scripts/Enemies/IDamageable.cs

功能：伤害接口。任何可受伤害对象应实现此接口，包括敌人和可破坏的物体。

方法：

void TakeDamage(float amount): 应对指定数值的伤害。

bool IsDead { get; }: 属性，返回对象是否已死亡。

Scripts/Enemies/Projectile.cs

功能：通用子弹/投射物脚本，用于发射后碰撞造成伤害。

主要成员：

字段 damage (float)：造成的伤害值，lifeSpan (float)：存活时间。

方法 Start(): 在 lifeSpan 后销毁自身（Destroy(gameObject, lifeSpan)）。

方法 OnTriggerEnter2D(Collider2D other): 如果碰撞体实现 IDamageable（如 DarkSpriteAI），则调用其 TakeDamage(damage) 并销毁自身。

Scripts/Enemies/DarkSpriteAI.cs

功能：暗影精灵（Dark Sprite）敌人的行为控制脚本，实现复杂的 AI 状态机和自爆机制。该脚本实现了 IDamageable 接口。

主要内容：

状态机：包含多个子状态 Seek、Hover、Windup、Dive、Recover 等。基本流程：当玩家进入探测范围，则进入追踪状态，先漂浮盘旋（Hover），然后蓄力（Windup），接着俯冲攻击玩家（Dive），完成后恢复初始状态（Recover）。每个状态通过私有方法 Tick_* 处理。

闪光视觉：敌人血量降低时会发出红光（根据注释“红量→发光/染色”）。当触发自爆后，将关闭这些可视化效果。

受伤与自爆：场景中有专门的 EnemySelfExplodeOnOverheat 脚本处理 “红光过载自爆” 逻辑。当受伤（调用 TakeDamage）时，减少能量。若能量满，则触发 SelfExplode()：产生爆炸粒子特效和光照效果，对周围对象造成范围伤害和击退，点燃附近火把（Torch），触发摄像机抖动，并销毁自身。

碰撞检测：OnCollisionEnter2D、OnTriggerEnter2D 等方法处理与玩家或障碍碰撞。

接口实现：public void TakeDamage(float amount) 接口方法，减少自身血量，若血量≤0 则触发死亡逻辑。

依赖：UnityEngine.Events（内部事件 onChanged 监听能量变化）、UnityEngine.Rendering.Universal.Light2D（爆炸光照）、FadedDreams.Player.RedLightController（红光能量逻辑）、FadedDreams.World.Torch（点燃火把）、IDamageable、Cinemachine（摄像机抖动）等。

备注：该脚本注释指出可调参数和状态细节，为游戏主要敌人类型之一。

Scripts/Enemies/EnemySelfExplodeOnOverheat.cs

功能：附加在拥有 RedLightController 的敌人身上，实现“红光能量满后自爆”效果。通常与 DarkSpriteAI 配合。

主要内容：

在 OnEnable() 时订阅 RedLightController.onChanged 事件。当发现红光能量达到上限且尚未发生爆炸时，调用 Explode()。

Explode(): 生成爆炸粒子特效和光照；然后：

遍历爆炸范围内的所有 Collider2D，如果有 Torch 组件则调用 OnLaserFirstHit() 点燃火把。

对 affectMask 掩码内所有对象，若实现 IDamageable 且未死亡，则调用 TakeDamage(damage)；若拥有刚体，则施加冲击力 knockbackForce。

触发屏幕抖动（调用摄像机的位置抖动协程）。

最后销毁自身 GameObject。

协程 ExplodeSequence(Light2D l): 控制爆炸光照扩散动画，调整 Light2D 强度后销毁。

依赖：RedLightController、UnityEngine.Light2D、Torch、Physics2D、Cinemachine（屏幕抖动）、IDamageable 等。

注释说明：爆炸曲线、延迟销毁、光照半径缩放等特效参数均有注释，可调节。

界面模块 (Scripts/UI)

Scripts/UI/MainMenu.cs

功能：主菜单控制脚本，管理标题场景中的按钮交互。

主要功能：

按钮：New Game（新游戏）、Continue（继续）、Quit（退出）等。

NewGame(): 调用 LightSource2D.NewGameApplyStartOnDefaults()（重置全局光源状态），然后 SaveSystem.ResetAll() 清空存档，最后调用 SceneLoader.LoadScene(firstScene, firstCheckpoint) 进入第一场景起始检查点。

ContinueGame(): 从 SaveSystem 中读取 lastScene 和 lastCheckpoint，然后调用 SceneLoader.LoadScene 加载保存进度场景及检查点。

依赖：FadedDreams.Core.SaveSystem、SceneLoader、FadedDreams.World.Light.LightSource2D（初始化光源）。

Scripts/UI/ContinueMenu.cs

功能：“继续游戏”界面脚本，位于弹出窗口上。列出当前章节下已解锁的所有检查点，玩家可点击任一项跳转。

主要功能：

在 OnEnable() 时清空列表，根据当前章节（通常从 GameManager 或场景名得知）逐个生成按钮条目。数据来自 SaveSystem.GetCheckpoints()（所有已发现检查点 ID）。

每个按钮显示检查点的 ID，点击后调用 SceneLoader.LoadScene(currentSceneName, checkpointId) 加载对应检查点。

组件绑定：挂载在 ScrollView 的 Content 下，sceneName 字段指定本界面对应的场景（如“Chapter1”）。

依赖：FadedDreams.Core.SaveSystem、SceneLoader。

Scripts/UI/PauseMenu.cs

功能：暂停菜单面板脚本，控制暂停界面显示与隐藏。

主要功能：

Toggle(): 切换菜单面板的激活状态，当打开时暂停游戏（Time.timeScale = 0），当关闭时恢复游戏。

按钮：Resume（继续游戏）调用 OnResume() 关闭菜单，恢复时间；Continue from save（载入存档）调用 SceneLoader.LoadScene 加载最后进度；Back to Main 调用 SceneLoader.LoadScene("MainMenu", "") 返回主菜单。

OnResume(): 恢复游戏时间和输入锁定状态，关闭菜单。

Awake(): 确保场景中存在 EventSystem，用于 UI 交互。

依赖：SceneLoader、GameManager（可选，用于限制章节，见下）。

Scripts/UI/PauseToggle.cs

功能：监听全局按键（如 Esc）以打开或关闭暂停菜单。

主要功能：

在 Update() 中检测 Esc 键按下，触发 pauseMenu.Toggle()。

支持选项 restrictToCh1To4：若为 true，则仅在第 1–4 章启用暂停（使用 GameManager.CurrentChapter 或 ChapterManager.ChapterFromScene() 判断）。

依赖：PauseMenu、GameManager 或 ChapterManager。

Scripts/UI/GlowTextBanner.cs

功能：全局唯一的横幅文本提示器，用于在屏幕上中央显示短文本。近期新增组件，常用于场景触发器弹出提示。

主要成员：

单例 Instance 持有 CanvasGroup (canvasGroup) 和 TextMeshProUGUI (label)。初始时隐藏（canvasGroup.alpha = 0）。

Show(string text, string token, float fadeIn): 设置 label.text = text，并将 canvasGroup.alpha 通过协程插值到 1 显示出来。token 用于标识当前持有显示权的调用者。

Hide(string token, float fadeOut): 仅当传入的 token 与当前持有者相同时，通过协程将透明度插值到 0 隐藏。

ForceHide(float fadeOut): 忽略 token 直接淡出。

利用协程平滑过渡透明度，实现淡入淡出效果。

依赖：TMPro、UnityEngine.CanvasGroup。可在任何触发器脚本（如 GlowTextZone）中调用，用于屏幕提示。

Scripts/UI/GlowTextZone.cs

功能：场景触发器脚本，放置于特定区域。近期新增：当玩家进入该区域时，在屏幕上方显示一段文本，离开后隐藏。

主要成员：

字段 message (string)：要显示的文本内容；fadeIn、fadeOut (float)：淡入淡出时间；playerTag (string)：玩家标签。

Awake(): 生成一个唯一的 token（基于 GetInstanceID()）标识此触发器。

OnTriggerEnter2D(Collider2D other): 如果 other.tag 与 playerTag 匹配，则调用 GlowTextBanner.Instance.Show(message, token, fadeIn)。

OnTriggerExit2D(Collider2D other): 玩家离开区域时，调用 GlowTextBanner.Instance.Hide(token, fadeOut) 隐藏横幅。

要求：附加的 GameObject 需有 Collider2D 并勾选 isTrigger=true。

Scripts/UI/RedLightHUD.cs

功能：红光能量条 UI 控制器，显示玩家当前红光（生命）值。挂载在 HUD Canvas 上。

主要成员：

引用 RedLightController red、Slider slider、Gradient colorByPercent、Image fill。

Awake(): 查找 red 对象（玩家红光控制器），初始化 slider.maxValue = red.Max、slider.value = red.Current，并订阅 red.onChanged 事件。

方法 OnRedChanged(float cur, float max): 更新 slider.value = cur，并根据 cur/max 在 colorByPercent 渐变图中获取颜色，设置 fill.color。实时反映红光能量的变化。

Scripts/UI/HUDController.cs

功能：玩家光能和模式的 HUD 更新。挂载在游戏中 HUD Canvas 上。

主要成员：

字段 Slider energyBar：显示玩家当前光能百分比；TextMeshProUGUI modeLabel：显示当前光模式名称；PlayerLightController player。

Start(): 将自身注册为玩家控制器事件的监听者：player.onChanged（能量变化）调用 Refresh()，player.onModeChanged 调用 RefreshMode()。

Refresh(): 根据 player.currentEnergy / player.maxEnergy 更新 energyBar.value。

RefreshMode(): 更新 modeLabel.text = player.mode.ToString()。

作用：实时更新玩家当前能量和模式到 HUD。

Scripts/UI/SaveSlotItem.cs

功能：多存档槽支持的占位脚本，目前空实现。可用于将来扩展多存档功能。

Scripts/UI/SayingBookUI.cs

功能：话语册界面脚本，管理玩家已收集话语的显示列表。

主要成员：

UI 引用：GameObject rootCanvas、Button topRightButton（右上角按钮）和 TextMeshProUGUI countLabel（显示阅读冷却）、GameObject panel（弹出面板）、Transform listParent（列表容器）、GameObject itemPrefab（话语条目预制体）。

Awake(): 获取组件并初始化状态。

Toggle()：点击右上角按钮时调用，切换面板可见性。打开时调用 RebuildList()。

RebuildList(): 清空 listParent 下所有子物体，通过 SayingBook.GetAllSayings() 获取所有文本，然后按顺序实例化 itemPrefab 并设置其文本内容。

Update(): 每隔一定时间（如 0.2 秒）更新 countLabel 显示的手动阅读剩余冷却时间（调用 ReadingStateController.GetManualRemainingCooldownSeconds()），格式化为“读CD: mm:ss” 或 “就绪”。

依赖：FadedDreams.Core.SayingBook（获取已收集文本）、ReadingStateController（获取冷却时间）。

工具模块 (Scripts/Utilities)

Scripts/Utilities/Singleton.cs

功能：泛型单例基类。任何需要全局唯一实例的组件可继承此类，例如 GameManager、SaveSystem。提供静态属性 Instance 访问唯一实例。使用前需确保场景中有该组件的 GameObject。

Scripts/Utilities/SerializableDictionary.cs

功能：Unity 不支持直接序列化普通 Dictionary，此脚本提供一个可序列化的字典（基于 IDictionary 和自定义序列化）。可以在 Inspector 中编辑。

Scripts/Utilities/BeamReflector2D.cs

功能：光线反射器，用于场景中将光束按照反射/折射路径传递。实现类似 “激光镜面反射”。

主要成员：静态内部类 Result 描述单次射线投射结果。主要方法 Cast(Vector2 origin, Vector2 dir, int maxBounce, LayerMask mask)：从起点沿方向 dir 发射光线，检测碰撞后计算反射方向，递归处理多次弹射，返回最终路径数据。

Scripts/Utilities/BloomBreathByEnergy.cs

功能：根据玩家能量改变屏幕光晕效果。绑定到摄像机等，可使得玩家能量越高，屏幕泛光（Bloom）越强。

Scripts/Utilities/CameraFollow2D.cs

功能：简易 2D 相机跟随脚本。将相机位置固定在目标（通常是玩家）附近，保持相对位置或淡入淡出过渡。

Scripts/Utilities/FloatingSaying.cs

功能：屏幕上空飘动文字提示工具。常用于显示“收集到话语”之类的提示。

主要成员：

静态方法 SpawnPopup(Transform near, string msg): 在指定目标位置上方生成一个空 GameObject，并附加 FloatingSaying 组件来显示文本。

Show(Transform target, Vector2 offset, string text, float duration): 保存显示目标和文字，启动协程 CoRun()。

CoRun(): 执行淡入、停留、淡出动画，同时让文字位置跟随 target。

Scripts/Utilities/LayerRefs.cs

功能：保存常用物理层（Layer）或标签名称/编号的静态引用。简化不同脚本间对特定层的引用（如敌人层、射线层等）。

世界与关卡模块 (Scripts/World)
背景与特效

Scripts/World/BackgroundEdgeRepeatFill.cs

功能：自动平铺背景纹理，使其填满摄像机视野。支持运行时和编辑时 [ExecuteAlways] 调整。根据摄像机视野大小重复缩放四周背景图块。

收集物与交互

Scripts/World/Collectibles/ColorInteractable.cs

功能：颜色交互物件。放在场景中，当玩家以对应光模式（Red/Green/Blue）进入范围时触发效果（如启动某机关）。

方法：OnTriggerEnter2D(Collider2D other) 检测玩家进入，并根据玩家当前 LightMode 激活对应交互。

Scripts/World/Collectibles/GlowTextZone.cs (同 UI 模块 GlowTextZone，上下部分重复，可归为其一)

功能：同 UI 模块描述。

Scripts/World/Collectibles/SayingTrigger.cs

功能：话语触发器，附加在场景中某些地点，用于让玩家收集新的“话语”（对话文本）。

主要内容：

Reset(): 重置触发器状态（编辑模式下使用）。

OnTriggerEnter2D(Collider2D other): 玩家进入时调用，若条件满足调用 SayingBook.TryCollect(id, text) 收集对话，并通过 FloatingSaying.SpawnPopup 生成提示文字。

危险物

Scripts/World/Hazards/InstantLightDrain.cs

功能：即时光能吸收器，放在场景中作为陷阱。玩家进入时立即消耗其所有光能（相当于瞬间死亡）。

方法：OnTriggerEnter2D(Collider2D other): 如果进入的对象是玩家（检测 RedLightController 或标签），则调用该组件的 TakeDamage(currentEnergy) 或类似方法，将玩家光能设为 0。

光源 (Light)

Scripts/World/Light/LightIrradianceSensor.cs

功能：光照传感器，可对场景光源进行感知。依赖于 URP。如果启用 Universal Rendering Pipeline，计算周围 Light2D 对象照度，并通过事件通知其他对象（如变化玩家能量）。

主要内容：使用 UnityEngine.Rendering.Universal.Light2D 获取场景灯光，评估与传感器的距离和角度，调用回调事件传递强度。

LightSource2D（在“世界模块/光源”下）：
把原先“startOn/isOn/点亮状态”的描述移除，替换为：
“光源分为常亮（isConstant=true）与不常亮。

常亮：强度固定为 litIntensity；

不常亮：有 maxEnergy=100 与 currentEnergy，每秒 drainPerSecond；强度按 currentEnergy/maxEnergy 从 unlitIntensity 线性映射到 litIntensity；

被其它光照到或调用 LightUp() 时 currentEnergy 直接置 100，可选播放爆燃（burst*），并对外提供 ProvidesLight(minThreshold)。”
同时删去与 startOn/isOn 相关的存取说明。

Scripts/World/Light/Torch.cs

功能：火把（Torch）脚本，可被激光点燃。

主要内容：

字段 lightIntensityOn (float)：点燃后光强，igniteTime (float)：点燃动画持续时间。

Reset()/Awake(): 初始化组件，隐藏光源。

Update(): 如果火把点燃状态，逐渐降低 light.intensity 实现衰减。

OnLaserFirstHit(): 当激光首次命中火把时调用，立即点燃火把。

OnLaserHitAt(Vector2 hitPoint, float incomingLight)：激光射中火把，尝试点燃（调整光强）。

TryIgniteByLaser(Vector2 hitPoint, bool hasPoint, float incomingLight): 内部处理激光点燃逻辑，根据入射光强决定是否点燃。

点燃动画协程 Co_IgniteFlash(): 播放点燃闪光效果。

依赖：UnityEngine.Light2D。

机关 (Mechanisms)

Scripts/World/Mechanisms/DarkRedBlock.cs

功能：暗红方块，仅能被红光模式击碎的方块。

主要内容：

OnCollisionEnter2D(Collision2D other): 如果碰撞体为玩家且当前是红光模式，则触发碎裂动画（Break()）并销毁自身。

Break(): 生成粒子特效或播放动画，然后 Destroy(gameObject)。

依赖：FadedDreams.Player.RedLightController。

Scripts/World/Mechanisms/HeatPlatform.cs

功能：热平台组件，当玩家（或其他物体）进入时升高温度带来效果。

主要内容：

OnCollisionEnter2D/Exit2D: 开始/停止触碰时调整平台状态（如点燃火焰特效）。

OnTriggerEnter2D(Collider2D): 如玩家落在平台上，根据温度设置可能的伤害或音效。

可以调用 RedLightController 或其他机制影响玩家。

注释中可见红光控制和事件调用信息，表明平台会随着接触产生热焰。

Scripts/World/Mechanisms/LightDrivenMover.cs

功能：光驱动移动器，根据玩家光照强度控制移动对象。

主要内容：

列表 slots 定义能被影响的物体和移动目标位置。

在 Update() 中根据绑定在该区域的光强度计算目标移动值。

允许场景设计师在编辑器中设置不同光模式对应的移动量。

Scripts/World/Mechanisms/PhotoGate.cs

功能：光电门机关，需要玩家的光照触发。

主要成员：

OnTriggerEnter2D(Collider2D other): 如果碰撞体为带 LightSource2D 的对象（如玩家射出的光），则打开门（OpenGate()）；

OpenGate(): 启动门的动画或移动到打开位置。

依赖：检测玩家的光，可能使用 UnityEngine.U2D.Light2D 屏蔽光层判断。

Scripts/World/Mirror2D.cs

功能：2D 镜面反射，放置在场景中折射玩家或激光束。

主要内容：

OnTriggerEnter2D(Collider2D other): 如果碰撞体为光束的碰撞器，则计算出反射方向并调用 BeamReflector2D 处理。

可配置镜面角度和反射数量。

第三章相关脚本 (Scripts/d第三章)

“第三章”模块包含专属于第三章关卡的脚本、敌人和道具。路径前缀为 Scripts/d第三章/。

Scripts/d第三章/AreaEnergyRegen.cs

功能：能量恢复区域。在该区域内玩家的能量自动恢复。

主要方法：OnTriggerEnter2D、OnTriggerExit2D：玩家进入时开始持续回血，离开时停止。

Scripts/d第三章/BracketVisual.cs

功能：能量条括号（Bracket）视觉组件。对齐在屏幕边缘显示能量（或状态）区块边框。

主要内容：调整画布位置和旋转。

Scripts/d第三章/CloudSniperAI.cs

功能：云雾狙击手敌人 AI。远程攻击玩家。

主要内容：侦测玩家后进入蓄力，然后发射远程攻击。继承自 IDamageable。包含 Awake() 初始化、Update() 跟踪玩家、OnTriggerEnter2D 受伤逻辑。

Scripts/d第三章/EnemyHealth.cs

功能：通用的敌人生命组件。可附加到多种敌人上，处理基础生命值和受伤、死亡。

主要方法：TakeDamage(float) 减少生命，死亡时触发销毁等。

Scripts/d第三章/EnergyBracketsController.cs

功能：管理能量条括号显示的控制器。显示玩家当前能量层级。

主要内容：根据玩家能量变化（通过事件监听）动态更新边框显示。

Scripts/d第三章/EnergyPickup.cs

功能：能量拾取道具。玩家碰撞时增加能量。

主要方法：OnTriggerEnter2D(Collider2D other): 玩家进入时调用 player.AddEnergy(amount)，然后销毁道具。

Scripts/d第三章/EnergyPickupLightTint.cs

功能：能量道具的光照着色器控制脚本。根据玩法需求给能量球添加特效光晕。

主要内容：在运行时改变材质颜色或光源颜色。

Scripts/d第三章/FlashStrike.cs

功能：特殊攻击效果（闪电突袭）。

主要内容：追踪目标位置并生成闪电特效伤害敌人。

Scripts/d第三章/ModeVisibilityFilter.cs

功能：模式可见性过滤器。根据玩家当前光模式（R/G/B）控制某些对象的可见性或活动性。

主要方法：OnEnable(), OnDisable() 监听模式变化事件，根据 player.mode 开启/关闭自身渲染或碰撞。

Scripts/d第三章/PlayerColorModeController.cs

功能：管理玩家在第三章中切换模式的控制器（可能与武器模式有关）。

主要内容：提供在不同模式间转换的接口。

Scripts/d第三章/PlayerMeleeLaser.cs

功能：玩家的近战激光武器。结合近身和光束攻击。

主要内容：发射一条近距离激光，对敌人造成伤害。

新增特性：根据注释，此版本在击中时生成命中粒子并对敌人施加击退效果（“新增：命中粒子 + 击退”）。

Scripts/d第三章/PlayerRangedCharger.cs

功能：玩家远程充能武器，发射蓄力射击。

主要内容：按住蓄力后释放能量弹，对远处目标造成伤害。

新增特性：注释中提到增加了“炫酷特效（无资源）”作为视觉增强。

Scripts/d第三章/SwarmMeleeAI.cs

功能：成群冲锋敌人 AI。多只小怪物协同行动近身攻击。

主要内容：跟踪玩家并向其冲锋，低血量时散开或死亡。实现 IDamageable 接口。

其他资源：该目录下还有若干 Prefab（如光球、火焰特效）和图片资源用于场景特效，这里主要关注脚本文件。

其他文件

Scripts/CODE_OVERVIEW.md：脚本说明文档，总览本目录结构及各脚本功能（即本文的生成目标）。

.meta 文件：Unity 编辑器生成的元数据文件，可忽略。

模块间依赖关系

核心模块彼此高度关联：GameManager、SaveSystem、SceneLoader、Checkpoint 相互调用协作，共同维护游戏状态和场景切换。

玩家模块主要使用核心模块和敌人模块：玩家控制器不直接依赖 SaveSystem 等，但死亡时通过 GameManager/SceneLoader 触发重生；玩家与敌人通过 IDamageable 接口交互。

敌人模块使用玩家模块中的 RedLightController（红光能量）来实现自爆逻辑；Projectile 使用 IDamageable 伤害玩家和敌人。

UI 模块通过监听玩家和核心模块的事件更新界面：如 HUDController 监听 PlayerLightController.onChanged 更新能量条；SayingBookUI 调用 SayingBook 和 ReadingStateController。

工具模块提供底层功能：Singleton 被核心模块继承；BeamReflector2D 被激光武器和镜面使用；FloatingSaying 被 SayingTrigger 和其他触发器调用。

世界模块互相较少直接调用，但与玩家/敌人交互：如光源 Torch 响应玩家激光，InstantLightDrain 伤害玩家，机关脚本响应玩家状态等。

以上为 Scripts.zip 中所有脚本的详细概览。每个文件的主要功能、关键类方法以及相互依赖关系已经逐一说明，并标注了近期新增的功能或脚本，以便后续维护与扩展。