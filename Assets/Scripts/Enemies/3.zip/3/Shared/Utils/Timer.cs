using UnityEngine;

namespace FD.Shared.Utils {
    public class Timer {
        float dur; float t; bool loop; System.Action onDone;
        public Timer(float duration, bool looping=false, System.Action done=null){ dur=Mathf.Max(0.0001f,duration); loop=looping; onDone=done; t=0f; }
        public bool Tick(float dt){ t += dt; if (t>=dur){ if(loop) t=0f; onDone?.Invoke(); return true; } return false; }
        public void Reset(float newDur=-1f){ if(newDur>0f) dur=newDur; t=0f; }
        public float Ratio01 => Mathf.Clamp01(t/dur);
        public float Remaining => Mathf.Max(0f, dur - t);
    }
}
