using System.Collections.Generic;
using UnityEngine;

namespace FD.Bosses.C3.SM
{
    public class BossStateMachine : MonoBehaviour
    {
        readonly Stack<IState> stack = new();
        IState current => stack.Count > 0 ? stack.Peek() : null;

        [Header("Debug")] public bool debugLogs = true;

        public void Init(MonoBehaviour ctx) { if (debugLogs) Debug.Log("[BOSS][FSM] Init"); }
        public void Tick(float dt) { current?.Tick(dt); }
        public void Push(IState s)
        {
            if (current != null && !current.CanInterrupt) { if (debugLogs) Debug.Log($"[BOSS][FSM] Push blocked by {current.GetType().Name}"); return; }
            stack.Push(s); if (debugLogs) Debug.Log($"[BOSS][FSM] Push {s.GetType().Name} size={stack.Count}");
            s.OnEnter();
        }
        public void Pop()
        {
            if (stack.Count == 0) return;
            var s = stack.Pop();
            if (debugLogs) Debug.Log($"[BOSS][FSM] Pop {s.GetType().Name} size={stack.Count}");
            s.OnExit();
        }
        public void PushPhaseShift() { Push(new State_PhaseShift(this)); }
        public void PushStagger() { Push(new State_Staggered(this)); }
    }
}