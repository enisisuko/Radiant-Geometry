namespace FD.Bosses.C3.SM {
  public interface IState {
    void OnEnter();
    void OnExit();
    void Tick(float dt);
    bool CanInterrupt { get; }
  }
}
