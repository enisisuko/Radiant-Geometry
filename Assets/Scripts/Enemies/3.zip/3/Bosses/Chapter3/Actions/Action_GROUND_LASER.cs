using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_GROUND_LASER : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else { done = true; }
    }
    IEnumerator Do(){
      float dur = Mathf.Max(0.3f, Data.activeTime > 0 ? Data.activeTime : 0.35f);
      Vector3 start = ctx.transform.position; Vector3 dir = ctx.transform.forward;
      float len = 8f; float t = 0f;
      while (t < dur){ t += Time.deltaTime; var p = start + dir * len; BossActionHelpers.TryHitPlayerCircle(ctx, p, 0.8f, Data.damage); yield return null; }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime * 0.25f)); base.StartRecover();
    }
  }
}