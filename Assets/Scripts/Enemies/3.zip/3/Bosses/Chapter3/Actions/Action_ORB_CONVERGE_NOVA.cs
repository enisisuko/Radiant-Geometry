using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_ORB_CONVERGE_NOVA : BaseBossAction {
    public override void StartActive(){
      base.StartActive(); // ensure orb choreo triggers
      if (ctx) ctx.StartCoroutine(Do()); else { done = true; }
    }
    IEnumerator Do(){
      float charge = Mathf.Max(0.3f, Data.windupTime > 0 ? Data.windupTime : 0.8f);
      yield return new WaitForSeconds(charge);
      if (!ctx) { done = true; yield break; }
      ActionCommon.HitCircle((Vector2)ctx.transform.position, 2.2f, Data.damage * 2f, LayerMask.GetMask("Player"));
      float tail = Mathf.Max(0.01f, Data.recoverTime * 0.25f);
      yield return new WaitForSeconds(tail);
      base.StartRecover();
    }
  }
}