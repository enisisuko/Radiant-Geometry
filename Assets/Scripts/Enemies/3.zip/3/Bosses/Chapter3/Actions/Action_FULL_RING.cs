using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_FULL_RING : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else { done = true; }
    }
    IEnumerator Do(){
      float dur = Mathf.Max(0.35f, Data.activeTime > 0 ? Data.activeTime : 0.4f);
      float r0 = 0.5f, r1 = 12f; float t = 0f; Vector3 c = ctx.transform.position;
      while (t < dur){ t += Time.deltaTime; float r = Mathf.Lerp(r0, r1, t / dur);
        BossActionHelpers.TryHitPlayerCircle(ctx, c, r, Data.damage); yield return null; }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime * 0.25f)); base.StartRecover();
    }
  }
}