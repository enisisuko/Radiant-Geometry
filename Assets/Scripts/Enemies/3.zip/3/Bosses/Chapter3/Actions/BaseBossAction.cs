using UnityEngine;
using FD.Bosses.C3.Core;
using FD.Bosses.C3.Data;

namespace FD.Bosses.C3.Actions
{
    public abstract class BaseBossAction : MonoBehaviour, IBossAction
    {
        protected BossChapter3Controller ctx;
        public BossActionData Data { get; private set; }
        protected bool done;

        [Header("Orb Patterns (optional per-phase)")]
        public OrbPatternData orbPatternTell;
        public OrbPatternData orbPatternActive;
        public OrbPatternData orbPatternRecover;

        [Header("Choreo Upgrade")]
        public bool autoFlareOnActive = true;
        [Range(1f, 2.5f)] public float flareAmplitude = 1.6f;
        [Range(0.05f, 0.6f)] public float flareDuration = 0.18f;

        public virtual void Init(BossChapter3Controller c, BossActionData data) { ctx = c; Data = data; }
        public virtual bool CanStart() { return true; }

        public virtual void StartTell()
        {
            done = false;

            // 颜色预混（读招）
            if (ctx && ctx.orbRing)
                ctx.orbRing.PreBlendColor(Data.color, Mathf.Max(0.18f, Data.tellTime * 0.6f));

            // 喂图案（或兜底 flare）
            bool fed = TryApplyPattern(orbPatternTell ?? Data?.orbPattern, overrideDuration: Mathf.Max(0.12f, Data.tellTime));
            if (!fed && ctx && ctx.orbRing)
            {
                float dur = Mathf.Max(0.18f, Data.tellTime);
                var flare = MakeFlarePattern(ctx.phase == BossPhase.P2, Data != null ? Data.color : BossColor.Red, 1.15f, dur * 0.8f);
                ctx.orbRing.ApplyPattern(flare);
            }
        }

        public virtual void StartWindup() { }

        public virtual void StartActive()
        {
            bool fed = TryApplyPattern(orbPatternActive ?? Data?.orbPattern, overrideDuration: Mathf.Max(0.12f, Data.activeTime));
            float baseDur = (Data != null && Data.activeTime > 0f) ? Data.activeTime : 0.45f;

            if (ctx && ctx.orbRing)
            {
                if (autoFlareOnActive)
                {
                    var flare = MakeFlarePattern(ctx.phase == BossPhase.P2, Data != null ? Data.color : BossColor.Red, flareAmplitude, Mathf.Max(flareDuration, baseDur * 0.6f));
                    ctx.orbRing.ApplyPattern(flare);
                }
                else if (!fed)
                {
                    var flare = MakeFlarePattern(ctx.phase == BossPhase.P2, Data != null ? Data.color : BossColor.Red, 1.25f, Mathf.Max(0.25f, baseDur * 0.5f));
                    ctx.orbRing.ApplyPattern(flare);
                }
            }
        }

        public virtual void StartRecover()
        {
            TryApplyPattern(orbPatternRecover, overrideDuration: Mathf.Max(0.10f, Data.recoverTime));
            done = true;
        }

        public virtual void Abort() { done = true; }
        public bool IsDone => done;

        protected bool TryApplyPattern(OrbPatternData p, float overrideDuration = 0f)
        {
            if (ctx == null || ctx.orbRing == null || p == null || p.keyframes == null || p.keyframes.Length == 0)
                return false;

            // 克隆并强制相位（P1=4 / P2=6）
            var clone = ScriptableObject.CreateInstance<OrbPatternData>();
            clone.phase2SixOrbs = (ctx.phase == BossPhase.P2);

            clone.keyframes = new OrbKeyframe[p.keyframes.Length];
            for (int i = 0; i < p.keyframes.Length; i++)
            {
                var k = p.keyframes[i];
                if (overrideDuration > 0f && k.duration <= 0.0001f) k.duration = overrideDuration * 0.6f;
                clone.keyframes[i] = k;
            }

            ctx.orbRing.ApplyPattern(clone);
            return true;
        }

        protected static OrbPatternData MakeFlarePattern(bool six, BossColor color, float amp, float dur)
        {
            var p = ScriptableObject.CreateInstance<OrbPatternData>();
            p.phase2SixOrbs = six;

            var kfs = new System.Collections.Generic.List<OrbKeyframe>();
            var col = (color == BossColor.Red) ? new Color(1f, 0.35f, 0.35f, 1f) : new Color(0.35f, 1f, 0.35f, 1f);
            float baseR = six ? 2.4f : 2.0f;
            float flareR = baseR * Mathf.Clamp(amp, 1f, 2.5f);

            // 读招/出手可见的最小组合
            kfs.Add(new OrbKeyframe { t = 0f, motion = OrbMotion.Spread, radius = flareR, duration = dur * 0.6f, color = col, brightness = 1f, note = "flare spread" });
            kfs.Add(new OrbKeyframe { t = dur * 0.20f, motion = OrbMotion.Spin, radius = flareR, duration = dur * 0.8f, color = col, brightness = 1f, note = "flare spin" });
            kfs.Add(new OrbKeyframe { t = dur * 0.20f, motion = OrbMotion.Pulse, radius = flareR, duration = dur, color = col, brightness = 1f, note = "flare pulse" });
            kfs.Add(new OrbKeyframe { t = dur, motion = OrbMotion.Gather, radius = baseR * 1.05f, duration = dur * 0.6f, color = col, brightness = 0.9f, note = "flare settle" });

            p.keyframes = kfs.ToArray();
            return p;
        }
    }
}
