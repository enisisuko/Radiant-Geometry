using FD.Bosses.C3.Data;
using UnityEngine;
using FD.Bosses.C3.Runtime;   // �� ����ʱ�������
using FD.Bosses.C3.Actions;   // Ϊ�� BaseBossAction ��ʽ�ɼ�

namespace FD.Bosses.C3.Actions
{
    public static class ActionsRegistry
    {
        // ͳһ�������ã������½�����������
        static T GetOrAddUnique<T>(Core.BossChapter3Controller ctx) where T : Component, IBossAction
        {
            var existed = ctx.GetComponents<T>();
            T use = null;
            if (existed.Length > 0) use = existed[0];
            for (int i = 1; i < existed.Length; i++)
            {
                Object.Destroy(existed[i]); // ������ʷй©
            }
            if (use == null) use = ctx.gameObject.AddComponent<T>();
            return use;
        }

        public static IBossAction SpawnFor(BossActionData data, Core.BossChapter3Controller ctx)
        {
            IBossAction act = data.actionId switch
            {
                101 or 201 => GetOrAddUnique<Action_THRUST>(ctx),
                102 => GetOrAddUnique<Action_SWEEP>(ctx),
                103 => GetOrAddUnique<Action_GROUND_RING>(ctx),
                104 => GetOrAddUnique<Action_SCATTER_SHOTS>(ctx),
                105 or 212 => GetOrAddUnique<Action_LEAP_CLEAVE>(ctx),
                106 or 209 => GetOrAddUnique<Action_DELAYED_THUNDER>(ctx),
                107 => GetOrAddUnique<Action_PULL_PUSH>(ctx),
                108 or 205 => GetOrAddUnique<Action_DODGE_RIPOSTE>(ctx),
                109 => GetOrAddUnique<Action_TRIPLE_THRUST>(ctx),
                204 => GetOrAddUnique<Action_RING_SIX_ARCS>(ctx),
                206 => GetOrAddUnique<Action_TRI_BEAM>(ctx),
                207 => GetOrAddUnique<Action_WHIRLWIND>(ctx),
                208 => GetOrAddUnique<Action_GRAV_TRAP>(ctx),
                210 => GetOrAddUnique<Action_FULL_RING>(ctx),
                211 => GetOrAddUnique<Action_ORB_CONVERGE_NOVA>(ctx),
                213 => GetOrAddUnique<Action_WALL_BOUNCE_Z>(ctx),
                214 => GetOrAddUnique<Action_PRISM_BARRAGE>(ctx),
                215 => GetOrAddUnique<Action_CHROMA_LOCK>(ctx),
                216 => GetOrAddUnique<Action_DOUBLE_FAN>(ctx),
                _ => null
            };

            if (act == null)
            {
                Debug.LogWarning($"[BOSS][Actions] Unknown actionId={data.actionId}, fallback to THRUST");
                act = GetOrAddUnique<Action_THRUST>(ctx);
            }

            // ��ʼ��
            act.Init(ctx, data);

            // �� ����ʱ�Զ��� ACTIVE / RECOVER �켣���� C3_Orb_{id}_... ��������
            //   - һ�������Ѱ� TELL �赽 BossActionData.orbPattern��Ԥ��=ͣת+����
            //   - ����� ACTIVE/RECOVER Ҳ�Զ����� BaseBossAction �ֶΣ�����/���м���ר������
            var baseAction = act as BaseBossAction;
            if (baseAction != null)
            {
                C3_OrbPatternRuntimeBinder.Bind(baseAction, data);
            }
            else
            {
                Debug.LogWarning($"[BOSS][Actions] Action instance is not BaseBossAction ({act?.GetType().Name}), skip binding ACTIVE/RECOVER.");
            }

            return act;
        }
    }
}
