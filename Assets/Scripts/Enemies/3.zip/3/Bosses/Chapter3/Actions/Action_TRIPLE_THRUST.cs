using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_TRIPLE_THRUST : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else done = true;
    }
    IEnumerator Do(){
      for(int i=0;i<3;i++){
        Vector3 dir = BossActionHelpers.FlatDirTo(ctx, ctx.transform.position);
        Vector3 start = ctx.transform.position;
        Vector3 end = start + dir * 2.2f;
        float t=0, dur=0.14f;
        while(t<dur){ t+=Time.deltaTime; ctx.transform.position = Vector3.Lerp(start,end,t/dur); BossActionHelpers.TryHitPlayerCircle(ctx, ctx.transform.position, 0.8f, Data.damage); yield return null; }
        yield return new WaitForSeconds(0.08f);
      }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime*0.25f));
      base.StartRecover();
    }
  }
}