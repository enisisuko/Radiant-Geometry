using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_DOUBLE_FAN : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else { done = true; }
    }
    IEnumerator Do(){
      yield return SweepFan(-1); yield return SweepFan(+1);
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime * 0.25f)); base.StartRecover();
    }
    IEnumerator SweepFan(int dirSign){
      float dur = 0.35f; float span = 90f; float r = 2.3f; float t = 0f; Vector3 c = ctx.transform.position;
      while (t < dur){
        t += Time.deltaTime; float ang = (dirSign < 0 ? -span : span) * (t / dur);
        var p = c + (Quaternion.Euler(0, ang, 0) * ctx.transform.right) * r;
        BossActionHelpers.TryHitPlayerCircle(ctx, p, 0.9f, Data.damage); yield return null;
      }
    }
  }
}