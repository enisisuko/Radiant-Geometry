using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_GRAV_TRAP : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else { done = true; }
    }
    IEnumerator Do(){
      Vector3 basePos = ctx && ctx.player ? ctx.player.position : (ctx ? ctx.transform.position + ctx.transform.forward * 4f : Vector3.zero);
      Vector3 offset = Vector3.right * 2.0f; Vector3 A = basePos + offset, B = basePos - offset;
      float pullT = 1.6f; float t = 0f;
      while (t < pullT){ t += Time.deltaTime; BossActionHelpers.PullPlayerTowards(ctx, (A + B) * 0.5f, 6f * Time.deltaTime); yield return null; }
      BossActionHelpers.TryHitPlayerCircle(ctx, A, 1.1f, Data.damage);
      BossActionHelpers.TryHitPlayerCircle(ctx, B, 1.1f, Data.damage);
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime * 0.25f)); base.StartRecover();
    }
  }
}