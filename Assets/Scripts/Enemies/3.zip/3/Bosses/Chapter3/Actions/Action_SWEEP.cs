using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_SWEEP : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else done = true;
    }
    IEnumerator Do(){
      float dur = Mathf.Max(0.45f, Data.activeTime>0?Data.activeTime:0.6f);
      float angleSpan = 120f; float hitRadius = 2.2f; Vector3 c = ctx.transform.position; float t=0;
      while(t<dur){ t+=Time.deltaTime; float k=t/dur; float ang=-angleSpan*0.5f + angleSpan*k;
        var p = c + (Quaternion.Euler(0,ang,0)*ctx.transform.right) * hitRadius;
        BossActionHelpers.TryHitPlayerCircle(ctx, p, 0.8f, Data.damage);
        yield return null; }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime*0.25f));
      base.StartRecover();
    }
  }
}