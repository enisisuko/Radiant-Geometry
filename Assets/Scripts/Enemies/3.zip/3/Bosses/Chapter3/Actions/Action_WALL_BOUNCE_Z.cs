using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_WALL_BOUNCE_Z : BaseBossAction {
    public override void StartActive(){
      base.StartActive(); 
      if (ctx) ctx.StartCoroutine(Do()); else done = true;
    }
    IEnumerator Do(){
      Vector3 center = Vector3.zero; // TODO: replace with your arena center
      Vector3 dir = BossActionHelpers.FlatDirTo(ctx, ctx.transform.position);
      Vector3 right = Vector3.Cross(Vector3.up, dir).normalized;
      Vector3 A = ctx.transform.position + (dir+right).normalized * 4.5f;
      Vector3 B = ctx.transform.position + (dir-right).normalized * 4.5f;
      Vector3 C = center;
      yield return MoveTo(A, 0.18f);
      BossActionHelpers.TryHitPlayerCircle(ctx, ctx.transform.position, 0.9f, Data.damage);
      yield return MoveTo(B, 0.18f);
      BossActionHelpers.TryHitPlayerCircle(ctx, ctx.transform.position, 0.9f, Data.damage);
      yield return MoveTo(C, 0.18f);
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime*0.25f));
      base.StartRecover();
    }
    IEnumerator MoveTo(Vector3 p, float dur){
      Vector3 s = ctx.transform.position; float t=0;
      while(t<dur){ t+=Time.deltaTime; ctx.transform.position = Vector3.Lerp(s,p,t/dur); yield return null; }
    }
  }
}