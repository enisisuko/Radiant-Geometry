using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_CHROMA_LOCK : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else { done = true; }
    }
    IEnumerator Do(){
      float dur = Mathf.Max(0.5f, Data.activeTime > 0 ? Data.activeTime : 0.6f);
      float r0 = 0.5f, r1 = 8f, t = 0f; Vector3 c = ctx.transform.position;
      while (t < dur){
        t += Time.deltaTime;
        float r = Mathf.Lerp(r0, r1, t / dur);
        // damage and apply "color lock" window (handled in helpers/systems if available)
        if (BossActionHelpers.TryHitPlayerCircle(ctx, c, r, Data.damage)){
          // TODO: Integrate color lock status for ~0.8s if you have a system for it
        }
        yield return null;
      }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime * 0.25f));
      base.StartRecover();
    }
  }
}