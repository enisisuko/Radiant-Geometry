using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_SWORD_RING : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else done = true;
    }
    IEnumerator Do(){
      int hits = 6; float step=0.12f; float r=2.2f;
      for(int i=0;i<hits;i++){
        Vector3 dir = Quaternion.Euler(0, (360f/hits)*i, 0) * Vector3.forward;
        var p = ctx.transform.position + dir * r;
        BossActionHelpers.TryHitPlayerCircle(ctx, p, 0.9f, Data.damage);
        yield return new WaitForSeconds(step);
      }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime*0.25f));
      base.StartRecover();
    }
  }
}