using System.Collections.Generic;
using UnityEngine;
using FD.Bosses.C3.Data;
using FD.Bosses.C3.Actions;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace FD.Bosses.C3.Runtime
{
    /// <summary>
    /// ����ʱΪ BaseBossAction �� OrbPattern����֤ Tell һ���У��ڱ༭���ﰴ����Լ������ _TELL/_ACTIVE/_RECOVER����
    /// </summary>
    public static class C3_OrbPatternRuntimeBinder
    {
        public static void Bind(BaseBossAction action, BossActionData data)
        {
            if (action == null || data == null) return;

            // 1) ��֤ TELL һ���У����� action �Լ������ data.orbPattern
            if (action.orbPatternTell == null)
                action.orbPatternTell = data.orbPattern;

#if UNITY_EDITOR
            // 2) �� Editor �³��԰��������� _TELL/_ACTIVE/_RECOVER
            string clean = SanitizeName(data.displayName);
            string prefix = $"C3_Orb_{data.actionId}_{clean}";
            TryFill(ref action.orbPatternTell, FindBySuffix(prefix, "TELL"));
            TryFill(ref action.orbPatternActive, FindBySuffix(prefix, "ACTIVE"));
            TryFill(ref action.orbPatternRecover, FindBySuffix(prefix, "RECOVER"));
#endif
        }

        public static int BindAllInScene()
        {
            var all = FindAllActionsInScene();
            int cnt = 0;
            foreach (var a in all)
            {
                var d = a.Data;
                if (d != null) { Bind(a, d); cnt++; }
            }
            if (cnt > 0) Debug.Log($"[C3][Orbs] RuntimeBinder bound {cnt} action instance(s).");
            return cnt;
        }

        private static List<BaseBossAction> FindAllActionsInScene()
        {
            var list = new List<BaseBossAction>();
#if UNITY_2023_1_OR_NEWER
            list.AddRange(Object.FindObjectsByType<BaseBossAction>(FindObjectsSortMode.None));
#else
            list.AddRange(Object.FindObjectsOfType<BaseBossAction>(true));
#endif
            return list;
        }

#if UNITY_EDITOR
        private static string SanitizeName(string s)
        {
            if (string.IsNullOrEmpty(s)) return "NONAME";
            foreach (char c in System.IO.Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s.Replace(' ', '_');
        }

        private static OrbPatternData FindBySuffix(string prefix, string suffix)
        {
            string[] guids = AssetDatabase.FindAssets("t:FD.Bosses.C3.Data.OrbPatternData");
            OrbPatternData best = null;
            foreach (var g in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(g);
                var file = System.IO.Path.GetFileNameWithoutExtension(path);
                if (!file.Contains(prefix) || !file.Contains(suffix)) continue;
                var asset = AssetDatabase.LoadAssetAtPath<OrbPatternData>(path);
                if (!asset) continue;
                if (file.EndsWith("_" + suffix)) return asset; // ��ȷ��׺����
                best = best ?? asset;
            }
            return best;
        }

        private static void TryFill(ref OrbPatternData target, OrbPatternData cand)
        {
            if (cand) target = cand;
        }
#endif
    }
}
