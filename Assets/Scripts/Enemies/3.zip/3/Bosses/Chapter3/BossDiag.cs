// Assets/Scripts/Debug/BossDiag.cs
using UnityEngine;
using FD.Bosses.C3.Core;
using FD.Bosses.C3.Actions;

public class BossDiag : MonoBehaviour
{
    public BossChapter3Controller ctx;
    public bool logEverySecond = true;
    float t;

    void Reset() { ctx = GetComponent<BossChapter3Controller>(); }
    void Update()
    {
        if (!ctx) return;
        t += Time.deltaTime;
        if (logEverySecond && t >= 1f)
        {
            t = 0f;
            var exec = ctx.executor;
            var ai = ctx.ai;
            var fsm = ctx.fsm;
            string step = exec ? exec.ToString() : "no-exec";
            string idle = exec ? (exec.IsIdle ? "Idle" : "Busy") : "no-exec";
            string phase = ctx.phase.ToString();
            string color = ctx.color.ToString();
            string playerOk = (ctx.player || (ctx.playerProvider != null && ctx.playerProvider.PlayerTransform)) ? "player=OK" : "player=NULL";
            Debug.Log($"[BOSS-DIAG] {idle} phase={phase} color={color} {playerOk}");
        }
    }
}
