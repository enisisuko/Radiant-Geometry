using UnityEngine;
namespace FD.Bosses.C3.Integration {
  public class BossVFXRouter : MonoBehaviour {
    public void Play(string key, Vector3 pos) { /* TODO: Connect VFX Graph/PS */ }
  }
}
