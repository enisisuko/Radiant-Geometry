using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using UnityEngine;
using FD.Bosses.C3.Core;
using FD.Bosses.C3.Data;

namespace FD.Bosses.C3.Orbs
{
    public enum OrbMotion { Idle, Gather, Spread, Spin, Pulse }

    [System.Serializable]
    public struct OrbKeyframe
    {
        public float t;
        public float duration;
        public float radius;
        public float angleOffset;
        public float brightness;
        public Color color;
        public OrbMotion motion;
        public bool lockFormation;
        public int[] orbs;     // 1-based or 0-based ���ɣ��ڲ����ݴ�
        public string note;
    }

    public class OrbRingController : MonoBehaviour
    {
        [Header("Refs")]
        public List<OrbAgent> orbs = new List<OrbAgent>();

        [Header("Debug")]
        public bool debugLogs = false;

        [Header("Phase Counts")]
        [SerializeField] int p1Count = 4;
        [SerializeField] int p2Count = 6;

        [Header("Behavior")]
        [Tooltip("����Ϊ true ʱ������ͼ���ʲ��л���λ������ǿ�Ƹ��� Boss ��ǰ��λ��")]
        public bool respectAssetPhase = false;

        BossChapter3Controller _ctx;
        bool _isSixOrbs = false;
        float _defaultRadius = 2.4f;

        public void Init(BossChapter3Controller ctx)
        {
            _ctx = ctx;
            _isSixOrbs = (ctx != null && ctx.phase == BossPhase.P2);
            SetPhase(_isSixOrbs, _isSixOrbs ? 2.6f : 2.2f);
            if (debugLogs) Debug.Log("[BOSS][Orbs] Init");
        }

        public void Tick(float dt)
        {
            for (int i = 0; i < orbs.Count; i++)
                if (orbs[i]) orbs[i].Tick(dt);
        }

        public void SetPhase(bool six, float resetRadius = 2.4f)
        {
            _isSixOrbs = six;
            _defaultRadius = resetRadius;

            int want = six ? p2Count : p1Count;

            for (int i = 0; i < orbs.Count; i++)
            {
                bool active = (i < want) && orbs[i] != null;
                if (orbs[i]) orbs[i].gameObject.SetActive(active);
            }

            Transform center = _ctx ? (_ctx.modelRoot ? _ctx.modelRoot : _ctx.transform) : transform;
            for (int i = 0; i < orbs.Count; i++)
            {
                if (!orbs[i] || !orbs[i].gameObject.activeSelf) continue;
                orbs[i].ResetToIdle(center, i, six, resetRadius);
            }

            if (debugLogs) Debug.Log($"[BOSS][Orbs] SetPhase six={six} active={want}");
        }

        public void SwitchToFourOrbs() => SetPhase(false, 2.2f);
        public void SwitchToSixOrbs() => SetPhase(true, 2.6f);

        public void PreBlendColor(BossColor target, float blendTime)
        {
            Color dst = (target == BossColor.Red)
                ? new Color(1f, 0.35f, 0.35f, 1f)
                : new Color(0.35f, 1f, 0.35f, 1f);

            for (int i = 0; i < orbs.Count; i++)
                if (orbs[i] && orbs[i].gameObject.activeSelf) orbs[i].BlendColor(dst, blendTime);

            if (debugLogs) Debug.Log($"[BOSS][Orbs] PreBlendColor -> {target} ({blendTime:F2}s)");
        }

        public void ResetToIdle(Transform center, bool sixOrbs, float startRadius = 2.4f)
        {
            for (int i = 0; i < orbs.Count; i++)
                if (orbs[i] && orbs[i].gameObject.activeSelf) orbs[i].ResetToIdle(center, i, sixOrbs, startRadius);
        }

        public void ApplyPattern(OrbPatternData patternAsset)
        {
            if (!patternAsset)
            {
                if (debugLogs) Debug.LogWarning("[BOSS][Orbs] Pattern asset is null.");
                return;
            }

            // ���� ��λ��������ʽ����������ǿ�Ƹ��� Boss ��ǰ��λ
            bool bossSix = (_ctx && _ctx.phase == BossPhase.P2);
            bool wantSix = respectAssetPhase ? patternAsset.phase2SixOrbs : bossSix;
            if (wantSix != _isSixOrbs)
                SetPhase(wantSix, wantSix ? 2.6f : 2.2f);

            // ����ȡ keyframes������ public/private��
            var kfField = typeof(OrbPatternData).GetField("keyframes",
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (kfField == null) { if (debugLogs) Debug.LogWarning("[BOSS][Orbs] Pattern has no keyframes field."); return; }

            var rawArray = kfField.GetValue(patternAsset) as System.Array;
            if (rawArray == null || rawArray.Length == 0) { if (debugLogs) Debug.LogWarning("[BOSS][Orbs] Pattern empty."); return; }

            System.Type kfType = rawArray.GetType().GetElementType();
            var f_motion = kfType.GetField("motion");
            var f_duration = kfType.GetField("duration");
            var f_radius = kfType.GetField("radius");
            var f_angleOff = kfType.GetField("angleOffset");
            var f_brightness = kfType.GetField("brightness");
            var f_color = kfType.GetField("color");
            var f_orbs = kfType.GetField("orbs");
            var f_t = kfType.GetField("t");
            var f_lock = kfType.GetField("lockFormation");
            var f_note = kfType.GetField("note");

            // ��ն���
            for (int i = 0; i < orbs.Count; i++)
                if (orbs[i] && orbs[i].gameObject.activeSelf) orbs[i].ClearQueue();

            // ��ǰ����� orb ����
            var activeIdx = Enumerable.Range(0, orbs.Count)
                                      .Where(i => orbs[i] && orbs[i].gameObject.activeSelf)
                                      .ToArray();

            // === Safety: ȫ�ֶ�����ʼ֡����������û�Ե� TELL ��������һ��ģʽ������ת�� ===
            var safetyFreeze = new OrbKeyframe
            {
                t = 0f,
                duration = 0.30f,                  // ���ǵ� TELL ��ʼ����ʵ�ؼ�֡�Ḳ����
                radius = _defaultRadius,
                angleOffset = 0f,
                brightness = 0.7f,
                color = Color.white,
                motion = OrbMotion.Gather,         // �� Spin
                lockFormation = true,              // ���ᣡ
                orbs = null,                       // �ַ���ȫ��������
                note = "safety: global freeze"
            };
            foreach (var idx in activeIdx)
                if (orbs[idx] && orbs[idx].gameObject.activeInHierarchy)
                    orbs[idx].EnqueueKey(safetyFreeze);

            // �ַ���ʵ�ؼ�֡
            for (int n = 0; n < rawArray.Length; n++)
            {
                object src = rawArray.GetValue(n);

                // Motion ������δ֪һ�ɻ���Ϊ Gather����ֹ��������ȫ
                OrbMotion motion = OrbMotion.Gather;
                if (f_motion != null && f_motion.GetValue(src) is System.Enum motionEnum)
                {
                    string name = motionEnum.ToString();
                    if (!System.Enum.TryParse(name, true, out motion))
                    {
                        if (name == "Lift" || name == "Jump") motion = OrbMotion.Spread;
                        else if (name == "Drop") motion = OrbMotion.Gather;
                        else motion = OrbMotion.Gather;
                    }
                }

                var k = new OrbKeyframe
                {
                    motion = motion,
                    duration = f_duration != null && f_duration.GetValue(src) is float df ? Mathf.Max(0.05f, df) : 0.4f,
                    radius = f_radius != null && f_radius.GetValue(src) is float rf ? rf : _defaultRadius,
                    angleOffset = f_angleOff != null && f_angleOff.GetValue(src) is float af ? af : 0f,
                    brightness = f_brightness != null && f_brightness.GetValue(src) is float bf ? bf : 1f,
                    color = f_color != null && f_color.GetValue(src) is Color cf ? cf : Color.white,
                    orbs = f_orbs != null ? (int[])f_orbs.GetValue(src) : null,
                    t = f_t != null && f_t.GetValue(src) is float tf ? tf : 0f,
                    lockFormation = f_lock != null && f_lock.GetValue(src) is bool lb ? lb : false,
                    note = f_note != null && f_note.GetValue(src) is string ns ? ns : null
                };

                if (k.orbs == null || k.orbs.Length == 0)
                {
                    foreach (var i in activeIdx) orbs[i].EnqueueKey(k);
                }
                else
                {
                    foreach (var idx1 in k.orbs)
                    {
                        int zero = (idx1 >= 1 && idx1 <= 6) ? idx1 - 1 : idx1; // 1-based ����
                        if (zero < 0 || zero >= orbs.Count) continue;
                        if (orbs[zero] && orbs[zero].gameObject.activeSelf) orbs[zero].EnqueueKey(k);
                    }
                }
            }

#if UNITY_EDITOR
            int visible = activeIdx.Length, disabled = 0, zeroAlpha = 0;
            foreach (var i in activeIdx)
            {
                var o = orbs[i];
                var sr = o ? o.GetComponent<SpriteRenderer>() : null;
                if (!sr || !sr.enabled) { disabled++; continue; }
                if (sr.color.a <= 0.05f) { zeroAlpha++; continue; }
            }
            if (debugLogs) Debug.Log($"[BOSS][Orbs] Pattern={patternAsset.name} visible={visible} disabled={disabled} zeroAlpha={zeroAlpha}");
#endif
        }

    }
}
