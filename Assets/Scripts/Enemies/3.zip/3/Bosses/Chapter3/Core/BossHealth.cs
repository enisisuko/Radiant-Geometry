using UnityEngine;
using FD.Bosses.C3.Data;
using FD.Shared.Combat;

namespace FD.Bosses.C3.Core {
  public class BossHealth : MonoBehaviour, IDamageable {
    [Header("HP")]
    public int hpP1 = 1000;
    public int hpP2 = 1200;
    public float spawnInvulSeconds = 0.25f;
    public float hitInvulSeconds = 0.0f;

    public System.Action<int,int> OnDamaged;
    public System.Action<BossPhase> OnPhaseChanged;
    public System.Action OnDeath;

    BossChapter3Controller ctx;
    int hp1, hp2;
    float spawnTime, invulUntil;

    void Awake(){ ctx = GetComponent<BossChapter3Controller>(); spawnTime=Time.time; hp1=hpP1; hp2=hpP2; }
    public bool IsDead => hp1<=0 && hp2<=0;

    public void TakeDamage(float amount){
      if (Time.time - spawnTime < spawnInvulSeconds) return;
      if (Time.time < invulUntil) return;
      int dmg = Mathf.Max(0, Mathf.RoundToInt(amount)); if (dmg<=0) return;
      if (ctx.phase == BossPhase.P1){
        hp1 = Mathf.Max(0, hp1 - dmg);
        if (hp1 <= (hpP1/2) && ctx.phase==BossPhase.P1){
          ctx.phase = BossPhase.P2;
          ctx.orbRing.SwitchToSixOrbs();
          GetComponent<BossPoiseSystem>()?.SetMax(ctx.tuning.poiseP2);
          ctx.fsm.PushPhaseShift();
          OnPhaseChanged?.Invoke(BossPhase.P2);
        }
        if (hp1<=0 && hp2<=0) Die();
      } else {
        hp2 = Mathf.Max(0, hp2 - dmg);
        if (hp1<=0 && hp2<=0) Die();
      }
      invulUntil = Time.time + hitInvulSeconds;
      OnDamaged?.Invoke(dmg, hp1+hp2);
    }

    void Die(){ if (OnDeath!=null) OnDeath.Invoke(); Destroy(gameObject, 0.5f); }
  }
}
