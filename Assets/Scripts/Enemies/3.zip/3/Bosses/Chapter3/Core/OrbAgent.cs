using System.Collections.Generic;
using UnityEngine;

namespace FD.Bosses.C3.Orbs
{
    [RequireComponent(typeof(SpriteRenderer))]
    public class OrbAgent : MonoBehaviour
    {
        [Header("Orbit Speed (deg/sec)")]
        [Tooltip("P1 base speed for 4 orbs")]
        public float orbitDegPerSecP1 = 70f;
        [Tooltip("P2 base speed for 6 orbs")]
        public float orbitDegPerSecP2 = 95f;

        [Tooltip("Multiplier when in Spin motion")]
        [Range(1.0f, 1.5f)] public float spinBoost = 1.15f;

        [Tooltip("Upper cap to keep motion readable")]
        public float maxOrbitDegPerSec = 120f;

        [Header("Visuals")]
        public float minAlpha = 0.35f;           // keep visible
        public float pulseScale = 1.12f;         // Pulse scale
        public AnimationCurve ease = AnimationCurve.EaseInOut(0, 0, 1, 1);

        // runtime
        Transform _center;
        bool _isSix;
        float _angleDeg;
        float _radius;
        float _orbitSpd;
        SpriteRenderer _sr;

        // color blend
        Color _colorFrom, _colorTo;
        float _blendTime, _blendT;

        // choreo queue
        readonly Queue<OrbKeyframe> _queue = new Queue<OrbKeyframe>();
        OrbKeyframe _cur;
        float _curTime;
        bool _hasCur;

        void Awake()
        {
            _sr = GetComponent<SpriteRenderer>();
            if (_sr) _colorFrom = _colorTo = _sr.color;
        }

        public void ResetToIdle(Transform center, int index, bool sixOrbs, float startRadius)
        {
            _center = center;
            _isSix = sixOrbs;
            _radius = startRadius;

            if (sixOrbs)
                _angleDeg = 90f - 60f * index; // 90,30,-30,-90,-150,-210
            else
                _angleDeg = 90f - 90f * index; // 90,0,-90,-180

            _orbitSpd = sixOrbs ? orbitDegPerSecP2 : orbitDegPerSecP1;

            _queue.Clear();
            _hasCur = false;

            ApplyTransform(0f);
        }

        public void ClearQueue()
        {
            _queue.Clear();
            _hasCur = false;
        }

        public void EnqueueKey(OrbKeyframe kf)
        {
            if (kf.color.a < minAlpha) kf.color.a = minAlpha;
            _queue.Enqueue(kf);
        }

        public void BlendColor(Color to, float time)
        {
            if (!_sr) return;
            if (to.a < minAlpha) to.a = minAlpha;
            _colorFrom = _sr.color;
            _colorTo = to;
            _blendTime = Mathf.Max(0.01f, time);
            _blendT = 0f;
        }

        public void Tick(float dt)
        {
            // color blend
            if (_blendT < 1f && _blendTime > 0f)
            {
                _blendT = Mathf.Min(1f, _blendT + dt / _blendTime);
                var c = Color.Lerp(_colorFrom, _colorTo, _blendT);
                if (_sr) _sr.color = c;
            }

            // pull current key
            if (!_hasCur && _queue.Count > 0)
            {
                _cur = _queue.Dequeue();
                if (_cur.duration <= 0f) _cur.duration = 0.4f;
                _curTime = 0f;
                _hasCur = true;
            }

            float t01 = 0f;
            if (_hasCur)
            {
                _curTime += dt;
                t01 = Mathf.Clamp01(_curTime / Mathf.Max(0.0001f, _cur.duration));
                float e = ease.Evaluate(t01);

                // motions
                switch (_cur.motion)
                {
                    case OrbMotion.Gather:
                    case OrbMotion.Spread:
                        _radius = Mathf.Lerp(_radius, _cur.radius, e);
                        _orbitSpd = Mathf.Lerp(_orbitSpd, BaseSpeed(), 0.25f * e);
                        break;

                    case OrbMotion.Spin:
                        {
                            float target = Mathf.Min(BaseSpeed() * spinBoost, maxOrbitDegPerSec);
                            _orbitSpd = Mathf.Lerp(_orbitSpd, target, e);
                            _angleDeg += _cur.angleOffset * dt;
                            break;
                        }

                    case OrbMotion.Pulse:
                        {
                            float pulse = (Mathf.Sin(t01 * Mathf.PI) * 0.5f + 0.5f); // 0..1..0
                            _radius = Mathf.Lerp(_radius, _cur.radius, e) * Mathf.Lerp(1f, pulseScale, pulse);
                            float target = Mathf.Min(BaseSpeed() * 1.08f, maxOrbitDegPerSec);
                            _orbitSpd = Mathf.Lerp(_orbitSpd, target, 0.35f * e);
                            break;
                        }
                }

                // ����switch (_cur.motion) { �� } �ĺ��������һ�Σ�
                bool freeze = _hasCur && _cur.lockFormation; // �ؼ�֡Ҫ������
                if (freeze)
                {
                    _orbitSpd = 0f;            // ���ٶ�����
                }
           
                // orbit ���� ��ԭ���������ӽǶȵĴ���ĳɣ�����������ʱ���ƽ��Ƕ�
             
                ApplyTransform(t01);


                // color & brightness
                if (_sr)
                {
                    var c = _sr.color;
                    var tCol = _cur.color;
                    if (tCol.a < minAlpha) tCol.a = minAlpha;
                    var lerped = Color.Lerp(c, tCol, 0.65f * e);

                    // brightness drives alpha pop (>=1 keeps or raises)
                    float b = Mathf.Clamp(_cur.brightness <= 0f ? 1f : _cur.brightness, 0.5f, 1.5f);
                    float targetA = Mathf.Max(minAlpha, Mathf.Lerp(c.a, tCol.a, 0.65f * e));
                    // if b>1, gently approach 1; if b<1, approach targetA
                    float boostedA = (b >= 1f) ? Mathf.Lerp(targetA, 1f, 0.35f * (b - 1f)) : Mathf.Lerp(targetA, targetA * 0.85f, 0.5f * (1f - b));
                    lerped.a = Mathf.Clamp01(boostedA);
                    _sr.color = lerped;
                }

                if (_curTime >= _cur.duration) _hasCur = false;
            }

            // orbit
            _angleDeg += _orbitSpd * dt;
            ApplyTransform(t01);
        }

        float BaseSpeed() => _isSix ? orbitDegPerSecP2 : orbitDegPerSecP1;

        void ApplyTransform(float t01)
        {
            if (_center == null) return;
            float rad = _angleDeg * Mathf.Deg2Rad;
            Vector3 pos = _center.position + new Vector3(Mathf.Cos(rad), Mathf.Sin(rad), 0f) * _radius;
            transform.position = pos;
        }
    }
}