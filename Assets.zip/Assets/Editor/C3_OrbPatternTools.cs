﻿#if UNITY_EDITOR
using System.Linq;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using FD.Bosses.C3.Data;

public static class C3_OrbPatternTools
{
    // —— 你的项目采用“一资产三段”，运行期按 note/t/duration 切段。
    // 这个工具提供：按时长自动打 TELL/ACTIVE/RECOVER 的 note；按 t 窗口打标签；报告每个动作的主动段覆盖情况；可选把 t 正规化。

    [MenuItem("FD/Boss/OrbPatterns/Auto-Tag by Duration Timeline")]
    public static void AutoTagByDurationTimeline()
    {
        var assets = LoadAllPatterns();
        int changed = 0;
        foreach (var p in assets)
        {
            if (p.keyframes == null || p.keyframes.Length == 0) continue;

            float total = 0f;
            foreach (var k in p.keyframes) total += Mathf.Max(0.01f, k.duration);
            if (total <= 0f) continue;

            float cursor = 0f; bool any = false;
            for (int i = 0; i < p.keyframes.Length; i++)
            {
                var k = p.keyframes[i];
                float d = Mathf.Max(0.01f, k.duration);
                float mid = (cursor + d * 0.5f) / total; // 0..1

                string want = (mid < 0.34f) ? "TELL" : (mid < 0.84f ? "ACTIVE" : "RECOVER");
                if (string.IsNullOrEmpty(k.note) || !k.note.ToUpperInvariant().Contains(want))
                {
                    k.note = want;
                    p.keyframes[i] = k;
                    any = true;
                }
                cursor += d;
            }
            if (any) { EditorUtility.SetDirty(p); changed++; }
        }
        if (changed > 0) AssetDatabase.SaveAssets();
        Debug.Log($"[C3][Orbs] AutoTag by Duration Timeline — changed {changed} asset(s).");
    }

    [MenuItem("FD/Boss/OrbPatterns/Tag by T Ranges (0-0.51/0.51-0.95/0.95+)")]
    public static void TagByTRanges()
    {
        var assets = LoadAllPatterns();
        int changed = 0;
        foreach (var p in assets)
        {
            if (p.keyframes == null || p.keyframes.Length == 0) continue;

            bool any = false;
            for (int i = 0; i < p.keyframes.Length; i++)
            {
                var k = p.keyframes[i];
                string want =
                    (k.t < 0.51f) ? "TELL" :
                    (k.t < 0.95f) ? "ACTIVE" : "RECOVER";

                if (string.IsNullOrEmpty(k.note) || !k.note.ToUpperInvariant().Contains(want))
                {
                    k.note = want;
                    p.keyframes[i] = k;
                    any = true;
                }
            }
            if (any) { EditorUtility.SetDirty(p); changed++; }
        }
        if (changed > 0) AssetDatabase.SaveAssets();
        Debug.Log($"[C3][Orbs] Tag by T Ranges — changed {changed} asset(s).");
    }

    [MenuItem("FD/Boss/OrbPatterns/Normalize t by Duration (write t = cumulative)")]
    public static void NormalizeTByDuration()
    {
        var assets = LoadAllPatterns();
        int changed = 0;
        foreach (var p in assets)
        {
            if (p.keyframes == null || p.keyframes.Length == 0) continue;

            float total = 0f;
            foreach (var k in p.keyframes) total += Mathf.Max(0.01f, k.duration);
            if (total <= 0f) continue;

            float cursor = 0f; bool any = false;
            for (int i = 0; i < p.keyframes.Length; i++)
            {
                var k = p.keyframes[i];
                float d = Mathf.Max(0.01f, k.duration);
                float mid = (cursor + d * 0.5f) / total; // 0..1 normalized
                if (Mathf.Abs(k.t - mid) > 1e-3f)
                {
                    k.t = mid;
                    p.keyframes[i] = k;
                    any = true;
                }
                cursor += d;
            }
            if (any) { EditorUtility.SetDirty(p); changed++; }
        }
        if (changed > 0) AssetDatabase.SaveAssets();
        Debug.Log($"[C3][Orbs] Normalize t by Duration — changed {changed} asset(s).");
    }

    [MenuItem("FD/Boss/OrbPatterns/Report Active Coverage")]
    public static void ReportActiveCoverage()
    {
        var assets = LoadAllPatterns();
        var lines = new List<string>();
        int ok = 0, weak = 0;

        foreach (var p in assets)
        {
            int total = p.keyframes?.Length ?? 0;
            if (total == 0) continue;

            int activeByNote = 0, activeByT = 0;
            foreach (var k in p.keyframes)
            {
                if (!string.IsNullOrEmpty(k.note) && k.note.ToUpperInvariant().Contains("ACTIVE")) activeByNote++;
                if (k.t >= 0.51f && k.t < 0.95f) activeByT++;
            }

            int estActive = Mathf.Max(activeByNote, activeByT);
            bool strong = estActive >= 3;

            if (strong) ok++; else weak++;

            string name = AssetDatabase.GetAssetPath(p);
            lines.Add($"{(strong ? "✔" : "✖")} {System.IO.Path.GetFileNameWithoutExtension(name)} — ACTIVE keys: {estActive} / {total}");
        }

        Debug.Log($"[C3][Orbs] Active Coverage — OK:{ok}  WEAK:{weak}\n" + string.Join("\n", lines));
        EditorUtility.DisplayDialog("Active Coverage", $"OK:{ok}  WEAK:{weak}\n详见 Console。", "OK");
    }

    static List<OrbPatternData> LoadAllPatterns()
    {
        string[] guids = AssetDatabase.FindAssets("t:FD.Bosses.C3.Data.OrbPatternData");
        var list = new List<OrbPatternData>(guids.Length);
        foreach (var g in guids)
        {
            var path = AssetDatabase.GUIDToAssetPath(g);
            var p = AssetDatabase.LoadAssetAtPath<OrbPatternData>(path);
            if (p) list.Add(p);
        }
        return list;
    }
}
#endif
