﻿// Assets/Editor/C3_OneClickSuite.cs
// RE:Dream C3 — OneClick Suite (Editor, Cinematic Timings + Loud Tell + Validators)
// - 新增菜单：
//   1) OrbPatterns / Make Loud Tell & Assign All
//   2) Timings   / Lengthen All (Cinematic Preset)
//   3) Validate  / Validate Tell lockFormation
// - 调整默认时长为“观赏档”（更长）：TELL 0.80 / WINDUP 0.20 / ACTIVE 0.50 / RECOVER 0.50
// - 保留并增强：Rebuild、Validate 资产、Assign Holder、Tuning CSV 导入等
//
// 使用：保存后回到 Unity -> 菜单 FD/Boss (OneClick Suite)/...

#if UNITY_EDITOR
using System;
using System.Linq;
using System.IO;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using FD.Bosses.C3.Data;
using FD.Bosses.C3.Core;

namespace FD.Bosses.C3.EditorTools
{
    // 内置 Holder，避免外部依赖冲突
    public class C3ActionSetHolder : ScriptableObject
    {
        public BossActionData[] actions;
        public BossTuningData tuning;
    }

    public static class C3_OneClickSuite
    {
        // ---------- 可维护动作清单 ----------
        private static readonly ActionDef[] k_Actions = new[]
        {
            new ActionDef(101, "THRUST",            BossPhase.P1, BossColor.Red),
            new ActionDef(102, "SWEEP",             BossPhase.P1, BossColor.Red),
            new ActionDef(103, "GROUND_RING",       BossPhase.P1, BossColor.Red),
            new ActionDef(104, "SCATTER_SHOTS",     BossPhase.P1, BossColor.Green),
            new ActionDef(105, "LEAP_CLEAVE",       BossPhase.P1, BossColor.Red),
            new ActionDef(106, "DELAYED_THUNDER",   BossPhase.P1, BossColor.Green),
            new ActionDef(107, "PULL_PUSH",         BossPhase.P1, BossColor.Red),
            new ActionDef(108, "DODGE_RIPOSTE",     BossPhase.P1, BossColor.Red),
            new ActionDef(109, "TRIPLE_THRUST",     BossPhase.P1, BossColor.Red),
            new ActionDef(110, "SWORD_RING",        BossPhase.P1, BossColor.Red),

            new ActionDef(201, "FULL_RING",         BossPhase.P2, BossColor.Red),
            new ActionDef(202, "GROUND_LASER",      BossPhase.P2, BossColor.Green),
            new ActionDef(203, "RING_SIX_ARCS",     BossPhase.P2, BossColor.Green),
            new ActionDef(204, "WHIRLWIND",         BossPhase.P2, BossColor.Green),
            new ActionDef(205, "TRI_BEAM",          BossPhase.P2, BossColor.Green),
            new ActionDef(206, "PRISM_BARRAGE",     BossPhase.P2, BossColor.Green),
            new ActionDef(207, "WALL_BOUNCE_Z",     BossPhase.P2, BossColor.Red),
            new ActionDef(208, "ORB_CONVERGE_NOVA", BossPhase.P2, BossColor.Red),
            new ActionDef(209, "DOUBLE_FAN",        BossPhase.P2, BossColor.Red),
            new ActionDef(210, "GRAV_TRAP",         BossPhase.P2, BossColor.Green),
            new ActionDef(211, "CHROMA_LOCK",       BossPhase.P2, BossColor.Green),
        };

        private const int ORBS_P1 = 4;
        private const int ORBS_P2 = 6;

        // -------- 默认值（已调长为“观赏档”）--------
        private struct Defaults
        {
            public float tell, windup, active, recover;
            public int damage, poise;
            public float knockback, cooldown, range;
            public int weightClose, weightMid, weightFar;
        }

        private static readonly Defaults k_Defaults = new Defaults
        {
            tell = 0.80f,
            windup = 0.20f,
            active = 0.50f,
            recover = 0.50f,

            damage = 24,
            knockback = 1.2f,
            poise = 0,
            cooldown = 2.0f,
            weightClose = 5,
            weightMid = 5,
            weightFar = 5,
            range = 3.0f
        };

        private const string ROOT = "Assets/Boss_C3_Data";
        private const string ACTION_DIR = ROOT + "/Actions";
        private const string ORB_DIR = ROOT + "/OrbPatterns";
        private const string HOLDER_DIR = ROOT + "/Holders";
        private const string HOLDER_PATH = HOLDER_DIR + "/C3_ActionSetHolder.asset";

        // =====================================================================
        // 菜单：重建 / 校验 / 赋值 / 导入CSV / 清理
        // =====================================================================
        [MenuItem("FD/Boss (OneClick Suite)/Rebuild (Safe)")]
        public static void RebuildSafe() => RebuildInternal(false);

        [MenuItem("FD/Boss (OneClick Suite)/Rebuild (Clean Slate)")]
        public static void RebuildClean()
        {
            if (!EditorUtility.DisplayDialog("Rebuild (Clean)",
                $"这将删除并重建\n{ROOT}\n下的 Actions/OrbPatterns/Holders 内容。\n确定继续？", "继续", "取消"))
                return;
            RebuildInternal(true);
        }

        [MenuItem("FD/Boss (OneClick Suite)/Validate Assets")]
        public static void Validate()
        {
            EnsureFolders();

            var guids = AssetDatabase.FindAssets("t:BossActionData", new[] { ACTION_DIR });
            int ok = 0, warn = 0, err = 0;
            foreach (var g in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(g);
                var a = AssetDatabase.LoadAssetAtPath<BossActionData>(path);
                if (!a) { err++; Debug.LogError($"[C3/Validate] 资产加载失败: {path}"); continue; }

                var issues = new List<string>();
                if (a.actionId == 0) issues.Add("actionId 未设置");
                if (string.IsNullOrEmpty(a.displayName)) issues.Add("displayName 为空");
                if (!a.orbPattern) issues.Add("orbPattern 未绑定");
                else
                {
                    bool shouldSix = (a.phase == BossPhase.P2);
                    if (shouldSix && a.orbPattern.phase2SixOrbs == false) issues.Add("阶段=P2 期望6球，但 pattern.phase2SixOrbs=false");
                    if (!shouldSix && a.orbPattern.phase2SixOrbs == true) issues.Add("阶段=P1 期望4球，但 pattern.phase2SixOrbs=true");
                    if (a.orbPattern.keyframes == null || a.orbPattern.keyframes.Length == 0)
                        issues.Add("orbPattern.keyframes 为空");
                }

                if (issues.Count == 0) { ok++; continue; }
                if (issues.Any(x => x.Contains("失败") || x.Contains("为空"))) err++; else warn++;
                Debug.LogWarning($"[C3/Validate] {a.displayName} ({a.actionId}) @ {path}\n- {string.Join(" | ", issues)}");
            }

            var holder = LoadOrCreateHolder(autoMigrate: true, logDetail: true);
            if (!holder) { err++; Debug.LogError("[C3/Validate] Holder 资源无法创建/加载。"); }
            else
            {
                var list = holder.actions;
                if (list == null || list.Length == 0)
                {
                    list = FindAllActions();
                    if (list.Length > 0)
                    {
                        holder.actions = list;
                        EditorUtility.SetDirty(holder);
                        AssetDatabase.SaveAssets();
                        Debug.Log($"[C3/Validate] 自愈：已将 {list.Length} 个动作写入 Holder。");
                    }
                    else
                    {
                        warn++;
                        Debug.LogWarning("[C3/Validate] Holder.actions 为空（ACTION_DIR 下也未找到动作）。");
                    }
                }
                else ok++;
            }

            Debug.Log($"[C3/Validate] Done. OK={ok}, WARN={warn}, ERR={err}");
        }

        [MenuItem("FD/Boss (OneClick Suite)/Assign Holder To Selected Boss")]
        public static void AssignHolderToSelectedBoss()
        {
            var boss = Selection.activeGameObject ? Selection.activeGameObject.GetComponent<BossChapter3Controller>() : null;
            if (!boss) { EditorUtility.DisplayDialog("FD", "请在层级中选中一个 BossChapter3Controller。", "OK"); return; }

            var holder = LoadOrCreateHolder(autoMigrate: true, logDetail: true);
            if (!holder) { EditorUtility.DisplayDialog("FD", "无法创建/加载 C3ActionSetHolder（请看 Console）。", "OK"); return; }
            if (holder.actions == null || holder.actions.Length == 0)
            {
                var auto = FindAllActions();
                if (auto.Length > 0)
                {
                    holder.actions = auto.OrderBy(x => x.actionId).ToArray();
                    EditorUtility.SetDirty(holder);
                    AssetDatabase.SaveAssets();
                    Debug.Log($"[C3/Assign] 自愈：已自动填充 {holder.actions.Length} 个动作到 Holder。");
                }
            }

            if (holder.actions == null || holder.actions.Length == 0)
            {
                Debug.LogWarning("[C3/Assign] Holder 仍为空，尝试触发 RebuildSafe...");
                RebuildInternal(false);
                holder = LoadOrCreateHolder(autoMigrate: true, logDetail: true);
            }

            if (!holder || holder.actions == null || holder.actions.Length == 0)
            {
                EditorUtility.DisplayDialog("FD",
                    "未找到有效的 C3ActionSetHolder（Holder 为空且扫描不到动作）。\n请先执行 Rebuild，或查看 Console 日志。",
                    "OK");
                return;
            }

            Undo.RecordObject(boss, "Assign Holder");
            boss.actionSet = holder.actions;
            if (holder.tuning) boss.tuning = holder.tuning;
            EditorUtility.SetDirty(boss);
            Debug.Log($"[C3/Assign] 已为 {boss.name} 绑定 {holder.actions.Length} 个动作资产{(holder.tuning ? " 并绑定 Tuning" : "")}。");
        }

        [MenuItem("FD/Boss (OneClick Suite)/Import Tuning CSV (open window)")]
        public static void OpenImporterWindow() => C3CsvImporterWindow.Open();

        [MenuItem("FD/Boss (OneClick Suite)/Cleanup All Data (Delete Boss_C3_Data)")]
        public static void CleanupAll()
        {
            if (!AssetDatabase.IsValidFolder(ROOT))
            {
                Debug.Log("[C3/Cleanup] 未发现 Boss_C3_Data。");
                return;
            }
            if (!EditorUtility.DisplayDialog("Cleanup C3", $"将删除 {ROOT}（含 .meta）。确定？", "删除", "取消")) return;

            AssetDatabase.DeleteAsset(ROOT);
            AssetDatabase.Refresh();
            Debug.Log("[C3/Cleanup] Assets/Boss_C3_Data 已删除。");
        }

        [MenuItem("FD/Boss (OneClick Suite)/Consolidate (Remove Legacy Orb Folders)")]
        public static void ConsolidateLegacyOrbFolders()
        {
            var legacyRoot = "Assets/Bosses/Chapter3/Orbs";
            if (AssetDatabase.IsValidFolder(legacyRoot))
            {
                if (EditorUtility.DisplayDialog("Consolidate",
                    $"将删除旧目录：\n{legacyRoot}\n（Tell/Active/Recover）。\n确定？", "删除", "取消"))
                {
                    AssetDatabase.DeleteAsset(legacyRoot);
                    AssetDatabase.Refresh();
                    Debug.Log("[C3/Consolidate] 已移除 legacy Orbs 目录。");
                }
            }
            else Debug.Log("[C3/Consolidate] 未找到 legacy Orbs 目录。");
        }

        // =====================================================================
        // 新增：一键“显眼摆阵”TELL，并批量绑定到所有 BossActionData
        // =====================================================================
        [MenuItem("FD/Boss (OneClick Suite)/OrbPatterns/Make Loud Tell & Assign All")]
        public static void MakeLoudTellAndAssignAll()
        {
            EnsureFolders();

            var path = ORB_DIR + "/C3_Orb_TELL_LOUD.asset";
            var p = AssetDatabase.LoadAssetAtPath<OrbPatternData>(path);
            if (!p)
            {
                p = ScriptableObject.CreateInstance<OrbPatternData>();
                AssetDatabase.CreateAsset(p, path);
            }

            p.phase2SixOrbs = false; // 跟随当前相位数量，调试更直观
            p.keyframes = new OrbKeyframe[]
            {
                new OrbKeyframe{ t=0f,   duration=0.60f, lockFormation=true, brightness=0.9f, radius=2.2f, angleOffset=0f,  motion=OrbMotion.Gather, color=Color.white, orbs=new[]{0,1,2,3}, note="TELL freeze" },
                new OrbKeyframe{ t=0f,   duration=0.35f, lockFormation=true, brightness=1.0f, radius=2.6f, angleOffset=+40f, motion=OrbMotion.Gather,   color=Color.red,   orbs=new[]{0}, note="L offset" },
                new OrbKeyframe{ t=0f,   duration=0.35f, lockFormation=true, brightness=1.0f, radius=2.6f, angleOffset=-40f, motion=OrbMotion.Gather,   color=Color.red,   orbs=new[]{1}, note="R offset" },
                new OrbKeyframe{ t=0f,   duration=0.35f, lockFormation=true, brightness=1.0f, radius=3.0f, angleOffset=+15f, motion=OrbMotion.Gather,   color=Color.green, orbs=new[]{2}, note="+radius"  },
                new OrbKeyframe{ t=0f,   duration=0.35f, lockFormation=true, brightness=1.0f, radius=1.8f, angleOffset=-15f, motion=OrbMotion.Gather,   color=Color.green, orbs=new[]{3}, note="-radius"  },
                new OrbKeyframe{ t=0f,   duration=0.25f, lockFormation=true, brightness=1.0f, radius=2.4f, angleOffset=0f,  motion=OrbMotion.Gather, color=Color.white, orbs=new[]{0,1,2,3}, note="Reform" },
            };
            EditorUtility.SetDirty(p);

            int set = 0;
            string[] guids = AssetDatabase.FindAssets("t:FD.Bosses.C3.Data.BossActionData", new[] { ACTION_DIR });
            foreach (var g in guids)
            {
                string ap = AssetDatabase.GUIDToAssetPath(g);
                var data = AssetDatabase.LoadAssetAtPath<BossActionData>(ap);
                if (!data) continue;
                data.orbPattern = p;
                EditorUtility.SetDirty(data);
                set++;
            }
            AssetDatabase.SaveAssets();
            Debug.Log($"[C3/OrbPatterns] Loud Tell 已创建并绑定到 {set} 个 BossActionData：{path}");
            EditorUtility.DisplayDialog("Make Loud Tell", $"已为 {set} 个动作绑定显眼的 TELL 编舞。\n播放时预警阶段将明显摆阵。", "OK");
        }

        // =====================================================================
        // 新增：批量“拉长动作时长”（只增不减）到观赏档
        // =====================================================================
        [MenuItem("FD/Boss (OneClick Suite)/Timings/Lengthen All (Cinematic Preset)")]
        public static void LengthenAllTimings()
        {
            EnsureFolders();

            const float MIN_TELL = 0.80f;
            const float MIN_WINDUP = 0.20f;
            const float MIN_ACTIVE = 0.50f;
            const float MIN_RECOVER = 0.50f;

            int updated = 0, skipped = 0;
            string[] guids = AssetDatabase.FindAssets("t:FD.Bosses.C3.Data.BossActionData", new[] { ACTION_DIR });
            foreach (var g in guids)
            {
                string ap = AssetDatabase.GUIDToAssetPath(g);
                var data = AssetDatabase.LoadAssetAtPath<BossActionData>(ap);
                if (!data) { skipped++; continue; }

                bool changed = false;
                if (data.tellTime < MIN_TELL) { data.tellTime = MIN_TELL; changed = true; }
                if (data.windupTime < MIN_WINDUP) { data.windupTime = MIN_WINDUP; changed = true; }
                if (data.activeTime < MIN_ACTIVE) { data.activeTime = MIN_ACTIVE; changed = true; }
                if (data.recoverTime < MIN_RECOVER) { data.recoverTime = MIN_RECOVER; changed = true; }

                if (changed) { EditorUtility.SetDirty(data); updated++; } else skipped++;
            }
            AssetDatabase.SaveAssets();

            EditorUtility.DisplayDialog(
                "Lengthen Timings",
                $"完成。\n已拉长(只增不减)：{updated}\n无需调整：{skipped}\n预设：TELL≥0.80 / WINDUP≥0.20 / ACTIVE≥0.50 / RECOVER≥0.50",
                "OK"
            );
            Debug.Log($"[C3/Timings] Lengthen preset applied. Updated={updated}, Skipped={skipped}");
        }

        // =====================================================================
        // 新增：校验 TELL 首帧 lockFormation
        // =====================================================================
        [MenuItem("FD/Boss (OneClick Suite)/Validate/Validate Tell lockFormation")]
        public static void ValidateTellLock()
        {
            EnsureFolders();

            int ok = 0, bad = 0;
            var lines = new List<string>();

            string[] guids = AssetDatabase.FindAssets("t:FD.Bosses.C3.Data.BossActionData", new[] { ACTION_DIR });
            foreach (var g in guids)
            {
                string ap = AssetDatabase.GUIDToAssetPath(g);
                var data = AssetDatabase.LoadAssetAtPath<BossActionData>(ap);
                if (!data) continue;

                var p = data.orbPattern;
                if (!p || p.keyframes == null || p.keyframes.Length == 0)
                {
                    bad++; lines.Add($"✖ {data.actionId} {data.displayName} — orbPattern 缺失/空");
                    continue;
                }

                bool locked = p.keyframes[0].lockFormation;
                if (!locked) { bad++; lines.Add($"✖ {data.actionId} {data.displayName} — 首帧 lockFormation = FALSE"); }
                else ok++;
            }

            Debug.Log($"[C3/Validate] Tell lockFormation — OK:{ok}  BAD:{bad}\n" + string.Join("\n", lines));
            EditorUtility.DisplayDialog("Validate Tell lockFormation", $"OK:{ok}  BAD:{bad}\n详情查看 Console。", "OK");
        }

        // =====================================================================
        // 重建实现（基于更长默认时长）
        // =====================================================================
        private static void RebuildInternal(bool clearFolders)
        {
            EnsureFolders();
            try
            {
                AssetDatabase.StartAssetEditing();

                if (clearFolders)
                {
                    DeleteAllUnder(ACTION_DIR);
                    DeleteAllUnder(ORB_DIR);
                    DeleteAllUnder(HOLDER_DIR);
                }

                var createdActions = new List<BossActionData>();
                foreach (var def in k_Actions)
                {
                    try
                    {
                        var a = CreateOrUpdateAction(def, out _);
                        var pat = CreateOrUpdatePattern(def);
                        a.orbPattern = pat;
                        EditorUtility.SetDirty(a);
                        createdActions.Add(a);
                    }
                    catch (Exception ex)
                    {
                        Debug.LogError($"[C3/Rebuild] 构建 {def.displayName} 失败：{ex.Message}\n{ex.StackTrace}");
                    }
                }

                var holder = LoadOrCreateHolder(autoMigrate: true, logDetail: true);
                if (holder)
                {
                    holder.actions = createdActions.OrderBy(x => x.actionId).ToArray();
                    if (!holder.tuning)
                    {
                        var g = AssetDatabase.FindAssets("t:BossTuningData").FirstOrDefault();
                        if (!string.IsNullOrEmpty(g))
                            holder.tuning = AssetDatabase.LoadAssetAtPath<BossTuningData>(AssetDatabase.GUIDToAssetPath(g));
                    }
                    EditorUtility.SetDirty(holder);
                }
                else
                {
                    Debug.LogError("[C3/Rebuild] Holder 创建/加载失败，已跳过赋值。");
                }
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
            }

            EditorUtility.DisplayDialog("C3 Rebuild", "重建完成。已生成/更新动作与编舞，并写入 Holder。", "OK");
            Validate();
        }

        private static void EnsureFolders()
        {
            if (!AssetDatabase.IsValidFolder(ROOT)) AssetDatabase.CreateFolder("Assets", "Boss_C3_Data");
            if (!AssetDatabase.IsValidFolder(ACTION_DIR)) AssetDatabase.CreateFolder(ROOT, "Actions");
            if (!AssetDatabase.IsValidFolder(ORB_DIR)) AssetDatabase.CreateFolder(ROOT, "OrbPatterns");
            if (!AssetDatabase.IsValidFolder(HOLDER_DIR)) AssetDatabase.CreateFolder(ROOT, "Holders");
        }

        private static void DeleteAllUnder(string folder)
        {
            var guids = AssetDatabase.FindAssets("", new[] { folder });
            foreach (var g in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(g);
                AssetDatabase.DeleteAsset(path);
            }
        }

        private static string Sanitize(string name)
        {
            foreach (var c in Path.GetInvalidFileNameChars())
                name = name.Replace(c.ToString(), "_");
            return name;
        }

        private static BossActionData CreateOrUpdateAction(ActionDef def, out bool wasCreated)
        {
            wasCreated = false;
            var fileName = $"C3_Action_{Sanitize(def.displayName)}.asset";
            var path = $"{ACTION_DIR}/{fileName}";
            var a = AssetDatabase.LoadAssetAtPath<BossActionData>(path);
            if (!a)
            {
                a = ScriptableObject.CreateInstance<BossActionData>();
                AssetDatabase.CreateAsset(a, path);
                wasCreated = true;
            }

            a.actionId = def.id;
            a.displayName = def.displayName;
            a.phase = def.phase;
            a.color = def.color;

            // 采用更长默认时长
            a.tellTime = k_Defaults.tell;
            a.windupTime = k_Defaults.windup;
            a.activeTime = k_Defaults.active;
            a.recoverTime = k_Defaults.recover;

            a.damage = k_Defaults.damage;
            a.knockback = k_Defaults.knockback;
            a.poiseDamage = k_Defaults.poise;

            a.cooldown = k_Defaults.cooldown;
            a.weightClose = k_Defaults.weightClose;
            a.weightMid = k_Defaults.weightMid;
            a.weightFar = k_Defaults.weightFar;

            a.range = k_Defaults.range;
            a.faceTargetDuringActive = true;
            a.hitboxType = HitboxType.Capsule;

            a.designNotes = $"OneClickSuite built at {DateTime.Now:yyyy-MM-dd HH:mm:ss}\nPhase={def.phase} Color={def.color}";
            return a;
        }

        private static OrbPatternData CreateOrUpdatePattern(ActionDef def)
        {
            var fileName = $"C3_Orb_{Sanitize(def.displayName)}.asset";
            var path = $"{ORB_DIR}/{fileName}";
            var p = AssetDatabase.LoadAssetAtPath<OrbPatternData>(path);
            if (!p)
            {
                p = ScriptableObject.CreateInstance<OrbPatternData>();
                AssetDatabase.CreateAsset(p, path);
            }

            p.phase2SixOrbs = (def.phase == BossPhase.P2);
            p.keyframes = BuildPatternForAction(def).ToArray();

            EditorUtility.SetDirty(p);
            return p;
        }

        // =====================================================================
        // 编舞生成（各动作差异化，TELL 默认含停阵/分组/提示脉冲；时序与观赏档吻合）
        // =====================================================================
        private static IEnumerable<OrbKeyframe> BuildPatternForAction(ActionDef def)
        {
            int orbCount = OrbCountByPhase(def.phase);
            float baseR = (def.phase == BossPhase.P2) ? 2.4f : 2.0f;
            var cMain = def.color == BossColor.Red ? new Color(1.0f, 0.35f, 0.30f) : new Color(0.35f, 1.0f, 0.50f);
            var cAlt = def.color == BossColor.Red ? new Color(0.35f, 1.0f, 0.50f) : new Color(1.0f, 0.35f, 0.30f);
            int[] all = Enumerable.Range(0, orbCount).ToArray();

            // TELL：停阵 -> 紧缩 -> 心跳 -> 提示脉冲
            yield return Kf(0.00f, all, OrbMotion.Gather, baseR * 1.00f, 0f, 0.24f, cMain, 0.55f, true, "tell: freeze+glow");
            yield return Kf(0.24f, all, OrbMotion.Gather, baseR * 0.92f, 0f, 0.12f, cMain, 0.75f, true, "tell: tighten");
            yield return Kf(0.36f, all, OrbMotion.Gather, baseR * 0.80f, 0f, 0.15f, cMain, 0.85f, true, "tell: heartbeat");
            yield return Kf(0.51f, all, OrbMotion.Pulse, baseR * 0.85f, 0f, 0.06f, cMain, 1.00f, true, "cue: pulse");

            switch (def.displayName)
            {
                // —— 以下为各动作独立分镜（与原版一致，但更“显眼”）——
                case "SWEEP":
                    {
                        var (left, right) = SplitLR(orbCount);
                        yield return Kf(0.51f, left, OrbMotion.StretchLine, baseR * 1.05f, -30f, 0.10f, cMain, 0.95f, true, "windup L");
                        yield return Kf(0.58f, right, OrbMotion.StretchLine, baseR * 1.05f, 30f, 0.10f, cMain, 0.95f, true, "windup R");
                        yield return Kf(0.68f, left, OrbMotion.StretchLine, baseR * 1.30f, 90f, 0.18f, cMain, 1.00f, true, "sweep L");
                        yield return Kf(0.77f, right, OrbMotion.StretchLine, baseR * 1.30f, -90f, 0.18f, cMain, 1.00f, true, "sweep R");
                        yield return Kf(0.92f, all, OrbMotion.Gather, baseR * 0.90f, 0f, 0.10f, cMain, 0.70f, false, "recover");
                        break;
                    }
                case "THRUST":
                    {
                        var front = FrontHalf(orbCount);
                        Stagger(front, 0.51f, 0.04f, (i, t) => Kf(t, new[] { i }, OrbMotion.Gather, baseR * 0.70f, 0f, 0.06f, cMain, 0.95f, true, $"queue {i}"));
                        Stagger(front, 0.63f, 0.05f, (i, t) => Kf(t, new[] { i }, OrbMotion.StretchLine, baseR * 1.20f, 0f, 0.12f, cMain, 1.00f, true, $"lunge {i}"));
                        yield return Kf(0.82f, front, OrbMotion.Gather, baseR * 0.85f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                case "TRIPLE_THRUST":
                    {
                        var seq = FrontHalf(orbCount);
                        Stagger(seq, 0.51f, 0.03f, (i, t) => Kf(t, new[] { i }, OrbMotion.StretchLine, baseR * 1.15f, 0f, 0.10f, cMain, 0.95f, true, "thrust#1"));
                        Stagger(seq, 0.64f, 0.03f, (i, t) => Kf(t, new[] { i }, OrbMotion.StretchLine, baseR * 1.25f, 0f, 0.10f, cMain, 1.00f, true, "thrust#2"));
                        Stagger(seq, 0.77f, 0.03f, (i, t) => Kf(t, new[] { i }, OrbMotion.StretchLine, baseR * 1.35f, 0f, 0.12f, cMain, 1.00f, true, "thrust#3"));
                        yield return Kf(0.90f, all, OrbMotion.Pulse, baseR * 0.95f, 0f, 0.08f, cMain, 0.75f, false, "recover");
                        break;
                    }
                case "LEAP_CLEAVE":
                    {
                        yield return Kf(0.51f, all, OrbMotion.Lift, baseR * 0.90f, 0f, 0.10f, cMain, 0.95f, true, "lift");
                        yield return Kf(0.61f, all, OrbMotion.Drop, baseR * 0.80f, 0f, 0.08f, cMain, 1.00f, true, "drop");
                        yield return Kf(0.69f, all, OrbMotion.Spread, baseR * 1.35f, 0f, 0.20f, cMain, 1.00f, true, "impact");
                        yield return Kf(0.89f, all, OrbMotion.Spin, baseR * 1.10f, 0f, 0.08f, cMain, 0.70f, false, "afterglow");
                        break;
                    }
                case "SWORD_RING":
                case "FULL_RING":
                    {
                        var order = all;
                        Stagger(order, 0.52f, 0.06f, (i, t) => Kf(t, new[] { i }, OrbMotion.StretchLine, baseR * 1.18f, 0f, 0.12f, cMain, 1.00f, true, $"stab {i}"));
                        yield return Kf(0.90f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                case "DODGE_RIPOSTE":
                    {
                        var side = RightHalf(orbCount);
                        yield return Kf(0.51f, side, OrbMotion.Spin, baseR * 1.05f, 0f, 0.10f, cAlt, 0.95f, false, "hint side");
                        yield return Kf(0.61f, all, OrbMotion.Jump, baseR * 0.90f, 0f, 0.08f, cMain, 1.00f, true, "dodge");
                        yield return Kf(0.70f, Opposite(side, orbCount), OrbMotion.StretchLine, baseR * 1.28f, 0f, 0.18f, cMain, 1.00f, true, "riposte");
                        yield return Kf(0.90f, all, OrbMotion.Spin, baseR, 0f, 0.08f, cMain, 0.70f, false, "recover");
                        break;
                    }
                case "DOUBLE_FAN":
                    {
                        var (left, right) = SplitLR(orbCount);
                        yield return Kf(0.51f, left, OrbMotion.StretchLine, baseR * 1.05f, -25f, 0.12f, cMain, 0.95f, true, "windup L");
                        yield return Kf(0.63f, left, OrbMotion.StretchLine, baseR * 1.30f, 95f, 0.18f, cMain, 1.00f, true, "sweep L");
                        yield return Kf(0.70f, right, OrbMotion.StretchLine, baseR * 1.05f, 25f, 0.12f, cMain, 0.95f, true, "windup R");
                        yield return Kf(0.82f, right, OrbMotion.StretchLine, baseR * 1.30f, -95f, 0.18f, cMain, 1.00f, true, "sweep R");
                        yield return Kf(1.00f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                case "WALL_BOUNCE_Z":
                    {
                        var (left, right) = SplitLR(orbCount);
                        yield return Kf(0.51f, left, OrbMotion.StretchLine, baseR, -35f, 0.10f, cMain, 0.95f, true, "mark L");
                        yield return Kf(0.51f, right, OrbMotion.StretchLine, baseR, 35f, 0.10f, cMain, 0.95f, true, "mark R");
                        yield return Kf(0.62f, all, OrbMotion.StretchLine, baseR * 1.12f, 60f, 0.10f, cMain, 1.00f, true, "dash#1");
                        yield return Kf(0.72f, all, OrbMotion.StretchLine, baseR * 1.22f, -60f, 0.12f, cMain, 1.00f, true, "dash#2");
                        yield return Kf(0.84f, all, OrbMotion.StretchLine, baseR * 1.32f, 20f, 0.14f, cMain, 1.00f, true, "dash#3");
                        yield return Kf(1.00f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                case "SCATTER_SHOTS":
                    {
                        yield return Kf(0.51f, all, OrbMotion.Spin, baseR, 0f, 0.12f, cMain, 0.95f, false, "spin up");
                        yield return Kf(0.63f, all, OrbMotion.StretchLine, baseR * 1.18f, -20f, 0.12f, cMain, 1.00f, true, "fan A");
                        yield return Kf(0.75f, all, OrbMotion.StretchLine, baseR * 1.22f, 20f, 0.12f, cMain, 1.00f, true, "fan B");
                        yield return Kf(0.90f, all, OrbMotion.Spin, baseR, 0f, 0.08f, cMain, 0.70f, false, "recover");
                        break;
                    }
                case "WHIRLWIND":
                    {
                        yield return Kf(0.51f, all, OrbMotion.Spin, baseR * 0.85f, 0f, 0.12f, cMain, 0.95f, true, "spin compress");
                        yield return Kf(0.63f, all, OrbMotion.Pulse, baseR * 0.95f, 0f, 0.08f, cMain, 1.00f, true, "core flash");
                        yield return Kf(0.71f, all, OrbMotion.Spread, baseR * 1.30f, 0f, 0.22f, cMain, 1.00f, true, "whirl out");
                        Stagger(all.Reverse().ToArray(), 0.93f, 0.04f, (i, t) =>
                            Kf(t, new[] { i }, OrbMotion.Gather, baseR * 0.95f, 0f, 0.06f, cMain, 0.70f, true, $"settle {i}"));
                        break;
                    }
                case "GROUND_LASER":
                    {
                        var bottom = BottomHalf(orbCount);
                        yield return Kf(0.51f, bottom, OrbMotion.StretchLine, baseR * 0.95f, 0f, 0.12f, cMain, 0.95f, true, "line up");
                        yield return Kf(0.63f, bottom, OrbMotion.HexFlower, baseR * 1.20f, 0f, 0.22f, cMain, 1.00f, true, "ground arcs");
                        yield return Kf(0.88f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                case "TRI_BEAM":
                    {
                        var tri = TriangleGroup(orbCount);
                        yield return Kf(0.51f, tri, OrbMotion.Triangle, baseR * 0.85f, 0f, 0.16f, cMain, 0.95f, true, "triangle focus");
                        yield return Kf(0.67f, tri, OrbMotion.Pulse, baseR * 1.05f, 0f, 0.18f, cMain, 1.00f, true, "beam pulse");
                        Stagger(tri, 0.85f, 0.05f, (i, t) => Kf(t, new[] { i }, OrbMotion.Drop, baseR * 0.92f, 0f, 0.07f, cMain, 0.70f, true, $"ember {i}"));
                        break;
                    }
                case "RING_SIX_ARCS":
                    {
                        yield return Kf(0.51f, all, OrbMotion.Spin, baseR, 0f, 0.12f, cMain, 0.95f, false, "spin up");
                        yield return Kf(0.63f, all, OrbMotion.HexFlower, baseR * 1.25f, 0f, 0.26f, cMain, 1.00f, true, "six-petal burst");
                        yield return Kf(0.92f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                case "PRISM_BARRAGE":
                    {
                        yield return Kf(0.48f, all, OrbMotion.Spin, baseR, 0f, 0.06f, cAlt, 0.85f, false, "cadence alt");
                        yield return Kf(0.54f, all, OrbMotion.Spin, baseR, 0f, 0.06f, cMain, 0.95f, false, "cadence main");
                        yield return Kf(0.60f, all, OrbMotion.StretchLine, baseR * 1.18f, -18f, 0.12f, cMain, 1.00f, true, "fan A");
                        yield return Kf(0.72f, all, OrbMotion.StretchLine, baseR * 1.22f, 18f, 0.12f, cMain, 1.00f, true, "fan B");
                        yield return Kf(0.84f, all, OrbMotion.Spread, baseR * 1.30f, 0f, 0.14f, cMain, 1.00f, true, "close stabs");
                        yield return Kf(1.00f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                case "GRAV_TRAP":
                    {
                        var pair = PairOpposites(orbCount);
                        yield return Kf(0.51f, pair, OrbMotion.Lift, baseR * 0.95f, 0f, 0.12f, cMain, 0.95f, true, "hover pair");
                        yield return Kf(0.63f, pair, OrbMotion.Spin, baseR * 0.90f, 0f, 0.18f, cMain, 1.00f, true, "attract swirl");
                        yield return Kf(0.81f, pair, OrbMotion.Spread, baseR * 1.30f, 0f, 0.16f, cMain, 1.00f, true, "detonate split");
                        yield return Kf(0.97f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                case "DELAYED_THUNDER":
                    {
                        var top = TopOne(orbCount);
                        yield return Kf(0.51f, top, OrbMotion.Lift, baseR * 0.90f, 0f, 0.14f, cMain, 0.95f, true, "marker");
                        yield return Kf(0.65f, top, OrbMotion.Drop, baseR * 0.80f, 0f, 0.08f, cMain, 1.00f, true, "drop");
                        yield return Kf(0.73f, all, OrbMotion.HexFlower, baseR * 1.20f, 0f, 0.20f, cMain, 1.00f, true, "ground ring");
                        yield return Kf(0.93f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                case "CHROMA_LOCK":
                    {
                        yield return Kf(0.51f, all, OrbMotion.Spin, baseR * 0.78f, 0f, 0.16f, cMain, 0.95f, true, "swirl");
                        yield return Kf(0.67f, all, OrbMotion.Pulse, baseR * 1.05f, 0f, 0.10f, cMain, 1.00f, true, "pulse#1");
                        yield return Kf(0.79f, all, OrbMotion.Pulse, baseR * 1.12f, 0f, 0.12f, cMain, 1.00f, true, "pulse#2");
                        yield return Kf(0.95f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
                default:
                    {
                        yield return Kf(0.51f, all, OrbMotion.Gather, baseR * 0.82f, 0f, 0.10f, cMain, 0.95f, true, "windup");
                        yield return Kf(0.61f, all, OrbMotion.Spread, baseR * 1.22f, 15f, 0.18f, cMain, 1.00f, true, "active");
                        yield return Kf(0.82f, all, OrbMotion.Gather, baseR * 0.95f, 0f, 0.08f, cMain, 0.70f, true, "recover");
                        break;
                    }
            }
        }

        // =====================================================================
        // CSV 导入窗口（保留）
        // =====================================================================
        private class C3CsvImporterWindow : EditorWindow
        {
            [Serializable]
            private class Row
            {
                public int actionId;
                public string name, phase, color;
                public float tellTime, windupTime, activeTime, recoverTime, damage;
                public float aiWeightClose, aiWeightFar;
            }

            TextAsset csvAsset;
            string searchFolder = ACTION_DIR;
            bool dryRun = false;

            public static void Open()
            {
                var w = GetWindow<C3CsvImporterWindow>("C3 Action Tuning");
                w.minSize = new Vector2(560, 220);
                w.Show();
            }

            void OnGUI()
            {
                GUILayout.Label("Boss C3 Action Tuning Importer", EditorStyles.boldLabel);
                csvAsset = (TextAsset)EditorGUILayout.ObjectField("CSV (TextAsset)", csvAsset, typeof(TextAsset), false);
                searchFolder = EditorGUILayout.TextField("Search Folder", searchFolder);
                dryRun = EditorGUILayout.Toggle(new GUIContent("Dry Run (no write)"), dryRun);

                if (GUILayout.Button("Import Now", GUILayout.Height(32)))
                {
                    if (!csvAsset) { EditorUtility.DisplayDialog("Importer", "Please assign the CSV TextAsset.", "OK"); return; }
                    Import(csvAsset, searchFolder, dryRun);
                }
            }

            private static void Import(TextAsset csv, string rootFolder, bool dryRun)
            {
                var dict = Parse(csv.text);
                int updated = 0, skipped = 0;
                string[] guids = AssetDatabase.FindAssets("t:BossActionData", new[] { rootFolder });

                foreach (var g in guids)
                {
                    string path = AssetDatabase.GUIDToAssetPath(g);
                    var data = AssetDatabase.LoadAssetAtPath<BossActionData>(path);
                    if (!data) { skipped++; continue; }

                    var so = new SerializedObject(data);
                    var pId = so.FindProperty("actionId");
                    if (pId == null) { Debug.LogWarning($"[Tuning] {path} has no actionId field."); skipped++; continue; }
                    if (!dict.TryGetValue(pId.intValue, out var row)) { skipped++; continue; }

                    SetNumber(so, data, "tellTime", row.tellTime);
                    SetNumber(so, data, "windupTime", row.windupTime);
                    SetNumber(so, data, "activeTime", row.activeTime);
                    SetNumber(so, data, "recoverTime", row.recoverTime);
                    SetNumber(so, data, "damage", row.damage);

                    SetNumber(so, data, "weightClose", row.aiWeightClose);
                    SetNumber(so, data, "weightFar", row.aiWeightFar);
                    SetNumber(so, data, "weightMid", (row.aiWeightClose + row.aiWeightFar) * 0.5f);

                    var pColor = so.FindProperty("color");
                    if (pColor != null && pColor.propertyType == SerializedPropertyType.Enum)
                    {
                        int idx = pColor.enumValueIndex;
                        if (string.Equals(row.color, "Red", StringComparison.OrdinalIgnoreCase)) idx = 0;
                        else if (string.Equals(row.color, "Green", StringComparison.OrdinalIgnoreCase)) idx = 1;
                        pColor.enumValueIndex = idx;
                    }
                    else
                    {
                        TrySetEnumByName(data, "color", row.color);
                    }

                    if (!dryRun)
                    {
                        so.ApplyModifiedProperties();
                        EditorUtility.SetDirty(data);
                    }
                    updated++;
                }

                if (!dryRun) AssetDatabase.SaveAssets();
                EditorUtility.DisplayDialog("Importer", $"Done.\nUpdated: {updated}\nSkipped: {skipped}\nDryRun: {dryRun}", "OK");
            }

            private static Dictionary<int, Row> Parse(string csv)
            {
                var dict = new Dictionary<int, Row>();
                using (var reader = new StringReader(csv))
                {
                    string line = reader.ReadLine(); // header
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        var cols = line.Split(',');
                        if (cols.Length < 11) continue;

                        var r = new Row
                        {
                            actionId = ToInt(cols[0]),
                            name = cols[1].Trim(),
                            phase = cols[2].Trim(),
                            color = cols[3].Trim(),
                            tellTime = ToF(cols[4]),
                            windupTime = ToF(cols[5]),
                            activeTime = ToF(cols[6]),
                            recoverTime = ToF(cols[7]),
                            damage = ToF(cols[8]),
                            aiWeightClose = ToF(cols[9]),
                            aiWeightFar = ToF(cols[10])
                        };
                        dict[r.actionId] = r;
                    }
                }
                return dict;
            }

            private static int ToInt(string s) { int.TryParse(s.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var v); return v; }
            private static float ToF(string s) { float.TryParse(s.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var v); return v; }

            private static void SetNumber(SerializedObject so, UnityEngine.Object obj, string fieldName, float value)
            {
                var p = so.FindProperty(fieldName);
                if (p != null)
                {
                    switch (p.propertyType)
                    {
                        case SerializedPropertyType.Float: p.floatValue = value; return;
                        case SerializedPropertyType.Integer: p.intValue = Mathf.RoundToInt(value); return;
                    }
                }
                var t = obj.GetType();
                var f = t.GetField(fieldName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (f != null)
                {
                    if (f.FieldType == typeof(float)) f.SetValue(obj, value);
                    else if (f.FieldType == typeof(int)) f.SetValue(obj, Mathf.RoundToInt(value));
                    else if (f.FieldType == typeof(double)) f.SetValue(obj, (double)value);
                    else if (f.FieldType == typeof(decimal)) f.SetValue(obj, (decimal)value);
                }
            }

            private static void TrySetEnumByName(UnityEngine.Object obj, string fieldName, string enumName)
            {
                var t = obj.GetType();
                var f = t.GetField(fieldName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                if (f == null) return;
                var ft = f.FieldType;
                if (!ft.IsEnum) return;
                try { var val = Enum.Parse(ft, enumName, true); f.SetValue(obj, val); }
                catch { }
            }
        }

        // =====================================================================
        // 小工具 & 数据结构
        // =====================================================================
        private static int OrbCountByPhase(BossPhase p) => p == BossPhase.P1 ? ORBS_P1 : ORBS_P2;

        private static (int[] left, int[] right) SplitLR(int orbCount)
        {
            var left = new List<int>(); var right = new List<int>();
            for (int i = 0; i < orbCount; i++) ((i % 2) == 0 ? left : right).Add(i);
            return (left.ToArray(), right.ToArray());
        }
        private static int[] FrontHalf(int orbCount) { int n = Math.Max(1, orbCount / 2); return Enumerable.Range(0, n).ToArray(); }
        private static int[] RightHalf(int orbCount) { var list = new List<int>(); for (int i = 0; i < orbCount; i++) if ((i % 2) == 1) list.Add(i); return list.ToArray(); }
        private static int[] BottomHalf(int orbCount) => Enumerable.Range(orbCount / 2, orbCount - orbCount / 2).ToArray();
        private static int[] TopOne(int orbCount) => new[] { 0 };
        private static int[] Opposite(int[] subset, int orbCount) => subset.Select(i => (i + orbCount / 2) % orbCount).Distinct().ToArray();
        private static int[] PairOpposites(int orbCount) => orbCount < 2 ? new[] { 0 } : new[] { 0, orbCount / 2 };
        private static int[] TriangleGroup(int orbCount)
        {
            if (orbCount <= 3) return Enumerable.Range(0, orbCount).ToArray();
            int step = Math.Max(1, orbCount / 3);
            return new[] { 0, step % orbCount, (2 * step) % orbCount };
        }
        private static void Stagger(int[] order, float t0, float dt, Action<int, float> emit)
        { for (int i = 0; i < order.Length; i++) emit(order[i], t0 + dt * i); }

        private static OrbKeyframe Kf(float t, int[] orbs, OrbMotion motion, float radius, float angle, float dur, Color color, float b, bool lockForm, string note)
            => new OrbKeyframe { t = t, orbs = orbs, motion = motion, radius = radius, angleOffset = angle, duration = dur, color = color, brightness = b, lockFormation = lockForm, note = note };

        private static C3ActionSetHolder LoadOrCreateHolder(bool autoMigrate, bool logDetail)
        {
            EnsureFolders();

            var obj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(HOLDER_PATH);
            var holder = obj as C3ActionSetHolder;

            if (!holder && obj != null && autoMigrate)
            {
                var legacyType = obj.GetType();
                FieldInfo fActions = legacyType.GetField("actions");
                FieldInfo fTuning = legacyType.GetField("tuning");
                BossActionData[] legacyActions = null;
                BossTuningData legacyTuning = null;

                try
                {
                    if (fActions != null) legacyActions = fActions.GetValue(obj) as BossActionData[];
                    if (fTuning != null) legacyTuning = fTuning.GetValue(obj) as BossTuningData;
                }
                catch { /* ignore reflection issues */ }

                string bak = AssetDatabase.GenerateUniqueAssetPath(HOLDER_DIR + "/C3_ActionSetHolder_Legacy.asset");
                AssetDatabase.MoveAsset(HOLDER_PATH, bak);
                if (logDetail) Debug.Log($"[C3/Holder] 已备份旧 Holder: {bak}");

                holder = ScriptableObject.CreateInstance<C3ActionSetHolder>();
                AssetDatabase.CreateAsset(holder, HOLDER_PATH);

                if (legacyActions != null && legacyActions.Length > 0) holder.actions = legacyActions;
                if (legacyTuning) holder.tuning = legacyTuning;

                EditorUtility.SetDirty(holder);
                AssetDatabase.SaveAssets();
                if (logDetail) Debug.Log($"[C3/Holder] 已新建 C3ActionSetHolder 并迁移旧数据（动作数={holder.actions?.Length ?? 0}）。");
            }

            if (!holder)
            {
                holder = AssetDatabase.LoadAssetAtPath<C3ActionSetHolder>(HOLDER_PATH);
                if (!holder)
                {
                    holder = ScriptableObject.CreateInstance<C3ActionSetHolder>();
                    AssetDatabase.CreateAsset(holder, HOLDER_PATH);
                    AssetDatabase.SaveAssets();
                    if (logDetail) Debug.Log("[C3/Holder] 已新建空的 C3ActionSetHolder。");
                }
            }

            return holder;
        }

        private static BossActionData[] FindAllActions()
        {
            BossActionData[] From(string folder)
            {
                var ids = AssetDatabase.FindAssets("t:BossActionData", new[] { folder });
                return ids.Select(g => AssetDatabase.LoadAssetAtPath<BossActionData>(AssetDatabase.GUIDToAssetPath(g)))
                          .Where(a => a != null).ToArray();
            }
            var list = From(ACTION_DIR);
            if (list.Length == 0) list = From("Assets");
            return list.OrderBy(a => a.actionId).ToArray();
        }

        private struct ActionDef
        {
            public int id; public string displayName; public BossPhase phase; public BossColor color;
            public ActionDef(int id, string name, BossPhase p, BossColor c) { this.id = id; this.displayName = name; this.phase = p; this.color = c; }
        }
    }
}
#endif
