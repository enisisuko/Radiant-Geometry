ChapterManager.cs

类名：ChapterManager，继承自MonoBehaviour

功能概述：提供与关卡章节相关的全局帮助方法。该类包含一个静态方法，根据当前场景名称返回章节编号，用于决定游戏逻辑所处的章节。【浏览器源】

公开接口：

public static int ChapterFromScene()：获取当前激活场景名称中的章节编号。通过匹配场景名称中的“chapter1”、“chapter2”等关键字返回对应的整数编号。如果没有匹配，则默认返回1。

Unity 生命周期方法：无（不包含Awake/Start/Update/OnEnable/OnDisable等）

字段/属性：无公开字段或带[SerializeField]私有字段（该脚本只有一个静态方法，未定义实例字段）。

脚本关联：该方法使用了SceneManager.GetActiveScene()获取场景信息。其他脚本可调用ChapterManager.ChapterFromScene()以获取当前章节索引。

Checkpoint.cs

类名：Checkpoint，继承自MonoBehaviour

功能概述：用于定义检查点对象。当玩家触发此检查点时，可以复位玩家位置或记录检查点ID。通常用于场景开始时、玩家死亡重生或继续游戏时将玩家放置在此位置。

外部接口：

public string Id { get; }：只读属性，返回检查点的唯一标识符。优先返回idOverride字段（如果非空），否则返回当前GameObject的name。

public void SpawnPlayerHere()：将玩家传送到此检查点的位置上（使用GameObject.FindGameObjectWithTag("Player")找到玩家并设置其位置）。该方法也可在检查点重生时调用。

Unity 生命周期方法：

private void OnTriggerEnter2D(Collider2D other)：当有碰撞器进入此检查点触发器时触发。如果碰撞体标签是“Player”且activateOnStart为false，则调用SpawnPlayerHere()将玩家移动到检查点。

（备注：源码中存在activateOnStart字段，可能在Start()方法中判断是否立即激活，但当前代码显示检测在触发时处理。）

字段/属性：

类型	名称	描述	Inspector暴露
[SerializeField] private string	idOverride	检查点ID的可选覆盖；若为空则使用物体名称作为ID。带[Tooltip]提供说明。	是（私有，SerializeField）
public bool	activateOnStart	是否在场景加载开始时自动激活此检查点（如果为真，则会在Start时重置玩家位置）。带[Tooltip]说明。	是（公有）
public string	Id（只读属性）	返回有效的检查点ID（优先idOverride，否则为物体名称）。无Setter。	否（属性）

脚本关联：

通过GameObject.FindGameObjectWithTag("Player")查找玩家对象，并使用Transform.position移动玩家。

调用了FadedDreams.Player命名空间（与玩家控制类关联）。

activateOnStart字段提示可能在场景开始时主动调用SpawnPlayerHere()，但源码当前侧重于触发器触发。

GameManager.cs

类名：GameManager，继承自Singleton<GameManager>（单例泛型基类）

功能概述：全局管理器，保持游戏的高层状态（例如当前章节、当前检查点ID）。它提供设置章节和检查点的方法，并在玩家死亡时处理重生逻辑。

外部接口：

属性

public int CurrentChapter { get; private set; }：当前章节编号，只读对外（私有setter）。

public string CurrentCheckpointId { get; private set; }：当前检查点ID，只读对外。

方法

public void SetChapter(int chapter)：设置当前章节编号（更新CurrentChapter）。

public void SetCheckpoint(string checkpointId)：设置当前检查点ID，并调用SaveSystem.Instance.SaveCheckpoint(checkpointId)将其存储。

public void OnPlayerDeath()：玩家死亡时调用，内部会通过SceneLoader.ReloadAtLastCheckpoint()来重新加载最后记录的检查点位置。

Unity 生命周期方法：继承自Singleton<T>，可能在Awake()中由基类自动保证单例（基类中有protected override void Awake()）。

字段/属性：

类型	名称	描述	Inspector暴露
public int	CurrentChapter	当前章节编号，游戏启动时默认为1（设置章节后可能更新）。私有Setter。	是（公有属性，只读）
public string	CurrentCheckpointId	当前检查点ID，默认为空字符串（设置后存入保存系统）。私有Setter。	是（公有属性，只读）

脚本关联：

调用SaveSystem.Instance.SaveCheckpoint(string)在设置检查点时保存数据。

调用SceneLoader.ReloadAtLastCheckpoint()在玩家死亡时进行场景重载。

SaveData.cs

类名：SaveData，无显式继承（标记为[Serializable]）

功能概述：封装游戏存档数据的序列化类，包括最后记录的场景和检查点、解锁的最高章节以及已发现的检查点集合。

外部接口：

所有字段均为公有，作为可序列化数据。

字段/属性：

类型	名称	描述	Inspector暴露
public string	lastScene	记录上一次场景名称（用于继续游戏）。	是（字段）
public string	lastCheckpoint	记录上一次场景中的检查点ID。	是（字段）
public int	highestChapterUnlocked	已解锁的最高章节编号，默认1。	是（字段）
public HashSet<string>	discoveredCheckpoints	已发现检查点ID的集合，用于列表等功能。	是（字段）

脚本关联：SaveSystem使用此类进行JSON序列化存取，不涉及生命周期方法。

SaveSystem.cs

类名：SaveSystem，继承自Singleton<SaveSystem>

功能概述：负责将存档数据保存到磁盘（使用Application.persistentDataPath），以及加载存档。处理记录最近场景和检查点、解锁章节等逻辑。

外部接口：

方法

public void SaveLastScene(string sceneName)：保存当前场景名到data.lastScene，并写文件。

public void SaveCheckpoint(string checkpointId)：保存当前检查点ID到data.lastCheckpoint，同时如果是新发现的检查点还会加入discoveredCheckpoints集合并保存。

public void AddDiscoveredCheckpoint(string sceneName, string checkpointId)：记录发现的新检查点，同时调用保存最后场景和检查点的方法。（用于Checkpoint脚本中发生“达到检查点”的事件。）

public void UnlockChapter(int chapter)：如果传入章节编号更大，则更新data.highestChapterUnlocked并保存。

public void ResetAll()：重置存档数据到初始状态（清空检查点列表，章节设为1等）。

private void Save()：内部方法，将SaveData data序列化并写入文件路径。

private void Load()：内部方法，从文件读取JSON到data对象中。

Unity 生命周期方法：

protected override void Awake()：重写单例基类的Awake()，在此可加载存档（调用Load()）；保证单例实例的存在。

字段/属性：

类型	名称	描述	Inspector暴露
private string	FilePath（只读属性）	存档文件路径（Application.persistentDataPath/faded_dreams_save.json）。仅内部使用。	否（私有属性）
private SaveData	data	存储当前持久化数据的对象实例（SaveData）。开始时初始化为新实例。	否（私有）

脚本关联：

调用SaveData来读写存档。

ChapterManager和其他系统通过调用SaveSystem.Instance.SaveCheckpoint等方法影响此存档。

SceneLoader.cs

类名：SceneLoader（静态类）

功能概述：静态工具类，用于按指定检查点加载场景，或重新加载最后的检查点。包装了Unity的场景加载并与保存系统配合。

外部接口：

public static void LoadScene(string sceneName, string checkpointId = "")：加载指定场景。调用SaveSystem.Instance.SaveLastScene(sceneName)和SaveSystem.Instance.SaveCheckpoint(checkpointId)来记录数据。然后订阅SceneManager.sceneLoaded事件，在场景加载完成后找到对应的检查点对象并调用其SpawnPlayerHere()放置玩家。最后调用SceneManager.LoadScene(sceneName).

public static void ReloadAtLastCheckpoint()：从存档加载上一次的场景名和检查点ID，如果有效则调用LoadScene(lastScene, checkpointId)，否则加载默认场景。

Unity 生命周期方法：无（静态工具类，没有Awake/Start等）。

字段/属性：无（仅静态方法）。

脚本关联：

调用了SaveSystem和SceneManager。

在sceneLoaded回调中与Checkpoint脚本交互：查找场景中的指定ID的检查点并重生玩家。

AreaEnergyRegen.cs

类名：AreaEnergyRegen，继承自MonoBehaviour

功能概述：将当前GameObject作为一个能量回复区域，在一定半径内给玩家回复红能量和绿能量。支持可选的距离衰减、多玩家、每秒扫描次数控制等。

外部接口：无公共方法；仅通过Unity组件行为作用。

Unity 生命周期方法：

private void Update()：按设定的扫描频率检测玩家（使用Physics2D.OverlapCircleAll非分配版）并对每个玩家恢复能量。响应useDistanceFalloff决定恢复比例。

private void OnDrawGizmosSelected()：在编辑器中绘制Gizmos（半透明圆圈）可视化能量回复区域。

字段/属性：

类型	名称	描述	Inspector暴露
public float	radius	回复区域半径（最小0.1）。在此半径内为玩家恢复能量。带[Min(0.1f)]。	是（公有）
public LayerMask	playerMask	物理层遮罩，用于OverlapCircleAll仅筛选玩家层的对象（默认全部层）。	是（公有）
public float	redPerSecond	红能量每秒回复量（>=0）。带[Min(0f)]限制。	是（公有）
public float	greenPerSecond	绿能量每秒回复量（>=0）。带[Min(0f)]。	是（公有）
public bool	useDistanceFalloff	是否根据与区域中心距离线性衰减回复速度。即靠近中心恢复更快。	是（公有）
public float	edgeMultiplier	边缘最大时的恢复倍率（0~1）。1表示边缘不衰减，0.2表示边缘处仅20%速率。带[Range(0f,1f)]。	是（公有）
public int	scansPerSecond	每秒检查玩家的次数（整数1~20）。值越小性能开销低，但区域响应延迟越大。带[Range(1,20)]。	是（公有）
private float	_scanTimer	用于在Update中累计时间，控制扫描间隔计时。	否（私有）
private static Collider2D[]	_hitsBuffer	静态缓冲区数组，最大32个碰撞，供OverlapCircleNonAllocCompat复用以减少GC。	否（私有）

脚本关联：

引用了FadedDreams.Player命名空间，实际脚本中调用了PlayerColorModeController或玩家脚本API来修改玩家能量。

通过OverlapCircleAll（兼容版）查找所有位于playerMask层的玩家碰撞体，并对其执行能量恢复。

BracketVisual.cs

类名：BracketVisual，继承自MonoBehaviour

功能概述：用于显示玩家能量槽（左右括号）的可视UI组件。它根据能量值填充颜色并具有按使用和获得能量时的脉冲和闪光特效。

外部接口：

public void ConfigureSide(bool isRedSide)：设置当前括号是显示红色能量还是绿色能量（通过更改shellRenderer和rimLight颜色）。

public void SetTargetFill01(float v)：设置目标填充比例（0~1），通常根据玩家当前能量与最大能量之比来调用，用于启动填充插值。

public void TickFill(float dt)：进度填充动画，通常由外部脚本逐帧调用更新（dt为时间增量）。

public void PulseUse()：当玩家使用能量时（如攻击）调用，启动使用脉冲效果（调用协程CoPulse）。

public void FlashGain()：当玩家获得能量时调用，启动获得闪光效果（调用协程CoFlash）。

public void PlayUseHighlightAndFX()：触发能量使用时的粒子和光效反馈。

public void PlayGainFX()：触发能量获得时的粒子效果。

Unity 生命周期方法：

private void Awake()：在开始时获取组件引用并设置初始透明度值等。

字段/属性：

类型	名称	描述	Inspector暴露
public SpriteRenderer	shellRenderer	外层括号图像渲染器，用于设置整体透明度(shellAlpha)和材质等。	是（公有）
public SpriteRenderer	liquidRenderer	内层括号图像渲染器，用于填充条纹动画（配合SpriteMask显示能量液面）。	是（公有）
public Light2D	rimLight	光晕渲染器，显示高亮效果。	是（公有）
public float	shellAlpha	外层括号透明度（0~1），默认0.6。带[Range(0f,1f)]。	是（公有）
public Color	redColor	代表红侧括号的颜色（RGBA）。	是（公有）
public Color	greenColor	代表绿侧括号的颜色（RGBA）。	是（公有）
public string	sortingLayerName	括号渲染的排序层名称，默认为"UI"。	是（公有）
public int	sortingOrder	括号渲染的排序顺序，默认为5000。	是（公有）
public float	fillLerpSpeed	填充动画插值速度，默认3.0。	是（公有）
public float	minFillY	填充线条最小Y值，用于构造液面高度，默认0.02。	是（公有）
private float	_targetFill01	目标填充比例（0~1），用于动画。	否（私有）
private float	_currentFill01	当前填充比例（0~1），动画中逐渐接近目标值。	否（私有）
public float	usePulseScale	使用能量时脉冲放大倍数（基于原尺寸），默认1.08。	是（公有）
public float	usePulseTime	使用能量时脉冲持续时间（秒），默认0.12。	是（公有）
public float	gainFlashIntensity	获得能量时闪光的最大强度（倍数），默认1.4。	是（公有）
private bool	_pulsing	内部标记，是否正在进行脉冲动画（避免重复触发）。	否（私有）
private bool	_flashing	内部标记，是否正在闪光动画中。	否（私有）
private bool	_useHighlighting	标记是否要触发能量使用高亮（用于PlayUseHighlightAndFX）。	否（私有）
private float	_nextDebugTime	调试用计时器，无实际影响。	否（私有）

脚本关联：

与PlayerColorModeController配合使用，外部脚本（如EnergyBracketsController）会调用其SetTargetFill01和PulseUse/FlashGain等方法以更新显示。

在模式切换时会通过ConfigureSide()切换左右括号的颜色表示玩家红色或绿色模式。

BulletProjectile.cs

类名：BulletProjectile，继承自MonoBehaviour，实现IDamageable接口

功能概述：一个可被发射的子弹类，在触及玩家或障碍时造成伤害或自毁，并实现IDamageable可被伤害者接口。可用于敌人发射弹幕。

外部接口：

public void Fire(Vector2 dir)：用指定方向dir发射子弹（设置Rigidbody2D速度为speed * dir.normalized）。

public void TakeDamage(float amount)：接口实现，降低弹丸的生命值（damage），若血量降至0则自毁（调用KillSelf()）。

public bool IsDead { get; private set; }：实现接口的只读属性，指示子弹是否已被摧毁。

Unity 生命周期方法：

private void Awake()：在开始时缓存Rigidbody2D组件，设置gravityScale=0、collisionDetectionMode=Continuous。并启动协程（如果有，例如KillSelf等）。

private void OnTriggerEnter2D(Collider2D other)：当子弹撞击触发器时，如果碰撞对象与playerMask匹配或是障碍层，则调用KillSelf()触发爆炸或销毁。

字段/属性：

类型	名称	描述	Inspector暴露
public float	speed	子弹飞行速度，默认12。	是（公有）
public float	damage	子弹伤害值，默认12。对目标造成此量伤害。	是（公有）
public float	lifeTime	子弹存在的最长时间（秒），默认4。超过后自动销毁。	是（公有）
public LayerMask	playerMask	碰撞检测掩码，用于指定哪些层算作玩家可被击中的目标。	是（公有）
public LayerMask	obstacleMask	碰撞检测掩码，用于指定哪些层算作障碍物（撞击后子弹销毁）。	是（公有）
public bool	destroyOnHit	是否在撞击后立即销毁子弹并产生击中效果，默认true。	是（公有）
private Rigidbody2D	_rb	子弹的刚体组件缓存，用于移动。	否（私有）
public bool	IsDead	标识子弹是否已被销毁，由内部设置，外部只读（IDamageable接口要求）。	否（只读）

脚本关联：

实现IDamageable接口，因此可以被其他脚本调用TakeDamage（如被玩家攻击时）。

发射时会设置刚体速度，其运动和碰撞逻辑由物理引擎处理。

子弹碰撞到玩家或障碍时，会触发自身销毁（KillSelf），可用于产生爆炸或击中特效。

CloudSniperAI.cs

类名：CloudSniperAI，继承自MonoBehaviour

功能概述：敌人“云狙击者”的AI控制器。继承了移动逻辑（可能来自SmartMove），攻击方式包括子弹齐射和投掷震爆弹：按一定冷却时间进行多发子弹攻击，然后蓄力后发射爆炸弹。

外部接口：无公共方法（仅通过组件启用AI逻辑）。

Unity 生命周期方法：

private void Awake()：缓存组件如Rigidbody2D，初始化状态。

private void Update()：每帧更新AI状态，管理移动和攻击周期（可能启动协程CoAttackCycle()来处理攻击循环）。

字段/属性：

类型	名称	描述	Inspector暴露
public LayerMask	playerMask	玩家碰撞层，用于识别玩家的层。	是（公有）
public LayerMask	obstacleMask	障碍物层，用于射击时检测遮挡层。	是（公有）
public BulletProjectile	bulletPrefab	子弹预制体，用于发射子弹齐射。	是（公有）
public float	bulletDamage	子弹伤害值，默认12。	是（公有）
public float	bulletSpeed	子弹初速度，默认12。	是（公有）
public float	volleyCooldown	两次子弹齐射之间的冷却时间，默认2.2秒。	是（公有）
public ShockwaveGrenade	grenadePrefab	爆炸弹预制体，用于蓄力后发射。	是（公有）
public float	grenadeDamage	爆炸弹伤害值，默认26。	是（公有）
public float	grenadeSpeed	爆炸弹初速度，默认6。	是（公有）
public float	grenadeCooldown	两次爆炸投掷之间冷却时间，默认4.0秒。	是（公有）
public float	windupSeconds	蓄力时间，默认2.0秒（投掷前角色增加亮度）。	是（公有）
public float	glowIntensityMul	蓄力时自身Light2D.intensity乘数，默认2。	是（公有）
public float	idealRange	理想对玩家的追击距离，默认8。	是（公有）
public float	maxRange	最大追击距离，默认12。	是（公有）
public float	moveSpeed	移动速度，默认2.2。	是（公有）
public float	strafeSpeed	平移速度（侧向移动），默认1.8。	是（公有）
public float	avoidTurn	避让角速度，当接近边界时转向值，默认20度/s。	是（公有）
public float	obstacleProbe	探测障碍物的射线长度，默认1.0。	是（公有）
private Transform	_player	缓存玩家Transform。	否（私有）
private Rigidbody2D	_rb	缓存自身刚体。	否（私有）
private bool	_busy	标记是否正在攻击或其他动作中（用于协程控制）。	否（私有）
private Light2D	_selfLight	缓存自身的2D光源，用于蓄力发光效果。	否（私有）
private float	_baseIntensity	光源的基础强度，方便恢复蓄力前状态。	否（私有）

脚本关联：

使用了BulletProjectile和ShockwaveGrenade脚本来创建和发射子弹、爆炸弹。

调用Light2D组件来在蓄力时增加自身光照。

可能通过协程CoAttackCycle, CoBulletVolley和CoGrenade来控制攻击节奏。

EnemyHealth.cs

类名：EnemyHealth，继承自MonoBehaviour，实现IDamageable接口；同文件内还定义了嵌套类CameraShake2D。

功能概述：敌人的生命值管理脚本。处理敌人受到伤害、死亡后的效果（播放死亡特效、掉落物品、触发光爆和屏幕震动等）。

外部接口：

public void TakeDamage(float amount)：减少敌人生命值，并在生命值<=0时调用Die()死亡处理。

public bool IsDead { get; private set; }：接口属性，标记敌人是否已死亡。

Unity 生命周期方法：

private void Awake()：初始化生命值和缓存组件，如SpriteRenderer、Light2D等。

（文件末尾还定义了一个CameraShake2D类，在EnemyHealth逻辑中被用来在死亡时触发摄像机震动，该类具有自己的Awake、OnDisable方法，但属于嵌套类。这里合并说明。）

字段/属性：

类型	名称	描述	Inspector暴露
public float	maxHp	最大生命值，默认60。	是（公有）
public float	spawnInvulnerableSeconds	重生后的无敌时间（秒），默认0.25，以防瞬间被再击杀。	是（公有）
private float	_hp	当前生命值（内部跟踪，Awake时设为maxHp）。	否（私有）
private float	_spawnTime	记录生成时间，用于判断是否处于无敌期。	否（私有）
public GameObject	deathVfxPrefab	死亡时要实例化的粒子特效预制体（例如爆炸效果）。	是（公有）
public GameObject	dropPrefab	死亡时掉落的能量拾取物预制体（EnergyPickup）。	是（公有）
public bool	spawnExplosionLight	是否在死亡时产生光照爆炸效果。	是（公有）
public Color	explosionLightColor	死亡时光爆的颜色。	是（公有）
public float	explosionPeakIntensity	光爆最高亮度（Intensity），默认8。	是（公有）
public float	explosionInnerRadius	内圈光爆半径，默认0.5。	是（公有）
public float	explosionOuterRadius	外圈光爆半径，默认4.0。	是（公有）
public float	explosionFadeSeconds	光爆从高到低消失的时间（秒），默认0.65。	是（公有）
public AnimationCurve	explosionIntensityCurve	光爆强度随时间变化的曲线（从强到弱）。	是（公有）
public bool	shakeOnDeath	死亡时是否触发屏幕震动，默认true。	是（公有）
public float	shakeDuration	震动持续时间（秒），默认0.2。	是（公有）
public float	shakeFrequency	震动频率（震动每秒的次数），默认24。	是（公有）
public bool	IsDead	只读属性，标记敌人已死亡。	否（只读）
private FadedDreams.World.ModeVisibilityFilter	_colorRef	（可选）关联的颜色模式过滤器，用于判断击杀前的颜色。	否（私有）
private static CameraShake2D	_instance	摄像机震动的单例实例（CameraShake2D类）。	否（私有）
private Transform	_cam	主相机Transform。	否（私有）
private Vector3	_origin	摄像机原始位置，用于震动后重置。	否（私有）
private bool	_shaking	当前是否正在进行屏幕震动。	否（私有）

脚本关联：

死亡时若设置spawnExplosionLight，会实例化Light2D并插值渐隐（方法SpawnExplosionLight）。

若dropPrefab不空，则生成EnergyPickup实例，并设置其能量颜色为当前颜色的反色（调用ModeVisibilityFilter提供的对象颜色）。

调用CameraShake2D.Shake(shakeDuration, shakeStrength, shakeFrequency)来触发屏幕震动效果（CameraShake2D类在同文件末尾）。

包含嵌套的CameraShake2D类，实现摄像机震动：它具有静态Instance，并在自身Awake/OnDisable中管理震动参数和应用于相机的抖动。

EnergyBracketsController.cs

类名：EnergyBracketsController，继承自MonoBehaviour

功能概述：控制屏幕两侧能量“括号”UI的位置和显示。它将两侧的BracketVisual对象对齐到指定的跟随目标（通常为玩家），并根据玩家能量变化更新能量填充比例。

外部接口：无公开方法（只在内部订阅事件）。

Unity 生命周期方法：

private void Awake()：缓存PlayerColorModeController组件引用，并设置初始状态。

private void Start()：根据Inspector设置的跟随目标找到玩家模式控制器，并注册OnEnergyChanged事件回调。

private void Update()：每帧更新两个括号的目标位置到跟随目标两侧（使用followSmooth平滑插值），并更新填充。

private void OnEnergyChanged(float red, float redMax, float green, float greenMax)：当玩家能量改变时调用（由PlayerColorModeController触发），更新左右括号的填充目标值。

字段/属性：

类型	名称	描述	Inspector暴露
public BracketVisual	leftBracket	左侧括号视觉组件（默认对应红能量侧）。	是（公有）
public BracketVisual	rightBracket	右侧括号视觉组件（默认对应绿能量侧）。	是（公有）
public bool	leftShowsRed	是否左侧显示红能量（true）否则显示绿能量（false）。	是（公有）
public Transform	followTarget	要跟随的目标（一般为玩家Transform）。	是（公有）
public Vector2	leftOffset	跟随目标左侧偏移位置（世界坐标）。	是（公有）
public Vector2	rightOffset	跟随目标右侧偏移位置（世界坐标）。	是（公有）
public float	followSmooth	平滑跟随速度（插值系数），默认为20。	是（公有）
public string	sortingLayerName	括号渲染的排序层名称，默认为"UI"。	是（公有）
public int	sortingOrder	括号渲染的排序顺序，默认为5000。	是（公有）
public bool	debugLogs	是否开启调试输出，用于测试。	是（公有）
public float	debugInterval	调试日志的输出间隔时间。	是（公有）
private PlayerColorModeController	_pcm	缓存玩家的模式控制器，用于获取能量值和注册事件。	否（私有）
private float	_lastRed, _lastGreen	上一帧的红/绿能量，用于检查变化。	否（私有）
private float	_nextDebugTime	调试下一次输出的时间戳。	否（私有）

脚本关联：

在Start()方法中，找到followTarget对应的PlayerColorModeController（假设玩家身上有该组件）并注册事件：_pcm.OnEnergyChanged.AddListener(OnEnergyChanged)。

当玩家能量事件触发时，本脚本更新leftBracket和rightBracket的填充目标。如果leftShowsRed为true，左侧括号对应红能量，否则对应绿能量。

Update()中调用了BracketVisual.SetTargetFill01()来实时更新显示，并调用BracketVisual.ConfigureSide()设置括号颜色。

EnergyPickup.cs

类名：EnergyPickup，继承自MonoBehaviour

功能概述：表示场景中的能量拾取物。当玩家靠近时，会被吸引并为玩家恢复能量，然后消失。具有寿命限制和主动吸附逻辑。

外部接口：无公开方法；通过物理触发和距离检测实现行为。

Unity 生命周期方法：

private void Start()：在开始时找到玩家（带"Player"标签）的Transform，记录下来。

private void Update()：每帧检查玩家与拾取物之间的距离，如果超过吸引半径而未被吸引，则引发玩家。如果进入吸附半径，则调用AbsorbToPlayer()以完成拾取。

private void OnTriggerEnter2D(Collider2D other)：如果与玩家碰撞，则立即触发AbsorbToPlayer()（玩家获得能量，并销毁拾取物）。

字段/属性：

类型	名称	描述	Inspector暴露
public ColorMode	energyColor	此拾取物提供的能量颜色（红或绿），默认为红Red。	是（公有）
public float	amount	能量值数量，当玩家拾取时增加玩家该颜色的能量，默认20。	是（公有）
public float	life	存在寿命（秒），默认12秒，超过后自动销毁拾取物。	是（公有）
public float	attractRadius	吸引半径（单位距离），玩家在此范围内时拾取物会向玩家移动，默认6。	是（公有）
public float	absorbRadius	吸附半径（近距离距离），玩家进入此距离时自动拾取，默认0.35。	是（公有）
public float	flySpeed	吸引时拾取物飞向玩家的速度，默认8。	是（公有）
private Transform	_player	缓存玩家Transform（在Start中通过GameObject.FindGameObjectWithTag("Player")获取）。	否（私有）

脚本关联：

调用PlayerColorModeController.AddEnergy(energyColor, amount)（假设玩家脚本公开类似方法）或者其他逻辑增加玩家对应颜色能量。

激活时设置在Start()缓存玩家位置；Update()中不断检测距离。

EnergyPickupLightTint.cs

类名：EnergyPickupLightTint，继承自MonoBehaviour

功能概述：给能量拾取物的光源（Light2D）和EnergyPickup对象上色，以及可选的呼吸效果（明灭）。根据EnergyPickup.energyColor自动选择红/绿光色，并可以在不启用Universal Render Pipeline时配合其他光源组件使用。

外部接口：无公开方法；在Reset/Awake时获取引用，并在Update中根据拾取物颜色更新光的颜色和强度。

Unity 生命周期方法：

private void Reset()：当组件添加到GameObject时自动执行，尝试获取父对象或自身上的EnergyPickup组件。

private void Awake()：获取EnergyPickup和Light2D组件引用，并注册对EnergyPickup的监听（如果需要）。

private void Update()：每帧根据EnergyPickup.energyColor设置light2D.color为redEnergyLight或greenEnergyLight；如果启用breathe，还通过正弦波动态改变光强度形成呼吸效果。

private void ApplyColor()：内部方法，将颜色和baseIntensity应用到光源组件。

字段/属性：

类型	名称	描述	Inspector暴露
public EnergyPickup	pickup	引用当前的EnergyPickup对象（提供energyColor）。	是（公有）
public Light2D	light2D	光源组件，用于发光效果（颜色和强度）。	是（公有）
public Color	redEnergyLight	红色能量对应的光颜色，默认为淡红色。	是（公有）
public Color	greenEnergyLight	绿色能量对应的光颜色，默认为淡绿色。	是（公有）
public bool	breathe	是否启用呼吸效果（光强度周期性变化），默认为true。	是（公有）
public float	baseIntensity	光源基础强度。	是（公有）
public float	breatheAmplitude	呼吸效果的强度振幅，默认为0.15。	是（公有）
public float	breatheSpeed	呼吸频率，默认为2.4（周期）。	是（公有）

脚本关联：

在Reset()中如果未手动设置pickup，则自动使用父对象或自身的EnergyPickup。

Update()中根据pickup.energyColor切换光颜色，并按照breathe参数让光强度在baseIntensity±breatheAmplitude之间周期性变动。

FlashStrike.cs

类名：FlashStrike，继承自MonoBehaviour

功能概述：玩家“空间斩”（冲刺攻击）组件。在玩家冲刺时，对周围敌人造成伤害。按住冲刺键时玩家减速并拉伸体型，释放时检测一个半径内的敌人并施加伤害。

外部接口：无公开方法；通过与PlayerController2D配合运行。

Unity 生命周期方法：

private void Update()：检查玩家冲刺状态（可能通过监听PlayerController2D的回调或使用全局标志PlayerController2D.isDashing），若满足条件且冷却时间到，执行一次碰撞检测（Physics2D.OverlapCircleAll）来对每个敌人（满足enemyMask）调用伤害（如TakeDamage）。

字段/属性：

类型	名称	描述	Inspector暴露
public LayerMask	enemyMask	目标检测掩码，用于OverlapCircleAll筛选哪些层为敌人。	是（公有）
public float	checkRadius	检测半径，冲刺结束时检测周围此距离内的敌人。默认1.0。	是（公有）
public float	damage	空间斩的基础伤害值，默认30。	是（公有）
public float	aerialMultiplier	空中击中敌人时的伤害倍增因子，默认1.5。	是（公有）
public float	cooldown	两次空间斩之间的冷却时间（秒），默认0.25。	是（公有）
private bool	_isDashing	内部状态标志，当前是否处于冲刺状态（由PlayerController2D传入）。	否（私有）
private float	_lastProc	上次触发伤害的时间戳（用于执行冷却检测）。默认-99。	否（私有）

脚本关联：

与PlayerController2D关联：PlayerController2D在开始冲刺时应调用FlashStrike开始效果，在结束冲刺时调用检测伤害。

使用Physics2D.OverlapCircleAll按enemyMask层检测敌人对象，并对每个命中敌人调用IDamageable.TakeDamage造成伤害。

ModeVisibilityFilter.cs

类名：ModeVisibilityFilter，继承自MonoBehaviour

功能概述：根据玩家的当前颜色模式（红/绿），动态调整场景中物体的可见性和碰撞层。红模式下隐藏绿色物体、显示红色物体，绿模式相反。还可让物体关联的光源颜色与当前模式相匹配。

外部接口：无公开方法；在OnEnable/OnDisable中注册玩家模式变化事件。

Unity 生命周期方法：

private void Awake()：初始化各种Layer ID和缓存SpriteRenderer列表。

private void OnEnable()：注册到PlayerColorModeController.OnEnergyChanged或相关事件，以响应颜色模式变化，调用ApplyVisibility更新层级和透明度。

private void OnDisable()：注销事件监听。

private void OnValidate()：编辑器模式下，确保层名正确转换为层编号。

字段/属性：

类型	名称	描述	Inspector暴露
public ColorMode	objectColor	此对象对应的颜色模式（红或绿）。只有与玩家模式相同颜色时才显示，否则半透明或忽略碰撞。	是（公有）
public float	hiddenAlpha	当对象颜色与玩家模式不同（应隐藏时）的透明度（0~1），默认0.25。	是（公有）
public string	interactLayerName	“同色”互动层名称（如敌人层），当颜色相同时启用该层；否则禁用。	是（公有）
public string	ghostLayerName	“异色”互动层名称（如敌人幽灵层），颜色相反时启用该层；否则禁用。	是（公有）
public Light2D	light2D	关联的Light2D光源（可选），当颜色发生变化时调整光的颜色。	是（公有）
public Color	redLightColor	当玩家为红模式时为该光源设置的颜色。默认红色。	是（公有）
public Color	greenLightColor	当玩家为绿模式时为该光源设置的颜色。默认绿色。	是（公有）
private SpriteRenderer[]	_sprites	缓存自身及子物体所有SpriteRenderer组件，用于调整透明度。	否（私有）
private PlayerColorModeController	_player	缓存玩家的颜色模式控制器，用于订阅模式变化事件。	否（私有）
private int	_interactLayer	缓存“同色”层索引（根据interactLayerName转换）。	否（私有）
private int	_ghostLayer	缓存“异色”层索引（根据ghostLayerName转换）。	否（私有）

脚本关联：

在OnEnable()中查找PlayerColorModeController并注册OnEnergyChanged事件（因为颜色模式变化时玩家能量变化也可触发）。

ApplyVisibility(PlayerColorModeController currentMode)方法根据玩家当前颜色模式：

如果与objectColor相同，将物体及子物体恢复为正常层级（通过SetLayerRecursively启用“同色”层、禁用“异色”层），并将光源颜色设置为redLightColor或greenLightColor。

如果颜色不同，将物体变为半透明（设置SpriteRenderer.color的alpha为hiddenAlpha）并交换层级（启用ghostLayer层）。

PlayerColorModeController.cs

类名：PlayerColorModeController，继承自MonoBehaviour

功能概述：管理玩家的红绿能量值和颜色模式。处理能量消耗、模式切换和能量恢复，以及触发相关事件。

枚举：

public enum ColorMode { Red, Green }：玩家当前的颜色模式（红或绿）。

外部接口：

属性/字段：

public ColorMode Mode：当前模式（可在Inspector中初始设置）。

诸多私有[SerializeField]字段用于设定红/绿能量、切换耗能、攻击耗能和切换冷却等。

public UnityEvent OnBothEnergiesEmpty：当两种能量都耗尽时触发的事件。

public UnityEvent<ColorMode> OnModeChanged：模式切换时触发（提供新模式）。

public EnergyEvent OnEnergyChanged：自定义事件，签名为(float red, float redMax, float green, float greenMax)，当能量变化时触发。

方法：

public bool CanSwitchTo(ColorMode target)：判断是否可以切换到目标模式（当前能量是否满足minOtherEnergyToSwitch要求，以及冷却是否到期）。

public bool TrySwitchMode()：尝试切换模式，如果成功则扣除能量并返回true。内部调用ForceSwitch。

public bool HasEnergy(ColorMode m, float amount)：检查指定颜色模式下能量是否>=amount。

public bool SpendEnergy(ColorMode m, float amount)：扣除指定颜色模式的能量，如果扣除后达到0则触发OnBothEnergiesEmpty事件。

public void AddEnergy(ColorMode m, float amount)：增加指定颜色的能量，触发OnEnergyChanged、OnModeChanged（如果当前模式与增加的颜色相同）。

public bool TrySpendAttackCost()：消耗当前模式的攻击耗能（redAttackCost或greenAttackCost），如果成功返回true。

public void Set(ColorMode target)（或类似内部）：强制切换模式到target，不检查条件。

public UnityEvent<float, float, float, float> OnEnergyChanged：已声明事件，无直接方法名；通过内部调用触发。

Unity 生命周期方法：

private void Start()：在游戏开始时初始化红、绿能量为red和green字段值，并触发一次OnEnergyChanged。

private void Update()：处理自动切换逻辑（如切换冷却时间，或在无能量时自动切换/重生），并调用PushEnergyEvent()来持续推送OnEnergyChanged。

字段/属性：

类型	名称	描述	Inspector暴露
[SerializeField] private float	redMax	红能量最大值。	是（私有，序列化）
[SerializeField] private float	greenMax	绿能量最大值。	是（私有，序列化）
[SerializeField] private float	red	初始红能量（当前值）。	是（私有，序列化）
[SerializeField] private float	green	初始绿能量。	是（私有，序列化）
[SerializeField] private float	switchCost	切换模式一次的能量消耗。	是（私有，序列化）
[SerializeField] private float	redAttackCost	使用红能量攻击时的能量消耗。	是（私有，序列化）
[SerializeField] private float	greenAttackCost	使用绿能量攻击时的能量消耗。	是（私有，序列化）
public ColorMode	Mode	当前玩家模式（Red或Green）。可在Inspector修改初始值。	是（公有）
[SerializeField] private float	minOtherEnergyToSwitch	切换到另一种颜色时，对另一种颜色的最低剩余能量要求。	是（私有，序列化）
[SerializeField] private float	switchCooldown	模式切换的冷却时间（秒），防止连续切换。	是（私有，序列化）
private float	_lastSwitchTime	记录上次成功切换的时间戳，用于计算冷却。	否（私有）
public UnityEvent	OnBothEnergiesEmpty	两种能量同时为零时触发的Unity事件。	是（公有）
[System.Serializable] public class EnergyEvent : UnityEvent<float,float,float,float> { } <br/> public EnergyEvent	OnEnergyChanged	当红/绿能量值变化时触发，参数为(currentRed, maxRed, currentGreen, maxGreen)。	是（公有）
public UnityEvent<ColorMode>	OnModeChanged	当切换模式时触发的Unity事件（参数为新模式）。	是（公有）

脚本关联：

在模式切换和能量变化时调用事件OnEnergyChanged和OnModeChanged；界面或其他逻辑可订阅这些事件。

EnergyBracketsController订阅了OnEnergyChanged，以更新玩家HUD显示。

ModeVisibilityFilter订阅了模式变化以切换对象可见性。

PlayerMeleeLaser.cs

类名：PlayerMeleeLaser，继承自MonoBehaviour

功能概述：玩家的近战激光武器。在玩家蓄力后释放时，向一个方向发射延伸的激光并造成伤害，同时可播放释放动画和冲击波。

外部接口：

public void OnEnable()（或在Awake中）初始化线渲染器等组件。

该脚本没有公开方法供外部直接调用，动作通过用户输入触发。

Unity 生命周期方法：

private void Awake()：创建或配置主要组件（如LineRenderer）。

private void Update()：如果检测到玩家在使用这个武器（例如按住蓄力键），则启动协程CoChargeAndRelease()控制蓄力和释放过程。

private IEnumerator CoChargeAndRelease()：协程，处理蓄力阶段和释放阶段，最终调用子方法（如ApplyLR显示线渲染器、DoHitsAlongShaft造成伤害、播放特效）。

private void OnDrawGizmosSelected()：在编辑模式下绘制瞄准线的Gizmos帮助调整。

字段/属性：

类型	名称	描述	Inspector暴露
public LayerMask	hitMask	可撞击目标的层级（敌人和障碍）。	是（公有）
[Header("Charge Length")]
public float	minLen	激光最短长度（单位）。	是（公有）
public float	maxLen	激光最长长度。	是（公有）
public float	chargeMaxTime	蓄力所需时间上限（秒）。	是（公有）
[Header("Sweep Attack")]
public float	rotateDuration	扫击角度的持续时间（秒）。	是（公有）
public float	damage	激光每击伤害值，默认25。	是（公有）
public float	hitRadius	激光碰撞的宽度半径，默认0.2。	是（公有）
public AnimationCurve	sweepEase	扫击角速度曲线（输入0~1，输出0~1决定旋转进度）。	是（公有）
public float	refMinLen	参考最小长度，用于定位左侧线渲染器。默认1。	是（公有）
public float	refMaxLen	参考最大长度，用于定位左侧线渲染器。默认3.5。	是（公有）
public Transform	tipTrail	激光末端尾迹的Transform（可选，用于特效）。	是（公有）
public bool	autoEnableTrail	蓄力时自动显示尾迹，默认为true。	是（公有）
private Transform	_ringRoot	缓存环形LineRender器的父Transform。	否（私有）
private Light2D	_baseLight	缓存激光根部的光源，用于蓄力时光照增强效果。	否（私有）
private Light2D	_tipLight	缓存激光尖端的光源，用于释放时光照闪烁效果。	否（私有）
private float	_seedCore	随机种子用于蓄力时根部光照闪动。	否（私有）
private float	_seedGlow	随机种子用于蓄力时光晕效果。	否（私有）

脚本关联：

使用LineRenderer在释放时绘制激光。

PlayerController2D会在玩家攻击时启用/禁用此组件或触发方法，例如调用CoChargeAndRelease()。

击中敌人时通过Physics2D.LinecastAll检测目标（敌人），并对每个命中EnemyHealth调用TakeDamage(damage)。

触发冲击特效（光晕、粒子）并可启动额外协程（如CoShockwave）造成范围爆炸伤害。

PlayerRangedCharger.cs

类名：PlayerRangedCharger，继承自MonoBehaviour

功能概述：玩家的远程蓄力武器。按键蓄力时形成能量束，对准敌人自动锁定射击，并在释放时造成击退和爆炸效果。

外部接口：

无公开接口；通过用户输入自动进行瞄准、蓄力和释放。

Unity 生命周期方法：

private void Update()：检测玩家输入（蓄力开始/结束），开始CoChargePreviewAndShootAutoLock()协程：自动锁定最近的敌人并蓄力后发射能量束。

private IEnumerator CoChargePreviewAndShootAutoLock()：协程实现自动锁定敌人目标、显示蓄力光束和最终攻击。

其他协程如FlashBeamOnce（显示光束）、DoHitAndExplosion（攻击处理）被内部调用。

字段/属性：

类型	名称	描述	Inspector暴露
public LayerMask	enemyMask	目标检测层（敌人及可穿透对象），用于射线检测。	是（公有）
public LayerMask	raycastMask	射线遮挡层（环境），用于确定光束是否被障碍物阻挡。	是（公有）
public float	maxChargeTime	最大蓄力时间（秒），默认1.0。蓄力时间越长，伤害越高。	是（公有）
public float	widthMin	最小线宽度（蓄力开始时），默认0.1。	是（公有）
public float	widthMax	最大线宽度（蓄力结束时），默认0.5。	是（公有）
public float	baseDamage	基础伤害，未蓄力时使用，默认15。	是（公有）
public float	damageAtMax	最大蓄力下的伤害值，默认45。	是（公有）
public float	extraEnergyCostAtMax	从最小到最大蓄力额外的耗能增量，默认10。	是（公有）
public float	selfKnockbackForce	自身后坐力大小，默认8。	是（公有）
public float	maxBeamDistance	能量束最远射程，默认50。	是（公有）
public GameObject	explosionPrefab	爆炸特效预制体，用于在命中时生成爆炸效果。	是（公有）
public float	explosionRadius	爆炸半径，默认2.2。	是（公有）
public float	explosionDamage	爆炸伤害，默认35。	是（公有）
private Color	_chargeColor	内部变量：蓄力时的束光颜色。	否（私有）
private Color	_maxColor	内部变量：完全蓄力时的束光颜色。	否（私有）
及其他众多私有字段，用于控制蓄力过程和粒子效果等	–	–	否（私有）

脚本关联：

自动寻找最近敌人目标（使用FindNearestEnemy()），并指向该目标进行蓄力。

蓄力完成后生成LineRenderer光束，并进行击中检测（DoHitAndExplosion），对敌人造成伤害并触发粒子爆炸（explosionPrefab）。

动态调整激光的宽度和颜色，并可生成附加效果（弹射光束、拖尾等）。

ShockwaveGrenade.cs

类名：ShockwaveGrenade，继承自MonoBehaviour

功能概述：投掷型爆炸弹，用于近战爆炸伤害。敌人蓄力释放后生成并抛射此炸弹，碰到玩家或障碍物后爆炸并对周围玩家造成伤害。

外部接口：

public void Fire(Vector2 dir)：以指定方向抛射炸弹（设定Rigidbody2D速度为speed * dir.normalized）。

Unity 生命周期方法：

private void Awake()：缓存Rigidbody2D组件并初始化物理属性（如关闭重力）。

private void OnTriggerEnter2D(Collider2D other)：当炸弹撞击到玩家(playerMask)时，调用Explode()；或撞击到障碍(obstacleMask)时也引爆。

private void OnDrawGizmosSelected()：编辑器模式下绘制爆炸半径的Gizmos。

字段/属性：

类型	名称	描述	Inspector暴露
public float	speed	投射速度，默认6。	是（公有）
public float	damage	爆炸伤害值，默认26。	是（公有）
public float	radius	爆炸半径，默认2.8。	是（公有）
public float	lifeTime	存在时间（秒），默认6。过期自动爆炸或销毁。	是（公有）
public LayerMask	playerMask	玩家碰撞层（触发时爆炸）。	是（公有）
public LayerMask	obstacleMask	障碍物碰撞层（触发时爆炸）。	是（公有）
public GameObject	explosionVfx	爆炸特效预制体。	是（公有）
private Rigidbody2D	_rb	缓存自身刚体。	否（私有）

脚本关联：

调用Rigidbody2D的AddForce或设置速度实现抛射。

碰撞时调用Explode()：在玩家或障碍发生撞击后执行爆炸逻辑，可能包括伤害和粒子效果。

SwarmMeleeAI.cs

类名：SwarmMeleeAI，继承自MonoBehaviour

功能概述：群体近战敌人的AI。简单敌人，会寻找玩家并追击，一旦接近则进行攻击（包括冲刺或跳跃攻击）。

外部接口：无公共方法；通过启用此组件运行AI逻辑。

Unity 生命周期方法：

private void Awake()：缓存Rigidbody2D、LineRenderer等组件并初始化状态（如生成原始朝向）。

private void Update()：每帧更新AI状态：如果有玩家视线(HasLOS())则追击玩家；如果接近则开始攻击协程（如CoSweep、CoDashAttack）。也会在远离时进行探索（Wander()）。

private void OnDrawGizmosSelected()：编辑器绘制视线范围和攻击距离的Gizmos。

字段/属性：

类型	名称	描述	Inspector暴露
public LayerMask	playerMask	玩家层，用于检测玩家目标。	是（公有）
public LayerMask	groundMask	地面层，用于检测是否着地。	是（公有）
public float	damage	攻击造成的伤害，默认20。	是（公有）
public float	seeDistance	敌人能看到玩家的最大距离（视野半径），默认10。	是（公有）
public float	attackDistance	开始攻击（如冲刺）所需的距离阈值，默认1.6。	是（公有）
public float	moveSpeed	地面移动速度，默认2.8。	是（公有）
public float	gravityScale	重力缩放，默认2.5，用于在空中调整下落速度。	是（公有）
public float	groundCheckDistance	与地面检测碰撞体的距离（地面距离）。默认0.2。	是（公有）
public float	stepProbeDistance	小台阶高度检测距离（避障高度）。默认0.4。	是（公有）
public float	smallHopImpulse	过小障碍时自动跳跃的冲量，默认3.5。	是（公有）
public float	headClearance	顶部空间要求（跳起前需要检查），默认0.35。	是（公有）
public float	wanderRadius	闲置时随机目标搜索半径，默认5。	是（公有）
public float	wanderStaySeconds	漫游目标更新间隔，默认1.5秒。	是（公有）
private LineRenderer	_lr	缓存用于攻击动画的LineRenderer。	否（私有）
private Vector2	_spawn	存储出生点位置。	否（私有）
private Vector2	_wanderTarget	当前漫游目标位置。	否（私有）
private float	_nextWanderPick	下一次选择漫游目标的时间。	否（私有）
private bool	_busy	是否正在执行攻击协程，防止重复触发。	否（私有）

脚本关联：

使用Physics2D.Raycast等方法判断是否有可视线路径（HasLOS()）。

根据条件调用协程：如CoSweep()从远处突进、CoJumpCleave()跳击、CoDashAttack()冲刺攻击等。

攻击命中时调用DoPointHit对玩家造成伤害。

DarkSpriteAI.cs

类名：DarkSpriteAI，继承自MonoBehaviour，实现IDamageable

功能概述：敌人“黑暗精灵”AI控制器。具有悬浮飞行行为，玩家靠近时先盘旋、然后快速俯冲攻击玩家。当血量耗尽时会自爆（通过组件EnemySelfExplodeOnOverheat）。

外部接口：

public void TakeDamage(float amount)：减少生命值并触发自爆条件。

public void SelfExplode()：立即自爆（调用同游戏对象上的EnemySelfExplodeOnOverheat组件）。

Unity 生命周期方法：

private void Update()：每帧更新AI状态机，根据与玩家的距离切换行为（悬停、寻敌、俯冲、恢复等），并调用相应Tick_*()方法处理具体运动。

字段/属性：

类型	名称	描述	Inspector暴露
public Transform	player	玩家Transform引用。需手动在Inspector或运行时分配（或可自动寻找）。	是（公有）
public Rigidbody2D	rb	敌人的刚体，用于物理运动。	是（公有）
public float	detectRadius	AI开始追踪玩家的距离阈值，默认10。	是（公有）
public float	hoverHeight	悬停目标高度（相对于玩家或其他锚点），默认2.5。	是（公有）
public float	orbitRadius	盘旋围绕玩家的半径，默认2.2。	是（公有）
public float	approachSpeed	接近时的移动速度，默认6。	是（公有）
public float	orbitAngularSpeed	盘旋时的角速度（度/秒），默认120。	是（公有）
public float	windupTime	冲刺前停留蓄力时间（秒），默认2。	是（公有）
public float	windupMoveFactor	蓄力阶段的移动速度系数，默认0.2（几乎静止）。	是（公有）
public float	shakeAmpMax	起跳时的最大摇晃幅度，默认0.4。	是（公有）
public float	shakeFreq	摇晃频率（赫兹），默认18。	是（公有）
public float	diveSpeed	俯冲速度，默认14。	是（公有）
public float	recoverUpSpeed	恢复阶段的上升速度，默认10。	是（公有）
private int	_state	当前AI状态机的状态。可由Tick_*()系列方法改变。	否（私有）
private Vector2	_seekDir	攻击目标方向。	否（私有）
private float	_timer	用于统计状态持续时间或攻击定时。	否（私有）
（等其他私有字段）	…	…	否（私有）

脚本关联：

使用EnemySelfExplodeOnOverheat组件在生命耗尽时自爆。

TakeDamage会标记自爆（或调用SelfExplode()）。

运动过程使用Rigidbody2D执行，如rb.MovePosition()和rb.velocity。

包括与玩家的碰撞检测（OnCollisionEnter2D等）以触发攻击或自爆。

DeathLightPulse.cs

类名：DeathLightPulse，继承自MonoBehaviour

功能概述：静态帮助类，用于在指定位置生成一个光脉冲特效（例如敌人死亡时的爆炸光）。它在指定位置生成一个临时GameObject并淡入淡出Light强度。

外部接口：

public static void Spawn(Vector3 pos, float baseIntensity, float baseRadius, float riseSeconds = .25f, float fallSeconds = 3f)：在pos位置创建一个新DeathLightPulse组件的实例，并调用Init以开始播放从0到baseIntensity的脉冲再衰减的过程。

Unity 生命周期方法：

public void Init(float baseIntensity, float baseRadius, float riseSeconds, float fallSeconds)：初始化参数并启动CoPulse协程控制光的变化。

private IEnumerator CoPulse(float baseIntensity, float riseSeconds, float fallSeconds)：协程，根据曲线和时间插值光强度并在完成后销毁自身。

字段/属性：

类型	名称	描述	Inspector暴露
private Light2D	l2d	淡入淡出的光源组件，若启用了URP 2D。	否（私有）
private Component	anyLightLike	可选的非URP光源组件（如Light或PointLight2D），用于非URP渲染时替代。	否（私有）

脚本关联：

Spawn(...)用于其他脚本（如敌人死亡逻辑）调用，不需要额外组件挂载。

Projectile.cs

类名：Projectile，继承自MonoBehaviour

功能概述：简单的飞行投射物，自动存在一定时间后销毁。当碰撞到DarkSpriteAI敌人时，对其造成伤害并销毁自身。

外部接口：无公开方法。

Unity 生命周期方法：

private void Start()：在创建时调用，设置Destroy(gameObject, lifespan)确保在lifespan秒后销毁。

private void OnTriggerEnter2D(Collider2D other)：检测碰撞到DarkSpriteAI时，调用其TakeDamage(damage)并销毁自身。

字段/属性：

类型	名称	描述	Inspector暴露
public float	damage	投射物造成的伤害，默认20。	是（公有）
public float	lifespan	存在时间（秒），默认2，时间到后销毁自身。	是（公有）

脚本关联：

在OnTriggerEnter2D中使用other.GetComponent<DarkSpriteAI>()，如果存在，则调用enemy.TakeDamage(damage)并销毁自身。

ContinueMenu.cs

类名：ContinueMenu，继承自MonoBehaviour

功能概述：简单的“继续游戏”菜单控制器。在Enable时清空现有按钮列表并创建表示已发现检查点的按钮列表，点击按钮可加载对应检查点。

外部接口：无公开方法。

Unity 生命周期方法：

private void OnEnable()：每次菜单激活时调用。销毁listParent下的所有子对象（旧按钮），然后从保存系统中获取当前场景的发现检查点列表，遍历创建新的按钮（使用checkpointButtonPrefab），并设置按钮点击事件为SceneLoader.LoadScene或GameManager等逻辑以加载该检查点。

字段/属性：

类型	名称	描述	Inspector暴露
public Button	checkpointButtonPrefab	检查点按钮的预制体，用于实例化列表项。	是（公有）
public Transform	listParent	持有所有按钮的父Transform（ScrollView内容）。	是（公有）
public string	sceneName	该菜单显示的场景名（用来获取该场景的发现检查点）。默认为"Chapter1"。	是（公有）

脚本关联：

通过SaveSystem.Instance.LoadCheckpoint()或保存的检查点列表创建菜单项。

GlowTextBanner.cs

类名：GlowTextBanner，继承自MonoBehaviour（单例）

功能概述：全局文字提示条，用于在屏幕上居中弹出带发光效果的文本提示（如对话、提示消息）。支持淡入淡出动画。

外部接口：

public static GlowTextBanner Instance：单例实例，自动在Awake()中赋值。

public void Show(string text, string token, float? fadeIn = null)：显示一条提示文本。token用于管理并行多条提示（仅拥有当前token的才能隐藏）。fadeIn可选指定淡入时间。

public void Hide(string token, float? fadeOut = null)：隐藏提示（仅当token匹配时生效），fadeOut为淡出时长。

public void ForceHide(float? fadeOut = null)：强制隐藏当前提示，无视token。

内部还有private void StartFadeTo(float target, float duration)和协程FadeTo实现具体的淡入淡出动画，通过控制CanvasGroup.alpha。

Unity 生命周期方法：

private void Awake()：设置Instance单例，并初始化CanvasGroup和TextMeshPro组件引用。

字段/属性：

类型	名称	描述	Inspector暴露
public static GlowTextBanner	Instance	单例实例，用于全局访问。	否（只读）
private CanvasGroup	canvasGroup	用于控制UI透明度的CanvasGroup组件引用。	是（私有）
private TextMeshProUGUI	label	文本组件引用，用于显示文字。	是（私有）
private float	defaultFadeIn	默认淡入时长（秒），可在Inspector调整。	是（私有）
private float	defaultFadeOut	默认淡出时长（秒），可在Inspector调整。	是（私有）
private string	ownerToken	当前显示提示的标识符（用于防止错误隐藏）。	否（私有）
private Coroutine	fadeRoutine	当前正在执行的淡入淡出协程，用于控制动画。	否（私有）

脚本关联：

在游戏中其它脚本（如剧情对话、触发器）可调用GlowTextBanner.Instance.Show(text, token)显示提示，并使用对应token调Hide隐藏。

HUDController.cs

类名：HUDController，继承自MonoBehaviour

功能概述：HUD（界面）控制器，更新玩家能量槽和模式文本显示。将PlayerLightController的事件绑定到UI元素（滑动条和文本）以实时反映能量变化和模式切换。

外部接口：无公开方法。

Unity 生命周期方法：

private void Start()：在开始时注册监听：player.onEnergyChanged绑定到Refresh()、player.onModeChanged绑定到RefreshMode()，并调用一次Refresh()初始化UI。

字段/属性：

类型	名称	描述	Inspector暴露
public Slider	energyBar	能量条UI滑动条组件，用于显示当前能量比例。	是（公有）
public TextMeshProUGUI	modeLabel	文本组件，用于显示当前模式名称（红/绿）。	是（公有）
public PlayerLightController	player	玩家亮度/能量控制器引用，用于绑定事件。	是（公有）

脚本关联：

监听PlayerLightController.OnEnergyChanged和OnModeChanged事件：

Refresh()方法将energyBar.value设置为player.currentEnergy/player.maxEnergy的比例。

RefreshMode()方法更新modeLabel.text为"RED"或"GREEN"（取决于player.mode）。

MainMenu.cs

类名：MainMenu，继承自MonoBehaviour

功能概述：主菜单控制脚本。处理“新游戏”、“继续”、“退出”等按钮的逻辑。

外部接口：

public void NewGame()：新游戏按钮回调。清除存档（SaveSystem.Instance.ResetAll()），并加载指定的首场景及检查点。

public void ContinueGame()：继续游戏按钮回调。通过SaveSystem加载最后保存的场景或默认场景。

public void Quit()：退出游戏按钮回调。调用Application.Quit()退出程序。

字段/属性：

类型	名称	描述	Inspector暴露
public string	firstScene	新游戏开始时加载的初始场景名称，默认"Chapter1"。	是（公有）
public string	firstCheckpointId	新游戏开始时使用的检查点ID，保证场景中存在该ID。默认"101"。	是（公有）

脚本关联：

NewGame()调用SaveSystem.Instance.ResetAll()清空存档，并使用SceneLoader.LoadScene(firstScene, firstCheckpointId)加载新场景检查点。

ContinueGame()通过SceneLoader.ReloadAtLastCheckpoint()继续游戏。

Quit()直接退出应用。

MainMenuOrchestrator.cs

类名：MainMenuOrchestrator，继承自MonoBehaviour

功能概述：主菜单场景的过渡动画控制器。管理菜单项的淡入、相机缓动等视觉效果，以及“按任意键继续”的逻辑。

Unity 生命周期方法：

private void Awake()：初始化场景，如隐藏菜单项，设置相机。

private IEnumerator Start()：或private void Start()中：等待“按任意键”，延时显示菜单项，启动渐入效果。

private void Update()：在空闲一段时间后触发小动画（如相机左右飘移），或检测玩家按键开始菜单。

字段/属性：

类型	名称	描述	Inspector暴露
public Camera	cam	舞台相机，用于摄像机运动效果。	是（公有）
public Transform	itemsRoot	所有菜单项（New, Continue, Quit）的根对象，用于统一控制出现位置。	是（公有）
public GameObject	pressAnyKey	“按任意键继续”提示对象。	是（公有）
public float	itemsFadeInDelay	菜单项淡入延迟时间，默认0.25秒。	是（公有）
public float	idleCinematicDelay	空闲动画触发时间（秒），默认15秒后开始相机漂移。	是（公有）
public float	camDriftAmp	相机漂移的幅度，默认0.5。	是（公有）
public float	camDriftSpeed	相机漂移的速率，默认0.2。	是（公有）
public ProjectedMenuItem	newGameItem	新游戏按钮（ProjectedMenuItem类型）。	是（公有）
public ProjectedMenuItem	continueItem	继续游戏按钮。	是（公有）
public ProjectedMenuItem	quitItem	退出游戏按钮。	是（公有）

脚本关联：

控制菜单项的出现动画（例如调用ProjectedMenuItem的动画方法）。

可启用MouseSpotlight（若addMouseSpotlight为真则在菜单上添加鼠标聚光效果）。

MouseSpotlight.cs

类名：MouseSpotlight，继承自MonoBehaviour

功能概述：在主菜单或UI场景中为鼠标指针添加一个投影光源效果（类似聚光灯）。根据是否悬停UI元素改变灯光颜色和角度。

外部接口：

public void SetHoveringUI(bool v)：当鼠标悬停在UI按钮上时由外部调用以改变光照效果（变换颜色/角度）。

Unity 生命周期方法：

private void Awake()：创建或配置内部灯光组件。

private void Update()：每帧跟随鼠标位置，逐渐将灯光移动到鼠标世界坐标（应用followLerp平滑）。根据hoveringUI状态逐渐过渡到hoverColor/hoverSpotAngle/hoverRange。

字段/属性：

类型	名称	描述	Inspector暴露
public float	intensity	投影灯强度，默认3.0。	是（公有）
public Color	baseColor	常态下光颜色，默认白色。	是（公有）
public float	baseSpotAngle	常态下光锥角度，默认35度。	是（公有）
public float	baseRange	常态下光半径，默认20。	是（公有）
public Color	hoverColor	悬停按钮时的光颜色，默认浅绿。	是（公有）
public float	hoverSpotAngle	悬停按钮时的光锥角度，默认30度。	是（公有）
public float	hoverRange	悬停时的光半径，默认18。	是（公有）
public float	aimLerp	鼠标位置插值速度，默认6。	是（公有）
public float	defaultDistance	无交互时光源距离，默认10（Z轴距离）。	是（公有）
public LayerMask	groundMask	鼠标Z投影用的地面层，可避免穿透空中UI。	是（公有）
public float	colorLerp	颜色平滑过渡速度，默认5。	是（公有）
public float	shapeLerp	角度/范围过渡速度，默认6。	是（公有）

脚本关联：

与UI事件系统配合：当鼠标进入或离开按钮时，通过EventTrigger或ProjectedMenuController调用SetHoveringUI(true/false)来改变灯光状态。

ProjectedMenuController.cs

类名：ProjectedMenuController，继承自MonoBehaviour

功能概述：用于3D主菜单场景中控制菜单项投影效果和相机移动。管理菜单项的焦点状态和过渡动画。

外部接口：无公开方法。

Unity 生命周期方法：

private void Awake()：设置初始状态，隐藏所有菜单项（except“按任意键”提示）。

private IEnumerator Start()：等待玩家按任意键后开始otherSlideInDur的淡入动画，焦点切换到选定项。

private void Update()：检测鼠标点击或触碰菜单项ProjectedMenuItem（使用Cam.ScreenPointToRay和interactMask），切换到焦点状态或触发按钮动作。维护当前菜单状态机(MenuState)；管理子菜单（如“继续”选项展开）。

字段/属性：

类型	名称	描述	Inspector暴露
public Camera	cam	主菜单场景的摄像机，用于投射鼠标射线。	是（公有）
public LayerMask	interactMask	菜单项交互层，用于射线检测哪些对象为可选项（通过ProjectedMenuItem标识）。	是（公有）
public Transform	itemsRoot	包含所有菜单项的父Transform，用于统一滑动入/出动画。	是（公有）
public float	othersSlideOutDist	菜单项被聚焦时，其他项滑出的距离。	是（公有）
public float	othersSlideOutDur	菜单项滑出动画时长。	是（公有）
public float	othersSlideInDur	菜单项滑入动画时长。	是（公有）
public float	focusDistance	焦点项与摄像机之间的距离。	是（公有）
public float	focusHeightOffset	焦点项与摄像机的高度偏移。	是（公有）
public float	focusMoveDur	聚焦项的移动动画时长。	是（公有）
public float	enterFadeOutDur	入场时摄像机拉回和过渡的时长。	是（公有）
public bool	playEnterIntro	是否播放开场黑屏淡入动画，默认为true。	是（公有）
public float	enterPullAheadDist	开场时相机向前推进距离（将菜单物体拉近），默认1.0。	是（公有）
public float	enterFadeInDur	开场时淡入黑幕的时长，默认2.0。	是（公有）
public MouseSpotlight	mouseSpot	用于主菜单的鼠标聚光灯，如果未赋值则在Awake中自动查找。	是（公有）
public float	areaSpotDimMul	“投影灯”区域亮度的衰减系数，默认0.65。	是（公有）

脚本关联：

与ProjectedMenuItem组件协作，切换MenuState（Idle、Focus、子菜单展开）。

用射线检测鼠标点击哪个ProjectedMenuItem，如果选中则播放其激活动画或处理动作（调用对应的MainMenu方法）。

控制摄像机位置和场景黑幕的渐变以产生开场动画（通过RedCurtainTransition进行淡入淡出）。

ProjectedMenuItem.cs

类名：ProjectedMenuItem，继承自MonoBehaviour

功能概述：菜单项的3D投影对象脚本。支持鼠标悬停变形、聚焦时突出效果、以及点击时触发按钮功能（新游戏/继续/退出）。

内部枚举：

public enum ActionType { NewGame, Continue, Quit, None }：定义菜单项的动作类型。

外部接口：

public void ExitSelectedState()：取消项目被选中状态，使其回到默认显示。

public void SetInteractable(bool v)：设置菜单项是否可交互，控制其透明度和碰撞。

public void SetSkewSign(float s)：设置斜切方向，用于随机生成破碎动画效果的偏移符号。

public void SetVisible(bool v, float fadeDuration = 0.3f)：显示或隐藏菜单项（通过材质属性或CanvasGroup）。

public void FreezeSlide(Vector3 offset)：冻结菜单项当前位置并偏移，用于焦点项的特殊动画。

public void UnfreezeSlide()：取消冻结，使菜单项回归自动布局。

public void PlayShatterBrief(float dur = 0.3f)：播放短暂破碎特效（使用shatterVfxPrefab）。

public void SlideToOffset(Vector3 worldOffset, float dur, AnimationCurve ease)：以动画方式移动菜单项到给定偏移位置。

public void SlideBack(float dur, AnimationCurve ease)：将菜单项滑回原位。

public void PushFrom(Vector3 source, float force, float radius)：受外力推动（动画效果）。

public void ReleasePush()：结束受推力动画。

public void TickSpring()：用于弹簧物理的更新调用（私有）。

Unity 生命周期方法：

private void Awake()：获取MeshRenderer和Collider引用，设置材质初始属性。

private void OnMouseEnter()/OnMouseExit()：处理鼠标悬停效果（调整材质的stretch和skew）。

private void OnMouseDown()：处理点击，通知MainMenu或开启子菜单。

字段/属性：

类型	名称	描述	Inspector暴露
public string	stretchKey	材质属性名，用于控制悬停时的伸缩效果（通常为_Stretch）。	是（公有）
public string	skewKey	材质属性名，用于控制悬停时的倾斜效果（通常为_Skew）。	是（公有）
public string	shatterKey	材质属性名，用于点击时的破碎动画（通常为_Shatter）。	是（公有）
public string	intensityKey	材质属性名，用于高亮强度（通常为_Intensity）。	是（公有）
public float	hoverStretch	鼠标悬停时的伸缩系数，默认1.35。	是（公有）
public float	hoverSkew	鼠标悬停时的倾斜系数，默认0.25。	是（公有）
public float	lerpSpeed	伸缩和倾斜变换的插值速度，默认8。	是（公有）
public float	selectedBoost	当项被选中（聚焦）时额外的缩放比例，默认0.5。	是（公有）
public ActionType	actionType	此菜单项的功能类型（新游戏、继续、退出等）。	是（公有）
public MainMenu	mainMenu	引用MainMenu脚本，以在点击时调用对应方法。	是（公有）
public ParticleSystem	shatterVfxPrefab	破碎特效预制体，用于播放点击动画。	是（公有）
public Light	spot	对应的聚光灯光源（UI按钮上的小灯），用于表现当前焦点。	是（公有）
public float	spotBase	聚光灯的基础亮度（环境状态），默认2.5。	是（公有）
public float	breathOnsetLerp	聚光灯开始呼吸（渐变）的插值速度，默认2.0。	是（公有）
public static float	GlobalSpotMul	全局聚光灯强度倍率，可用于调节灯光亮度，默认为1（公有只读）。	是（公有）
[SerializeField] private bool	interactable	菜单项是否可交互（默认为true），控制其可见度。	是（私有）
public float	visibleAlpha	菜单项可见时的透明度，默认1（调整后可能较低）。	是（公有）
public float	freezeFollowLerp	当冻结跟随模式时的插值速度，默认20。	是（公有）

脚本关联：

MainMenuOrchestrator使用此脚本控制各项动画。

点击事件通过mainMenu属性调用相应的主菜单逻辑（新游戏/继续/退出）。

BeamReflector2D.cs

类名：BeamReflector2D（静态类）

功能概述：提供一个静态方法，用于模拟一束光（激光）在2D空间中的反射路径（包括多次反射）。返回光线经过的所有点、最终撞击点和最后碰撞到的对象。

外部接口：

public static Result Cast(Vector3 origin, Vector2 direction, int maxBounce = 5, LayerMask mask, float stepEps = 0.01f, float maxDist = 1000f)：从origin以direction方向发射光线，检测与射线相交的反射面（如带Physics2D.Raycast标记为可反射的层）。最多反射maxBounce次。返回Result结构，包含路径点列表、最终结束点、碰撞到的Collider2D（若有）、是否发生过反射。

结构体：

public struct Result：包含四个字段：List<Vector3> points（光线经过的拐点坐标列表），Vector3 finalEnd（光线最终停留点），Collider2D finalCollider（最后碰撞到的物体，可能为空），bool reflected（是否至少反射了一次）。

脚本关联：

可用于LaserEmitter或其他需要计算反射路径的武器。

BloomBreathByEnergy.cs

类名：BloomBreathByEnergy，继承自MonoBehaviour

功能概述：控制全局后处理Bloom效果的脉动动画，依据玩家能量水平驱动呼吸节奏和强度。能量越低，脉动越快越强烈；能量恢复时脉动减弱。

外部接口：无公开方法；在开始时自动订阅玩家能量变化事件。

Unity 生命周期方法：

private void Awake()：查找并缓存Bloom后处理组件，订阅plc.OnEnergyChanged事件监听函数PullEnergy。

private void PullEnergy()：事件回调，从PlayerLightController获取当前能量百分比，更新内部energy01。

private void Update()：每帧根据energy01计算周期性变化（使用pulseSpeedAtLowEnergy和pulseAmplitude），并更新bloom.intensity。

字段/属性：

类型	名称	描述	Inspector暴露
public PlayerLightController	plc	玩家能量控制器引用，用于监听能量事件。	是（公有）
public Volume	volume	全局后处理Volume，用于获取其中的Bloom设置。	是（公有）
[Range(0f,2f)] public float	pulseSpeedAtLowEnergy	当能量低时的脉动速度因子，默认1.2。	是（公有）
[Range(0f,0.8f)] public float	pulseAmplitude	脉动强度振幅，默认0.4。	是（公有）
private Bloom	bloom	缓存的Bloom后处理组件。	否（私有）
private float	energy01	当前能量百分比，0~1。	否（私有）
private UnityAction	_energyListener	监听能量变化事件的委托（引用）。	否（私有）

脚本关联：

从PlayerLightController获取能量数值。

根据能量动态调整Bloom.intensity以实现呼吸效果。

CameraFollow2D.cs

类名：CameraFollow2D，继承自MonoBehaviour

功能概述：2D相机跟随脚本。根据玩家或目标位置计算软锁定区域，如果玩家离开该区域，则平滑移动相机使目标重新进入软区。还支持预测性跟随和场景边界限制。

外部接口：无公开方法；启用时自动工作。

Unity 生命周期方法：

private void Awake()：缓存Camera组件。

private void LateUpdate()：在每帧结束时更新相机位置：

使用softZoneCenterOffset和softZoneSize定义屏幕中心一个“软区”，如果目标位置超出软区，则使用SmoothDamp和maxSpeed将相机移动到使目标回到软区的边界。

lookahead功能：如果目标有速度，计算预测偏移（lookaheadFactor），提前移动相机。

限制相机位置在worldBounds所定义的区域内（若有）。

字段/属性：

类型	名称	描述	Inspector暴露
public Transform	target	目标对象（例如玩家）的Transform。	是（公有）
[Tooltip] public Vector2	softZoneCenterOffset	软区相对于屏幕中心的偏移（0~1范围内）。	是（公有）
[Tooltip] public Vector2	softZoneSize	软区的宽高（世界坐标），目标进入此区域后相机不动。	是（公有）
[Range(0.01f,1f)] public float	smoothTime	平滑移动时间系数（秒）SmoothDamp，较小值跟随更紧密，默认0.15。	是（公有）
[Tooltip] public float	maxSpeed	平滑移动时的最大速度（单位/秒），默认0表示不限制。	是（公有）
[Tooltip] public Vector2	lookaheadFactor	根据目标速度预测的位移因子（双轴）。默认(0.5,0.2)。	是（公有）
public float	lookaheadSmoothTime	预测移动插值时间，默认0.2。	是（公有）
public BoxCollider2D	worldBounds	定义相机可移动区域的Box Collider2D。相机将被限制在此范围内。	是（公有）
private Camera	cam	缓存的Camera组件。	否（私有）
private Vector3	moveVelocity	SmoothDamp的当前速度。	否（私有）
private Vector2	lookaheadVelocity	预测移动插值的当前速度。	否（私有）
private Vector2	targetPrevPos	前一帧目标位置，用于计算速度。	否（私有）
private Vector2	lookaheadPos	当前预测偏移后的目标位置。	否（私有）

脚本关联：

挂载在主摄像机上来跟随玩家。

利用BoxCollider2D（若存在）限制相机移动范围。

FadeScreen.cs

类名：FadeScreen，继承自MonoBehaviour（单例）

功能概述：全局淡入淡出管理器。通过覆盖屏幕的透明黑幕（CanvasGroup），实现屏幕渐变效果，常用于场景切换或重要转场。

外部接口：

public static FadeScreen Instance：单例实例。

public static IEnumerator Fade(float from, float to, float duration, AnimationCurve curve = null)：静态协程，渐变CanvasGroup.alpha从from到to，时长duration秒，使用curve。

public static IEnumerator FadeOutAndLoad(string sceneName, float fadeOut, float fadeIn, float hold = 0f)：静态方法，先淡入黑幕(fadeOut)，加载新场景，等待hold，然后淡出黑幕(fadeIn)。

Unity 生命周期方法：

void Awake()：设置单例实例并DontDestroyOnLoad以跨场景保留。获取CanvasGroup组件引用。

字段/属性：

类型	名称	描述	Inspector暴露
public static FadeScreen	Instance	单例实例，用于全局访问。	否（只读）
[Range(0,5)] public float	defaultDuration	默认淡入淡出持续时间，默认0.8秒。	是（公有）
public AnimationCurve	curve	默认的淡入淡出曲线（EaseInOut）。	是（公有）
private CanvasGroup	cg	用于遮罩全屏的CanvasGroup组件。	否（私有）

脚本关联：

SceneFlowManager可使用此脚本控制场景切换的黑幕效果。

其他脚本可以启动淡入淡出协程以实现渐变过渡。

LayerRefs.cs

类名：LayerRefs，继承自ScriptableObject

功能概述：自定义资源，用于在Inspector中配置常用层（Layer）遮罩的引用。

字段/属性：

类型	名称	描述	Inspector暴露
public LayerMask	worldObstacles	“世界障碍”层的遮罩（例如地形）。	是（ScriptableObject字段）
public LayerMask	enemy	“敌人”层的遮罩。	是（ScriptableObject字段）
public LayerMask	torch	“火炬”层的遮罩。	是（ScriptableObject字段）

脚本关联：在LaserEmitter等脚本中用于统一管理层遮罩配置。

SceneFlowManager.cs

类名：SceneFlowManager，继承自MonoBehaviour（单例）

功能概述：游戏的场景流程管理器。用于在剧情模式中先加载剧情场景再加载关卡，或在关卡结束时自动过渡。可与RedCurtainTransition配合做过渡动画。

外部接口：

public static SceneFlowManager Instance：单例实例。

public void BeginStoryThenLoad(string nextScene)：首先加载storySceneName（剧情场景），并在剧情结束后加载nextScene。

public void NotifyStoryFinished()：由剧情场景调用，表示剧情播放结束，此时如果有pendingNextScene，则加载它并退出剧情模式。

Unity 生命周期方法：

private void Awake()：设置单例实例并DontDestroyOnLoad。

字段/属性：

类型	名称	描述	Inspector暴露
public static SceneFlowManager	Instance	单例实例。	否（只读）
public string	storySceneName	剧情场景的名称（播放剧情后再返回关卡）。默认"STORY1"。	是（公有）
[Range(0,5)] public float	fadeDuration	场景切换时的淡入淡出时长。	是（公有）
private string	pendingNextScene	待加载的下一个关卡场景名（设置在BeginStoryThenLoad中）。	否（私有）
private bool	storyFinishedFlag	是否已经结束剧情场景的标志。	否（私有）

脚本关联：

调用FadeScreen做渐变：在开始剧情前淡入黑幕，加载剧情场景后淡出，然后在剧情结束时再淡入黑幕切换到下一关。

BeginStoryThenLoad由关卡结束时调用；NotifyStoryFinished由剧情场景结束时调用。

SerializableDictionary.cs

类名：SerializableDictionary，非MonoBehaviour，标记为[Serializable]

功能概述：用于在Unity Inspector中序列化存储简单的字典（目前实现为string->string映射），通过列表来保存键值对。

外部接口：

public void Set(string key, string value)：设置字典中键key对应的值为value，若键已存在则更新，否则添加新键值对。

public bool TryGet(string key, out string value)：尝试获取指定键的值，返回是否存在。

public Dictionary<string,string> ToDictionary()：将内部存储列表转换为标准的Dictionary<string,string>对象。

结构体：

[Serializable] public struct Pair { public string key; public string value; }：内部键值对结构体。

字段/属性：

类型	名称	描述	Inspector暴露
[SerializeField] private List<Pair>	data	存储所有键值对的列表，供Inspector序列化。	是（私有）
public struct Pair	(字段)	每个元素包含key和value两个字段。	否（结构体）
Singleton.cs

类名：Singleton<T>，泛型类，继承自MonoBehaviour

功能概述：通用单例基类，用于其他管理类继承实现单例模式。自动查找已存在的实例或创建新对象。

外部接口：

public static T Instance：静态属性，获取单例实例。若实例不存在，则查找场景中的对应类型或创建新GameObject并附加组件。

Unity 生命周期方法：

protected virtual void Awake()：在基类中实现单例的初始化，确保Instance正确指向该对象，处理DontDestroyOnLoad等逻辑。

字段/属性：

类型	名称	描述	Inspector暴露
private static T	_instance	单例实例的引用。	否
public static T	Instance	静态属性，返回单例实例（调用者无法设值）。	否（只读）
StoryController.cs

类名：StoryController，继承自MonoBehaviour

功能概述：剧情播放结束的触发控制器。可用于测试自动结束剧情或在Timeline触发器完成时调用结束方法。

外部接口：

public void EndStory()：调用后通知SceneFlowManager.Instance.NotifyStoryFinished()，表示剧情结束，应切换回正常关卡。

Unity 生命周期方法：

void Start()：如果autoEndForTest为true，则在autoEndDelay秒后自动调用EndStory()（测试用）。

字段/属性：

类型	名称	描述	Inspector暴露
public bool	autoEndForTest	是否在开始时自动结束剧情（测试模式）。	是（公有）
public float	autoEndDelay	自动结束剧情的延迟时间（秒）。	是（公有）
TriggerLoadOnTouch.cs

类名：TriggerLoadOnTouch，继承自MonoBehaviour

功能概述：触发器脚本，当指定标签的角色（默认为玩家）触碰此对象时，加载指定场景。用于游戏关卡中的自动切换触发点。

外部接口：无公开方法。

Unity 生命周期方法：

private void OnTriggerEnter2D(Collider2D other)：当有碰撞器进入触发器时，如果碰撞对象标签为requiredTag且脚本未使用过，则调用SceneManager.LoadScene(nextSceneName)加载下一个场景。如果oneShot为true，则仅触发一次。

字段/属性：

类型	名称	描述	Inspector暴露
public string	requiredTag	必需的标签（默认为“Player”），只有此标签的物体触发加载。	是（公有）
public string	nextSceneName	加载的场景名称。	是（公有）
public bool	oneShot	是否只触发一次，触发后禁用自己，默认true。	是（公有）
WorldHUDAnchor.cs

类名：WorldHUDAnchor，继承自MonoBehaviour

功能概述：用于UI物体在世界空间中跟随游戏对象的脚本。例如头顶血条等。根据玩家的位置和摄像机位置动态调整UI元素的位置和朝向。

Unity 生命周期方法：

void Start()：如果cam为空，则自动设置为Camera.main。

void LateUpdate()：在相机更新后，将UI物体的世界位置插值到player.position + worldOffset，并使其面向摄像机（如果faceCamera为true）。

字段/属性：

类型	名称	描述	Inspector暴露
public Transform	player	要跟随的玩家Transform。	是（公有）
public Vector3	worldOffset	相对偏移位置，用于放置UI（如血条）高于玩家。	是（公有）
public Camera	cam	参考摄像机（用于朝向），默认为主相机。	是（公有）
public bool	faceCamera	是否让UI始终面向摄像机，默认true。	是（公有）
public float	followLerp	平滑跟随速度（插值系数），默认15。	是（公有）

脚本关联：

常用于玩家头顶血量条或提示性UI，使其在3D场景中贴合玩家位置并保持面对摄像机。


LaserBeamSegment2D.cs

类名：LaserBeamSegment2D，继承自 MonoBehaviour, IDamageable
功能概述：可复用的“2D 激光段”脚本，支持三种驱动形态：定长静止、扫屏（sweeping，带速度）、追踪（homing，端点跟随）；内置一次性伤害与“每秒持续扣能”两种模式；支持被“空间斩”切开后的电影化演出链路（白闪+弹宽、火花/冲击波VFX、短暂HitStop、Light2D脉冲、随后高频电光闪烁并与线宽/透明度同速收束）。

外部接口：

public void Initialize(Vector3 a, Vector3 b, Color color, float thickness, float chargeSeconds, float lethalSeconds, float lifeSeconds, bool sweeping, Vector2 velocity)：初始化端点/颜色/线宽/蓄力-致命-存活时间，并指定是否扫屏与速度向量。

public void SetSlicedHit(Vector3 pos, Vector3 normal)：可选地把“被空间斩切中”的命中点与法线传入，用于更精准的VFX定位。

public void TakeDamage(float amount)（来自 IDamageable）：当被空间斩命中时触发整套“切割演出”（含相机冲击与时间凝滞的可选项），并在演出后销毁。

Unity 生命周期/内部流程要点：

命中检测：以圆投射沿线段做宽体检测，命中 Player 时按一次性 or continuousDrain 扣能；可选上挑冲量。

碰地特效：末端射线检测地面命中点，受频率限制生成 vfxHitGround。

被切后：停止扫屏/追踪/碰地判定，关闭碰撞体，进入“弹宽+白闪→高频闪烁→渐隐收束→销毁”。

相机冲击：优先尝试 Cinemachine Impulse；若无，则触发自定义事件以接驳你的 CameraShake。

字段/属性（节选）：

类型	名称	描述	Inspector
Vector3	startPos, endPos	起止点（世界坐标）	是
Color	baseColor	线体颜色	是
float	thickness	线宽	是
float	chargeSeconds, lethalSeconds, lifeSeconds	蓄力→致命→存活阶段时长	是
bool	sweeping / Vector2 velocity	扫屏移动与速度	是
bool	homing / Transform homingOrigin/Target / float homingFollowLerp / maxLength	追踪参数	是
float	energyDamage / bool continuousDrain / float knockupImpulse	伤害/持续扣能/上挑冲量	是
GameObject/LayerMask	vfxHitGround / groundMask	撞地特效与地面层	是
bool	sliceOnlyWhenLethal	仅在致命期允许被切	是
（电影化参数若干）	slicedBlinkSeconds / slicedBlinkFrequency / slicedWidthPunchMul / hitStopDuration / spawnLight2DPulse 等	切割演出细节	是

（字段来源见：运行/伤害/追踪/撞地/切割/电影化配置段落。）

脚本关联：

被 BossPhasedLaser 作为 laserPrefab 实例化使用；其扫屏、追踪、伤害/扣能与渐隐逻辑由本脚本自身驱动。

持续/一次性扣能会尝试调用 PlayerLightController.AddEnergy(-x) 或通用 IDamageable.TakeDamage。

BossPhasedLaser.cs

类名：BossPhasedLaser，继承自 MonoBehaviour, IDamageable
功能概述：三阶段 Boss 控制器，含仇恨与简易 AI、分阶段激光攻击（阶段1：随机点→玩家连线的充能斩；阶段2：屏幕外向内的多条扫屏束；阶段3：加速混战并新增跟踪激光）、被击中后“遁入虚无”无敌回归、阶段血条（LineRenderer）、以及战斗期相机改造（玩家优先锚点、Boss次之，强制 Keep-In-View 防止玩家左右出框；透视相机支持后退拉远或FOV放大）。死亡后延时触发红幕/淡幕场景切换。

外部接口：

public void TakeDamage(float amount)（来自 IDamageable）：按“每阶段受击次数”扣减；非致命时触发“遁入虚无→回归”；阶段清零后转入下一阶段；第三阶段清零后进入死亡流程与转场。

公开大量 Inspector 参数用于调参：阶段击中次数/颜色/各阶段激光性能、相机构图/拉远/Keep-In-View 边界、VFX、死亡转场等。

Unity 生命周期/内部流程要点：

Awake：缓存相机/玩家/刚体/碰撞体；记录相机原始参数；构建阶段血条。

OnEnable/OnDisable：入场淡入；禁用时停止攻击并恢复相机设定。

Update：仇恨检测→进入战斗并应用相机；简易 AI（接近/平移绕行）；透视相机逐帧插值；启用玩家优先锚点与 Keep-In-View 的硬性左右护栏。

死亡：优先调用 RedCurtainTransition.Go(...)；若无则回退至 FadeScreen.FadeOutAndLoad(...)；最终保证切换到 storySceneOnDeath。

阶段攻击（要点）：

阶段1：充能直斩（可设置充能颜色渐变 + 致命期加粗 + 渐隐消逝）。跨屏生成一条贯穿束，延时进入致命期并结算伤害/上挑。

阶段2：扫屏束群（一波 N 条、随机角度/速度；可调速度区间/波间隔/渐隐，波次触发强震）。

阶段3：混战加速 + 跟踪激光（持续对玩家位置插值追踪，期间持续每秒扣能；落地触发地面特效；结束后冷却再来）。

相机处理：

进入战斗时放大可视范围（正交模式放大 orthographicSize；透视模式可“后退拉远”或提高 FOV），并把 CameraFollow2D.target 切到内部锚点（玩家优先），横向软区略收紧；退出战斗时一键恢复。

提供“硬性 Keep-In-View”字段，使玩家不至于跑出屏幕左右边界（可调边距与拉回强度）。

字段/属性（节选）：

类型	名称	描述	Inspector
Camera / Transform / LaserBeamSegment2D	cam / player / laserPrefab	关键引用	是
int	phase1Hits/phase2Hits/phase3Hits	各阶段所需受击次数	是
Color	phase1Color/phase2Color/phase3Color	阶段主色	是
float	s1*、s2*、s3*	各阶段激光参数（充能/厚度/间隔/速度/持续扣能等）	是
float/bool	camSizeMul / camUseDolly / camFovMul / camHardKeepPlayerInView 等	战斗期相机设定	是
GameObject	vfxPhaseIn/out/Death/HitGround	阶段/死亡与撞地特效	是
string/float	storySceneOnDeath / deathDelaySeconds / redCurtain*	死亡转场配置	是

（字段清单详见“Stage2/Stage3/Aggro/Camera/Scene Transition”段落。）

脚本关联：

依赖 LaserBeamSegment2D 作为激光段预制体；与 CameraFollow2D 协同进行战斗期构图；可调用 RedCurtainTransition 或回退 FadeScreen 进行转场；相机震动使用 FadedDreams.CameraFX.CameraShake2D。

放到文档里的“怎么写/怎么摆”

层级：保持和现有条目一致的标题层级与表格样式；上面两段已经照着你文档格式写好了，直接粘贴即可（建议在“激光系统”模块末尾加入 LaserBeamSegment2D.cs，在“Boss/相机/转场”模块末尾加入 BossPhasedLaser.cs）。参考你文档里现有的 CameraFollow2D.cs 与 FadeScreen.cs 写法与表格风格。

交叉链接：在 CameraFollow2D.cs 的“脚本关联”末尾可以补一句“Boss 战期间由 BossPhasedLaser 接管目标为内部锚点”（可选）。在 PlayerLightController/能量系统条目（若有）里，可补一句“被 LaserBeamSegment2D 调用以持续或一次性扣能”（此项只是建议，不改也不影响理解）。