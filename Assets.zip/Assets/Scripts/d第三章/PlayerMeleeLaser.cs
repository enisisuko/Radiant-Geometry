﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace FadedDreams.Player
{
    /// <summary>
    /// 近战（红）—4段攻击版
    /// ① 下劈（顺时针弧）→ ② 上挑（逆向弧）→ ③ 三次小刺（短突进×3）→ ④ 超级大刺（长突进）
    /// 手感要点：方向平滑、收招窗口（earlyComboOpen）、命中0.3s慢动作、拖尾重置避免错位。
    /// </summary>
    [RequireComponent(typeof(LineRenderer))]
    public class PlayerMeleeLaser : MonoBehaviour
    {
        [Header("Layers / Damage")]
        public LayerMask hitMask;
        public float baseDamage = 18f;
        public float launcherDamageMul = 0.85f;
        public float thrustDamageMul = 1.05f;
        [Tooltip("命中采样圆半径（更大=更容易命中）")]
        public float hitRadius = 0.28f;
        [Tooltip("普通横斩击退力度")]
        public float knockbackForce = 6.2f;
        public float knockupOnLaunch = 8.0f;
        public float bigCleaveAoERadius = 2.6f;
        public float bigCleaveAoEDamageMul = 0.30f;
        public bool useMassToDetectLarge = true;
        public float largeMassThreshold = 3.5f;
        public float largeBoundsSize = 2.0f;

        [Header("Combo / Input")]
        public float comboWindow = 1.15f;
        public float earlyComboOpen = 0.18f;
        public float inputBuffer = 0.25f;
        public KeyCode inputKey = KeyCode.Mouse0;

        [Header("Anchors")]
        public Transform bladeOrigin;
        public FadedDreams.Player.CompanionBlade companion;

        [Header("Geometry")]
        [Range(60f, 170f)] public float sectorAngle = 135f;
        [Tooltip("近战横斩半径（有效攻击距离）")]
        public float sectorRadius = 4.2f;
        public float sampleStep = 0.20f;

        [Header("Timings (每段≈1.0s)")]
        public float cleaveWindup = 0.22f;
        public float cleaveSwing = 0.36f;
        public float cleaveRecover = 0.42f;
        public float launchWindup = 0.22f;
        public float launchSwing = 0.36f;
        public float launchRecover = 0.42f;
        public float smallThrustWindup = 0.18f;
        public float smallThrustDuration = 0.22f;
        public float smallThrustGap = 0.10f;
        public float smallThrustRecover = 0.28f;
        public float megaWindup = 0.22f;
        public float megaDuration = 0.42f;
        public float megaRecover = 0.46f;

        [Header("Thrust / 机动与无敌")]
        public float thrustDistance = 9.5f;
        public float thrustIFRames = 0.11f;
        public float softLockAngle = 28f;
        public float softLockRadius = 18f;
        public float smallThrustDistance = 4.5f;
        public float megaThrustDistance = 12.5f;

        [Header("Feel / 手感")]
        public AnimationCurve swingEase = AnimationCurve.EaseInOut(0, 0, 1, 1);
        [Tooltip("随阶段的线宽曲线（0~1）")]
        public AnimationCurve widthByPhase = AnimationCurve.Linear(0, 0.12f, 1, 0.26f);
        public float lrCoreAlpha = 0.95f;
        [Tooltip("蓄势预览时的强度上限（透明度/宽度倍率）")]
        public float previewIntensityMax = 0.6f;

        [Header("Color (auto by Mode)")]
        public Color redCore = new Color(1.0f, 0.25f, 0.20f, 1f);
        public Color redGlow = new Color(1.0f, 0.45f, 0.10f, 0.9f);
        public Color greenCore = new Color(0.70f, 1.00f, 0.80f, 1f);
        public Color greenGlow = new Color(0.20f, 1.00f, 0.60f, 0.9f);
        private Color coreColor, glowColor;

        public Transform tipTrail;
        public bool autoEnableTrail = true;
        [Tooltip("收招后刀光淡出时长（观赏性）")] public float lingerBladeFade = 0.25f;

        [Header("Root Motion（步进）")]
        public float cleaveStepForward = 0.55f;
        public float launchStepForward = 0.48f;
        public float smallThrustStep = 0.35f;
        public float recoilBack = 0.22f;

        [Header("HitStop / SlowMo")]
        public bool enableHitStop = true;
        [Tooltip("命中时的慢动作时间比例（越小越慢）")]
        public float hitStopTimeScale = 0.12f;
        [Tooltip("全局慢动作固定持续时间（秒）")]
        public float globalSlowDuration = 0.22f;

        [Header("Aim / 方向手感")]
        public float aimSmooth = 16f;

        [Header("Ground Check (for Air Plunge)")]
        public Transform groundCheck;
        public float groundCheckRadius = 0.12f;
        public LayerMask groundMask;
        public float airPlungeGravityMul = 1.8f;
        public float airPlungeDownImpulse = -8.0f;

        [Header("Sorting")]
        public int sortingOrderCore = 20;
        public int sortingOrderGlow1 = 19;
        public int sortingOrderGlow2 = 18;

        // Runtime
        private static readonly Collider2D[] _hitsBuffer = new Collider2D[64];
        private LineRenderer _lrCore, _lrGlow1, _lrGlow2;
        private TrailRenderer _trail;
        private PlayerColorModeController _mode;
        private Rigidbody2D _rb;
        private Camera _cam;

        // Camera shake (reflection-based, no hard dependency)
        private static System.Reflection.MethodInfo _shakeMI;
        private static void TryShake(float duration, float strength, float frequency)
        {
            if (_shakeMI == null)
            {
                var t = System.Type.GetType("CameraShake2D") ?? System.Type.GetType("FadedDreams.Enemies.CameraShake2D");
                if (t != null) _shakeMI = t.GetMethod("Shake", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
            }
            if (_shakeMI != null)
            {
                try { _shakeMI.Invoke(null, new object[] { duration, strength, frequency }); } catch { }
            }
        }

        private int _comboStep = 0;
        private float _lastComboTime = -999f;
        private bool _bufferedInput;
        private float _bufferUntil;
        private bool _busy;

        private readonly HashSetFaded _hitSet = new();
        private readonly HashSetFaded _thrustHitSet = new(); // per-thrust

        // ==== 全局慢动作并发管理（确保必恢复） ====
        private static int _slowRefCount = 0;
        private static float _savedTimeScale = 1f;
        private static float _savedFixedDelta = 0.02f;

        private static void SlowMoEnter(float slowScale)
        {
            if (_slowRefCount == 0)
            {
                _savedTimeScale = Time.timeScale;
                _savedFixedDelta = Time.fixedDeltaTime;
            }
            _slowRefCount++;
            Time.timeScale = Mathf.Clamp(slowScale, 0.05f, 1f);
            Time.fixedDeltaTime = _savedFixedDelta * Time.timeScale;
        }

        private static void SlowMoExit()
        {
            _slowRefCount = Mathf.Max(0, _slowRefCount - 1);
            if (_slowRefCount == 0)
            {
                Time.timeScale = _savedTimeScale;
                Time.fixedDeltaTime = _savedFixedDelta;
            }
        }

        // 命中触发的0.3秒全局慢动作
        private IEnumerator CoGlobalSlowMo(float seconds, float slowScale)
        {
            SlowMoEnter(slowScale);
            yield return new WaitForSecondsRealtime(seconds);
            SlowMoExit();
        }

        // aim smoothing
        private Vector2 _smoothedAim = Vector2.right;
        // 在 pos 处重新开始一条干净的拖尾
        private void TrailBeginAt(Vector3 pos)
        {
            if (_trail == null) return;
            _trail.Clear();
            tipTrail.position = pos;
            _trail.enabled = true;
            _trail.emitting = true;
        }
        private void TrailStop()
        {
            if (_trail == null) return;
            _trail.emitting = false;
            _trail.enabled = false;
        }

        private void Awake()
        {
            _mode = GetComponentInParent<PlayerColorModeController>();
            _rb = GetComponentInParent<Rigidbody2D>();
            _cam = Camera.main != null ? Camera.main : FindFirstObjectByType<Camera>();

            _lrCore = GetComponent<LineRenderer>();
            SetupLR(_lrCore, sortingOrderCore);
            _lrCore.enabled = false;

            _lrGlow1 = CreateChildLR("_Glow1", sortingOrderGlow1);
            _lrGlow2 = CreateChildLR("_Glow2", sortingOrderGlow2);

            if (tipTrail) _trail = tipTrail.GetComponent<TrailRenderer>();
        }

        private void OnEnable()
        {
            if (_mode == null) _mode = GetComponentInParent<PlayerColorModeController>();
            if (_mode != null)
            {
                _mode.OnModeChanged.AddListener(OnModeChanged);
                OnModeChanged(_mode.Mode);
            }
        }

        private void OnDisable()
        {
            if (_mode != null) _mode.OnModeChanged.RemoveListener(OnModeChanged);
        }

        private void OnModeChanged(ColorMode m)
        {
            if (m == ColorMode.Red) { coreColor = redCore; glowColor = redGlow; }
            else { coreColor = greenCore; glowColor = greenGlow; }
        }

        private void Update()
        {
            if (_mode == null || _mode.Mode != ColorMode.Red) return;

            // 方向平滑
            Vector2 aimNow = AimDirRaw();
            _smoothedAim = Vector2.Lerp(_smoothedAim, aimNow, 1f - Mathf.Exp(-aimSmooth * Time.deltaTime));

            if (Input.GetKeyDown(inputKey))
            {
                _bufferedInput = true;
                _bufferUntil = Time.unscaledTime + inputBuffer;
            }

            if (_busy) return;

            if (_bufferedInput && Time.unscaledTime <= _bufferUntil)
            {
                _bufferedInput = false;
                HandleComboInput();
            }
        }

        private void HandleComboInput()
        {
            if (!_mode.TrySpendAttackCost()) return;

            float now = Time.unscaledTime;
            bool withinCombo = (now - _lastComboTime) <= comboWindow;
            if (!withinCombo) _comboStep = 0;
            _comboStep = Mathf.Clamp(_comboStep + 1, 1, 4);
            _lastComboTime = now;

            switch (_comboStep)
            {
                case 1: StartCoroutine(CoDownCleave(+1)); break;   // 下劈：顺时针（+1）
                case 2: StartCoroutine(CoDownCleave(-1)); break;   // 上挑：反向（-1）
                case 3: StartCoroutine(CoTripleStab()); break;     // 三次小刺
                case 4: StartCoroutine(CoMegaThrust()); break;     // 超级大刺
            }
        }

        // ①/② 弧斩：dirSign = +1 顺时针（下劈感），-1 逆时针（上挑感）
        private IEnumerator CoDownCleave(int dirSign)
        {
            _busy = true;
            if (companion) companion.AttachTo(bladeOrigin ? bladeOrigin : transform);
            if (tipTrail && autoEnableTrail) TrailStop();
            Vector2 baseAim = _smoothedAim;
            yield return CoWindupPreview(baseAim, cleaveWindup);
            bool grounded = IsGrounded();
            if (tipTrail && autoEnableTrail) TrailBeginAt(BladeOriginPos());

            float originalGravity = 0f;
            if (!grounded && _rb)
            {
                originalGravity = _rb.gravityScale;
                _rb.gravityScale = originalGravity * airPlungeGravityMul;
                var v = _rb.linearVelocity; v.y = airPlungeDownImpulse; _rb.linearVelocity = v;
            }

            float elapsed = 0f, total = cleaveSwing, half = sectorAngle * 0.5f;
            EnableBeams(true);

            while (elapsed < total)
            {
                elapsed += Time.deltaTime;
                float u = Mathf.Clamp01(elapsed / total);
                float eased = swingEase.Evaluate(u);
                // 方向弧线：顺/逆反向
                float from = dirSign > 0 ? +half : -half;
                float to = dirSign > 0 ? -half : +half;
                Vector2 dir = Rotate(baseAim, Mathf.Lerp(from, to, eased));

                RootStep(dir, cleaveStepForward * Time.deltaTime / total);

                var tip = DrawBlade(dir, sectorRadius, u);
                if (companion) companion.FollowTip(tip);

                bool hit = DoSectorHits(BladeOriginPos(), dir, sectorRadius, baseDamage * (dirSign > 0 ? 1f : launcherDamageMul), true, dirSign < 0);
                if (hit && enableHitStop) StartCoroutine(CoGlobalSlowMo(globalSlowDuration, hitStopTimeScale));

                yield return null;
            }
            StartCoroutine(CoLinger(lingerBladeFade));
            TryShake(0.11f, 0.22f, 18f);

            SmallRecoil(baseAim, recoilBack);
            yield return WaitScaled(Mathf.Max(0f, cleaveRecover - earlyComboOpen));
            _lastComboTime = Time.unscaledTime;
            yield return WaitScaled(earlyComboOpen);

            if (!grounded)
            {
                float t = 0.25f;
                while (t > 0f && !IsGrounded()) { t -= Time.deltaTime; yield return null; }
                if (IsGrounded()) SpawnGroundShock(transform.position, bigCleaveAoERadius, baseDamage * bigCleaveAoEDamageMul);
                if (_rb) _rb.gravityScale = originalGravity > 0f ? originalGravity : _rb.gravityScale;
            }

            EndStep(baseAim);
        }

        // ③ 三次小刺：短距离三连突进
        private IEnumerator CoTripleStab()
        {
            _busy = true;
            if (companion) companion.AttachTo(bladeOrigin ? bladeOrigin : transform);
            Vector2 baseAim = _smoothedAim;

            for (int i = 0; i < 3; i++)
            {
                if (tipTrail && autoEnableTrail) { TrailStop(); TrailBeginAt(BladeOriginPos()); }
                Vector2 dir = SoftLockDir(_smoothedAim, softLockAngle, softLockRadius);
                yield return CoWindupPreview(dir, smallThrustWindup, thrust: true);
                yield return DoThrust(dir, smallThrustDistance, smallThrustDuration, baseDamage * 0.85f, false);
                TryShake(0.08f, 0.18f, 18f);
                SmallRecoil(dir, recoilBack * 0.66f);
                if (i < 2) yield return WaitScaled(smallThrustGap); // 间隔
            }

            yield return WaitScaled(Mathf.Max(0f, smallThrustRecover - earlyComboOpen));
            _lastComboTime = Time.unscaledTime;
            yield return WaitScaled(earlyComboOpen);
            EndStep(baseAim);
        }

        // ④ 超级大刺：更长距离/更高伤害/短无敌
        private IEnumerator CoMegaThrust()
        {
            _busy = true;
            if (companion) companion.AttachTo(bladeOrigin ? bladeOrigin : transform);
            Vector2 dir = SoftLockDir(_smoothedAim, softLockAngle, softLockRadius);

            if (tipTrail && autoEnableTrail) { TrailStop(); TrailBeginAt(BladeOriginPos()); }
            yield return CoWindupPreview(dir, megaWindup, thrust: true);
            yield return DoThrust(dir, megaThrustDistance, megaDuration, baseDamage * thrustDamageMul * 1.35f, true);
            TryShake(0.16f, 0.35f, 14f);
            SmallRecoil(dir, recoilBack);

            yield return WaitScaled(Mathf.Max(0f, megaRecover - earlyComboOpen));
            _lastComboTime = Time.unscaledTime;
            yield return WaitScaled(earlyComboOpen);
            EndStep(dir);
        }

        // 统一的突进实现（可被③/④复用）
        private IEnumerator DoThrust(Vector2 dir, float distance, float duration, float damage, bool strong)
        {
            _thrustHitSet.Clear();
            Vector3 start = transform.position;
            Vector3 end = start + (Vector3)(dir.normalized * distance);

            StartCoroutine(CoIFRames(thrustIFRames * (strong ? 1.25f : 1f)));
            EnableBeams(true);

            float elapsed = 0f;
            Vector3 prev = start;
            bool blocked = false;

            while (elapsed < duration && !blocked)
            {
                elapsed += Time.unscaledDeltaTime;
                float u = Mathf.Clamp01(elapsed / duration);
                Vector3 p = Vector3.Lerp(start, end, u);
                if (_rb) _rb.MovePosition(p);

                Vector3 moveDir = (p - prev);
                float segLen = moveDir.magnitude + 0.0001f;
                Vector3 step = moveDir.normalized * Mathf.Max(sampleStep, hitRadius * 0.8f);
                for (float d = 0f; d <= segLen; d += step.magnitude)
                {
                    Vector3 probe = prev + moveDir.normalized * d;
                    if (DoPointHits(probe, damage, dir))
                    {
                        blocked = true;
                        if (enableHitStop) StartCoroutine(CoGlobalSlowMo(globalSlowDuration, hitStopTimeScale));
                        break;
                    }
                }

                var tip = DrawBlade(dir, sectorRadius * (strong ? 0.9f : 0.7f), u, lineLengthOverride: (p - start).magnitude);
                if (companion) companion.FollowTip(tip);

                prev = p;
                yield return null;
            }

            StartCoroutine(CoLinger(lingerBladeFade * (strong ? 1.25f : 1f)));
        }

        /// <summary>沿攻击方向的小幅位移（替代动画 RootMotion）</summary>
        private void RootStep(Vector2 dir, float step)
        {
            if (_rb) _rb.MovePosition(_rb.position + dir.normalized * step);
        }

        /// <summary>收招小幅后撤</summary>
        private void SmallRecoil(Vector2 baseAim, float distance)
        {
            if (!_rb || distance <= 0f) return;
            _rb.MovePosition(_rb.position - baseAim.normalized * distance);
        }

        private bool DoSectorHits(Vector3 origin, Vector2 centerDir, float radius, float damage, bool knockback = true, bool applyLaunch = false)
        {
            bool hitAny = false;
            _hitSet.Clear();

            for (float r = sampleStep; r <= radius; r += sampleStep)
            {
                Vector3 p = origin + (Vector3)(centerDir.normalized * r);
                int __n = Physics2D.OverlapCircleNonAlloc(p, hitRadius, _hitsBuffer, hitMask);
                for (int __i = 0; __i < __n; __i++)
                {
                    var c = _hitsBuffer[__i];
                    var dmg = c.GetComponentInParent<FadedDreams.Enemies.IDamageable>();
                    if (dmg == null || dmg.IsDead || _hitSet.Contains(dmg)) continue;
                    _hitSet.Add(dmg);
                    dmg.TakeDamage(damage);
                    hitAny = true;

                    var rb = c.attachedRigidbody ? c.attachedRigidbody : c.GetComponentInParent<Rigidbody2D>();
                    if (rb)
                    {
                        if (applyLaunch)
                        {
                            var v = rb.linearVelocity; v.y = Mathf.Max(v.y, knockupOnLaunch); rb.linearVelocity = v;
                        }
                        else if (knockback)
                        {
                            Vector2 push = ((Vector2)rb.worldCenterOfMass - (Vector2)origin).normalized * knockbackForce;
                            rb.AddForce(push + Vector2.up * 0.8f, ForceMode2D.Impulse);
                        }
                    }
                }
            }
            return hitAny;
        }

        private bool DoPointHits(Vector3 point, float damage, Vector2 moveDir)
        {
            int __n2 = Physics2D.OverlapCircleNonAlloc(point, hitRadius, _hitsBuffer, hitMask);
            for (int __j = 0; __j < __n2; __j++)
            {
                var c = _hitsBuffer[__j];
                var dmg = c.GetComponentInParent<FadedDreams.Enemies.IDamageable>();
                if (dmg != null && !dmg.IsDead)
                {
                    if (_thrustHitSet.Contains(dmg)) continue;
                    _thrustHitSet.Add(dmg);

                    bool large = false;
                    if (useMassToDetectLarge)
                    {
                        var rbm = c.attachedRigidbody ? c.attachedRigidbody : c.GetComponentInParent<Rigidbody2D>();
                        if (rbm && rbm.mass >= largeMassThreshold) large = true;
                    }
                    if (!large && c.bounds.size.magnitude >= largeBoundsSize) large = true;

                    dmg.TakeDamage(damage);

                    var rb2 = c.attachedRigidbody ? c.attachedRigidbody : c.GetComponentInParent<Rigidbody2D>();
                    if (rb2)
                    {
                        Vector2 push = moveDir.normalized * (large ? 3.0f : 5.0f);
                        rb2.AddForce(push, ForceMode2D.Impulse);
                    }
                    if (large)
                    {
                        if (_rb)
                        {
                            Vector2 to = (Vector2)point - (Vector2)_rb.worldCenterOfMass;
                            float len = Mathf.Max(0f, to.magnitude - 0.2f);
                            _rb.MovePosition(_rb.position + to.normalized * len);
                        }
                        return true; // 阻挡，提前结束
                    }
                }
            }
            return false;
        }

        private void SpawnGroundShock(Vector3 center, float radius, float damage)
        {
            int __n3 = Physics2D.OverlapCircleNonAlloc(center, radius, _hitsBuffer, hitMask);
            for (int __k = 0; __k < __n3; __k++)
            {
                var c = _hitsBuffer[__k];
                var d = c.GetComponentInParent<FadedDreams.Enemies.IDamageable>();
                if (d != null && !d.IsDead) d.TakeDamage(damage);
                var rb = c.attachedRigidbody ? c.attachedRigidbody : c.GetComponentInParent<Rigidbody2D>();
                if (rb) rb.AddForce((rb.worldCenterOfMass - (Vector2)center).normalized * 4f, ForceMode2D.Impulse);
            }
        }

        private void EnableBeams(bool on)
        {
            _lrCore.enabled = on;
            _lrGlow1.enabled = on;
            _lrGlow2.enabled = on;
            if (!on && tipTrail && autoEnableTrail && _trail)
            {
                _trail.emitting = false;
                _trail.enabled = false;
            }
        }

        private Vector3 DrawBlade(Vector2 dir, float len, float phase01, float lineLengthOverride = -1f)
        {
            Vector3 p0 = BladeOriginPos();
            Vector3 p1 = p0 + (Vector3)(dir.normalized * (lineLengthOverride > 0f ? lineLengthOverride : len));

            _lrCore.positionCount = 2; _lrCore.SetPosition(0, p0); _lrCore.SetPosition(1, p1);
            float w = widthByPhase.Evaluate(phase01);
            _lrCore.startWidth = w; _lrCore.endWidth = w * 0.92f;
            _lrCore.colorGradient = MakeGradient(coreColor, lrCoreAlpha);

            _lrGlow1.positionCount = 2; _lrGlow1.SetPosition(0, p0); _lrGlow1.SetPosition(1, p1);
            _lrGlow1.startWidth = w * 1.6f; _lrGlow1.endWidth = w * 1.5f;
            _lrGlow1.colorGradient = MakeGradient(Color.Lerp(coreColor, glowColor, 0.6f), Mathf.Lerp(0.55f, 0.85f, phase01));

            _lrGlow2.positionCount = 2; _lrGlow2.SetPosition(0, p0); _lrGlow2.SetPosition(1, p1);
            _lrGlow2.startWidth = w * 2.3f; _lrGlow2.endWidth = w * 2.2f;
            _lrGlow2.colorGradient = MakeGradient(Color.Lerp(coreColor, glowColor, 0.8f), Mathf.Lerp(0.35f, 0.65f, phase01));

            if (tipTrail) tipTrail.position = p1;
            return p1;
        }

        private IEnumerator CoWindupPreview(Vector2 dir, float duration, bool thrust = false)
        {
            EnableBeams(true);
            float t = 0f;
            while (t < duration)
            {
                t += Time.deltaTime;
                float u = Mathf.Clamp01(t / duration);
                float eased = swingEase.Evaluate(u);
                float len = Mathf.Lerp(sectorRadius * (thrust ? 0.30f : 0.40f), sectorRadius * (thrust ? 0.70f : 0.90f), eased);
                DrawBladePreview(dir, len, Mathf.Lerp(0.25f, previewIntensityMax, eased), thrust);
                yield return null;
            }
        }

        private void DrawBladePreview(Vector2 dir, float len, float intensity01, bool thrust)
        {
            Vector3 p0 = BladeOriginPos();
            Vector3 p1 = p0 + (Vector3)(dir.normalized * len);

            float w = widthByPhase.Evaluate(0f) * Mathf.Lerp(thrust ? 0.8f : 1f, 1.35f, intensity01);

            _lrCore.positionCount = 2; _lrCore.SetPosition(0, p0); _lrCore.SetPosition(1, p1);
            _lrCore.startWidth = w; _lrCore.endWidth = w * 0.92f;
            _lrCore.colorGradient = MakeGradient(coreColor, lrCoreAlpha * intensity01 * 0.85f);

            _lrGlow1.positionCount = 2; _lrGlow1.SetPosition(0, p0); _lrGlow1.SetPosition(1, p1);
            _lrGlow1.startWidth = w * 1.45f; _lrGlow1.endWidth = w * 1.35f;
            _lrGlow1.colorGradient = MakeGradient(Color.Lerp(coreColor, glowColor, 0.6f), intensity01 * 0.75f);

            _lrGlow2.positionCount = 2; _lrGlow2.SetPosition(0, p0); _lrGlow2.SetPosition(1, p1);
            _lrGlow2.startWidth = w * 2.1f; _lrGlow2.endWidth = w * 2.0f;
            _lrGlow2.colorGradient = MakeGradient(Color.Lerp(coreColor, glowColor, 0.8f), intensity01 * 0.6f);

            if (tipTrail) tipTrail.position = p1;
        }

        private System.Collections.IEnumerator CoLinger(float fade)
        {
            float t = 0f;
            float w0 = _lrCore.startWidth, w1 = _lrGlow1.startWidth, w2 = _lrGlow2.startWidth;
            while (t < fade)
            {
                t += Time.deltaTime;
                float u2 = Mathf.Clamp01(t / fade);
                _lrCore.startWidth = Mathf.Lerp(w0, 0f, u2);
                _lrGlow1.startWidth = Mathf.Lerp(w1, 0f, u2);
                _lrGlow2.startWidth = Mathf.Lerp(w2, 0f, u2);
                yield return null;
            }
            EnableBeams(false);
        }

        private Gradient MakeGradient(Color c, float a = 1f)
        {
            var g = new Gradient();
            g.SetKeys(
                new GradientColorKey[] { new GradientColorKey(c, 0f), new GradientColorKey(c, 1f) },
                new GradientAlphaKey[] { new GradientAlphaKey(a, 0f), new GradientAlphaKey(a * 0.9f, 1f) }
            );
            return g;
        }

        private Vector3 BladeOriginPos() => bladeOrigin ? bladeOrigin.position : transform.position;

        private Vector2 AimDirRaw()
        {
            if (_cam == null) _cam = Camera.main != null ? Camera.main : FindFirstObjectByType<Camera>();
            Vector3 mp = Input.mousePosition;
            float depth = Mathf.Abs((_cam ? _cam.transform.position.z : 0f) - BladeOriginPos().z);
            mp.z = depth <= 0.001f ? 10f : depth;
            Vector3 world = _cam ? _cam.ScreenToWorldPoint(mp) : (Vector3)transform.right + BladeOriginPos();
            world.z = BladeOriginPos().z;
            return (world - BladeOriginPos()).normalized;
        }

        private Vector2 AimDir() => _smoothedAim.sqrMagnitude > 0.001f ? _smoothedAim.normalized : Vector2.right;

        private Vector2 SoftLockDir(Vector2 aimDir, float maxAngle, float radius)
        {
            Collider2D best = null;
            float bestSqr = float.MaxValue;
            var cols = Physics2D.OverlapCircleAll(transform.position, radius, hitMask);
            foreach (var c in cols)
            {
                Vector2 d = (Vector2)c.bounds.center - (Vector2)transform.position;
                float ang = Vector2.Angle(aimDir, d);
                if (ang <= maxAngle)
                {
                    float s = d.sqrMagnitude;
                    if (s < bestSqr) { bestSqr = s; best = c; }
                }
            }
            if (!best) return aimDir;

            Vector2 to = ((Vector2)best.bounds.center - (Vector2)transform.position).normalized;
            float delta = Vector2.SignedAngle(aimDir, to);
            float clamp = Mathf.Clamp(delta, -8f, 8f);
            return Rotate(aimDir, clamp);
        }

        private Vector2 Rotate(Vector2 v, float degrees)
        {
            float rad = degrees * Mathf.Deg2Rad;
            float ca = Mathf.Cos(rad), sa = Mathf.Sin(rad);
            return new Vector2(ca * v.x - sa * v.y, sa * v.x + ca * v.y);
        }

        private bool IsGrounded()
        {
            if (!groundCheck) return false;
            return Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundMask);
        }

        private IEnumerator CoIFRames(float seconds)
        {
            yield return new WaitForSecondsRealtime(seconds);
        }

        private void EndStep(Vector2 lastDir)
        {
            _busy = false;
            _lastComboTime = Time.unscaledTime;
            if (_comboStep >= 4) _comboStep = 0;
            if (companion)
            {
                companion.ReturnToOrbitDelayed(comboWindow * 0.6f);
                companion.TransitionFlourish(lastDir);
            }
        }

        private void SetupLR(LineRenderer lr, int sortingOrder)
        {
            lr.useWorldSpace = true;
            lr.alignment = LineAlignment.View;
            lr.numCapVertices = 8; lr.numCornerVertices = 4;
            lr.textureMode = LineTextureMode.Stretch;
            lr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            lr.receiveShadows = false;
            lr.sortingOrder = sortingOrder;
        }

        private LineRenderer CreateChildLR(string name, int sortingOrder)
        {
            var go = new GameObject(name);
            go.transform.SetParent(transform, false);
            var lr = go.AddComponent<LineRenderer>();
            SetupLR(lr, sortingOrder);
            lr.material = _lrCore ? _lrCore.material : null;
            lr.enabled = false;
            return lr;
        }

        private IEnumerator WaitScaled(float sec)
        {
            float t = 0f;
            while (t < sec) { t += Time.unscaledDeltaTime; yield return null; }
        }

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(1, 0, 0, 0.25f);
            Vector2 aim = Application.isPlaying ? AimDir() : Vector2.right;
            float half = sectorAngle * 0.5f;
            Vector3 c = transform.position;
            Vector3 a = c + (Vector3)Rotate(aim, -half) * sectorRadius;
            Vector3 b = c + (Vector3)Rotate(aim, half) * sectorRadius;
            Gizmos.DrawLine(c, a); Gizmos.DrawLine(c, b);
            Vector3 prev = a;
            for (int i = 1; i <= 20; i++)
            {
                float tt = -half + (sectorAngle) * (i / 20f);
                Vector3 p = c + (Vector3)Rotate(aim, tt) * sectorRadius;
                Gizmos.DrawLine(prev, p);
                prev = p;
            }
        }
#endif

        // ======== 小工具：更紧凑的 HashSet 别名，避免长泛型名占行 ========



        private class HashSetFaded : HashSet<FadedDreams.Enemies.IDamageable> { }
    }
}
