#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using FD.Bosses.C3.Data;

namespace FD.Bosses.C3.EditorTools
{
    public class ActionAssetAutoBuilder_Upgraded
    {
        [MenuItem("FD/Boss/Upgrade C3 Action Patterns (Big Flair)")]
        public static void Upgrade()
        {
            string dir = "Assets/Boss_C3_Data";
            var guids = AssetDatabase.FindAssets("t:BossActionData", new[] { dir });
            int count = 0;
            foreach (var g in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(g);
                var a = AssetDatabase.LoadAssetAtPath<BossActionData>(path);
                if (!a) continue;

                // build pattern and persist as sub-asset of the action
                var p = BuildBigPattern(a.actionId, a.phase == BossPhase.P2, a.color);
                p.name = $"{a.name}_OrbPattern";
                AssetDatabase.AddObjectToAsset(p, a);
                p.hideFlags = HideFlags.HideInHierarchy;
                a.orbPattern = p;

                EditorUtility.SetDirty(p);
                EditorUtility.SetDirty(a);
                count++;
            }
            AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
            EditorUtility.DisplayDialog("FD", $"已升级 {count} 个 Action 的环绕体编舞（更大幅度、更显眼）", "OK");
        }

        static OrbPatternData BuildBigPattern(int id, bool six, BossColor color)
        {
            var p = ScriptableObject.CreateInstance<OrbPatternData>();
            p.phase2SixOrbs = six;
            var col = (color == BossColor.Red) ? new Color(1f, 0.35f, 0.35f, 1f) : new Color(0.35f, 1f, 0.35f, 1f);
            float baseR = six ? 2.2f : 1.8f;
            float bigR = six ? 3.2f : 2.8f;
            float tell = (id < 200) ? 0.38f : 0.30f;

            p.keyframes = new[]
            {
                new OrbKeyframe{ t=-tell,    motion=OrbMotion.Gather, radius=baseR*0.8f,  duration=tell*0.65f, color=col, brightness=0.95f, note="tell gather"},
                new OrbKeyframe{ t=-0.16f,   motion=OrbMotion.Pulse,  radius=baseR,      duration=0.16f,      color=col, brightness=1.0f,  lockFormation=true, note="pre-fire pulse"},
                new OrbKeyframe{ t=0f,       motion=OrbMotion.Spread, radius=bigR,       duration=0.12f,      color=col, brightness=1.0f,  note="fire spread big"},
                new OrbKeyframe{ t=0.02f,    motion=OrbMotion.Spin,   radius=bigR,       duration=0.28f,      color=col, brightness=1.0f,  note="fire spin"},
                new OrbKeyframe{ t=0.24f,    motion=OrbMotion.Gather, radius=baseR*1.05f,duration=0.18f,      color=col, brightness=0.9f,  note="settle"}
            };
            return p;
        }
    }
}
#endif