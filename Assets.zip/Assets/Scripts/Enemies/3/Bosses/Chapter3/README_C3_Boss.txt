Quick Setup:
1) Add components to Boss root: BossChapter3Controller, BossHealth, BossPoiseSystem, BossPhaseController, BossActionExecutor, BossAI, BossColorSystem, BossStateMachine.
2) Build assets via menu: FD/Boss/Build All Action & Pattern Assets. Assign ActionSetHolder.tuning and .actions to controller.
3) Add OrbRingController + OrbAgent(4) & OrbAgent(6) children. Give orbs a SpriteRenderer or MeshRenderer; OrbMaterialDriver handles emission.
4) On Player, add PlayerColorBridge (or implement IPlayerColorProvider yourself). Drag it to controller.playerProvider.
