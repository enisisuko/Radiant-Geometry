namespace FD.Bosses.C3.SM {
  public class State_PhaseShift : IState {
    BossStateMachine fsm; float t; public State_PhaseShift(BossStateMachine m){ fsm=m; }
    public void OnEnter(){ t=0f; }
    public void OnExit(){ }
    public void Tick(float dt){ t+=dt; if(t>=1.2f) fsm.Pop(); }
    public bool CanInterrupt => false;
  }
  public class State_Staggered : IState {
    BossStateMachine fsm; float t; float dur=3.0f; public State_Staggered(BossStateMachine m){ fsm=m; }
    public void OnEnter(){ t=0f; }
    public void OnExit(){ }
    public void Tick(float dt){ t+=dt; if(t>=dur) fsm.Pop(); }
    public bool CanInterrupt => false;
  }
}
