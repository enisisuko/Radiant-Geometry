using UnityEngine;
namespace FD.Bosses.C3.Integration {
  public class CameraCueAdapter : MonoBehaviour {
    public void FovKick(float addPercent, float inTime, float outTime){}
    public void Shake(float amp, float freq, float dur){}
  }
}
