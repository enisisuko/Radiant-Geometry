using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_WHIRLWIND : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else done = true;
    }
    IEnumerator Do(){
      float dur = Mathf.Max(1.0f, Data!=null && Data.activeTime>0?Data.activeTime:1.2f);
      Vector3 pos = ctx ? ctx.transform.position + ctx.transform.up * 1.2f : Vector3.zero;
      Vector3 dir = ctx ? (ctx.player ? (ctx.player.position - ctx.transform.position).normalized : ctx.transform.up) : Vector3.up;
      float speed = 6.0f; float t=0;
      while(t<dur){
        t+=Time.deltaTime; pos += dir * speed * Time.deltaTime;
        if (ctx) BossActionHelpers.TryHitPlayerCircle(ctx, pos, 1.0f, Data.damage);
        yield return null;
      }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data!=null?Data.recoverTime*0.25f:0.1f));
      base.StartRecover();
    }
  }
}