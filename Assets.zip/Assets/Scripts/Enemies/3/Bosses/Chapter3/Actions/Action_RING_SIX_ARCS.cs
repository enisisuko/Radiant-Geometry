using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_RING_SIX_ARCS : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else done = true;
    }
    IEnumerator Do(){
      int rays=6; float arcDur=Mathf.Max(0.5f, Data.activeTime>0?Data.activeTime:0.6f);
      float len=9f; Vector3 c=ctx.transform.position; float t=0;
      while(t<arcDur){ t+=Time.deltaTime;
        for(int i=0;i<rays;i++){ Vector3 dir = Quaternion.Euler(0, i*(360f/rays), 0) * Vector3.forward;
          var p = c + dir * Mathf.Lerp(0, len, t/arcDur); BossActionHelpers.TryHitPlayerCircle(ctx, p, 0.7f, Data.damage); }
        yield return null; }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime*0.25f));
      base.StartRecover();
    }
  }
}