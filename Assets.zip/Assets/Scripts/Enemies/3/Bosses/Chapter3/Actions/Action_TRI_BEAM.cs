using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_TRI_BEAM : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else done = true;
    }
    IEnumerator Do(){
      float dur = Mathf.Max(0.6f, Data.activeTime>0?Data.activeTime:0.7f);
      float arc=40f; int beams=3; float t=0; Vector3 o = ctx.transform.position;
      while(t<dur){ t+=Time.deltaTime;
        for(int b=0;b<beams;b++){ float a = -arc + (arc*2f)*(b/(float)(beams-1));
          Vector3 dir = Quaternion.Euler(0,a,0)*ctx.transform.forward; var p = o + dir * 10f;
          BossActionHelpers.TryHitPlayerCircle(ctx, p, 0.7f, Data.damage); }
        yield return null; }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime*0.25f));
      base.StartRecover();
    }
  }
}