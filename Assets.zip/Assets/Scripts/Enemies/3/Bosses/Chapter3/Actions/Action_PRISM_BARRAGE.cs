using UnityEngine;
using System.Collections;
using FD.Bosses.C3.Integration;

namespace FD.Bosses.C3.Actions {
  public class Action_PRISM_BARRAGE : BaseBossAction {
    private Coroutine routine;
    private Transform T => ctx.transform;
    private BossVFXRouter vfx; private BossSFXRouter sfx; private CameraCueAdapter cam;

    [Header("Hit Settings")]
    public LayerMask playerMask;
    public float damage = 18f;
    public float hitRadius = 0.6f;
    public int capsuleSamples = 6;
    
    void Awake(){ vfx = GetComponent<BossVFXRouter>(); sfx = GetComponent<BossSFXRouter>(); cam = GetComponent<CameraCueAdapter>(); }

    public override void StartTell() { 
      base.StartTell(); 
      // Face player
      var p = ctx.playerProvider != null ? ctx.playerProvider.PlayerTransform : ctx.player;
      if(p) {
        var dir = (p.position - T.position);
        if(dir.sqrMagnitude>0.0001f) {
          var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg - 90f;
          T.rotation = Quaternion.Euler(0,0, angle);
        }
      }
      if(sfx) sfx.Play("tell_"+nameof(Action_PRISM_BARRAGE), T.position);
    }

    public override void StartActive() { 
      base.StartActive(); // ensure orb choreo triggers
      if(routine!=null) StopCoroutine(routine);
      if(vfx) vfx.Play("fire_"+nameof(Action_PRISM_BARRAGE), T.position);
      if(cam) cam.FovKick(0.08f, 0.2f, 0.3f);
      routine = StartCoroutine(DoAction());
    }

    public override void StartRecover() { 
      if(routine!=null) StopCoroutine(routine);
      base.StartRecover();
    }

    private IEnumerator DoAction() {
      float recover = Data!=null && Data.recoverTime>0 ? Data.recoverTime : 0.25f;
      yield return null; 
      float el=0; 
      while(el<0.6f){ el+=Time.deltaTime; yield return null; }
      // delayed strike at current position
      HitAtSelf();
      yield return new WaitForSeconds(Mathf.Max(0.01f, recover*0.25f));
      base.StartRecover();
    }

    // ---- Hit helpers per frame ----
    private void HitForwardCapsule(float dist) {
      Vector2 a = T.position;
      Vector2 b = a + (Vector2)T.up * dist;
      ActionCommon.HitCapsule(a,b,hitRadius, damage, playerMask.value, capsuleSamples);
    }
    private void HitAtSelf(){ ActionCommon.HitCircle(T.position, hitRadius, damage, playerMask.value); }
  }
}