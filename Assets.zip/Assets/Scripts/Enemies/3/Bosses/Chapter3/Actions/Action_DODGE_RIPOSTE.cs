using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_DODGE_RIPOSTE : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else { done = true; }
    }
    IEnumerator Do(){
      Vector3 start = ctx.transform.position;
      Vector3 side = Vector3.Cross(Vector3.up, BossActionHelpers.FlatDirTo(ctx, start)).normalized;
      Vector3 dodge = start + side * 2.0f;
      float t = 0f, dur = 0.12f;
      while (t < dur){ t += Time.deltaTime; ctx.transform.position = Vector3.Lerp(start, dodge, t / dur); yield return null; }
      Vector3 dir = BossActionHelpers.FlatDirTo(ctx, ctx.transform.position);
      float thrust = 3.0f; Vector3 end = ctx.transform.position + dir * thrust;
      t = 0f; dur = 0.18f;
      while (t < dur){
        t += Time.deltaTime;
        ctx.transform.position = Vector3.Lerp(dodge, end, t / dur);
        BossActionHelpers.TryHitPlayerCircle(ctx, ctx.transform.position, 0.8f, Data.damage);
        yield return null;
      }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime * 0.25f));
      base.StartRecover();
    }
  }
}