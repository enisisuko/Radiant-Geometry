using FD.Bosses.C3.Data;
namespace FD.Bosses.C3.Actions {
  public interface IBossAction {
    BossActionData Data { get; }
    void Init(Core.BossChapter3Controller ctx, BossActionData data);
    bool CanStart();
    void StartTell();
    void StartWindup();
    void StartActive();
    void StartRecover();
    void Abort();
    bool IsDone { get; }
  }
}