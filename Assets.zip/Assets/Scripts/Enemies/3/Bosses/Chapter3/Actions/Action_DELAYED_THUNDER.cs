using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_DELAYED_THUNDER : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else { done = true; }
    }
    IEnumerator Do(){
      Vector3 target = ctx && ctx.player ? ctx.player.position : (ctx ? ctx.transform.position + ctx.transform.forward * 3f : Vector3.zero);
      yield return new WaitForSeconds(Mathf.Max(0.2f, Data.tellTime > 0 ? Data.tellTime : 0.5f));
      float t = 0f, dur = Mathf.Max(0.6f, Data.activeTime > 0 ? Data.activeTime : 1.0f);
      while (t < dur){
        t += Time.deltaTime;
        BossActionHelpers.TryHitPlayerCircle(ctx, target, 0.9f, Data.damage);
        yield return null;
      }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime * 0.25f));
      base.StartRecover();
    }
  }
}