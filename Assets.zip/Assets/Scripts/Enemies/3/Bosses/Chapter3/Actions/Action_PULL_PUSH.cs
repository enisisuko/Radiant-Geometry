using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_PULL_PUSH : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else done = true;
    }
    IEnumerator Do(){
      float pullT=0.5f; float t=0;
      while(t<pullT){ t+=Time.deltaTime; BossActionHelpers.PullPlayerTowards(ctx, ctx.transform.position, 9f*Time.deltaTime); yield return null; }
      BossActionHelpers.PushPlayerAway(ctx, ctx.transform.position, 1.2f);
      BossActionHelpers.TryHitPlayerCircle(ctx, ctx.transform.position, 1.6f, Data.damage);
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime*0.25f));
      base.StartRecover();
    }
  }
}