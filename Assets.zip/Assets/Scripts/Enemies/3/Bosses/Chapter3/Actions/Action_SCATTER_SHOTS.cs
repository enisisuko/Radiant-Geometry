using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_SCATTER_SHOTS : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else done = true;
    }
    IEnumerator Do(){
      int shots=8; float arc=60f; float step = arc/(shots-1);
      Vector3 origin = ctx.transform.position + ctx.transform.forward*0.2f;
      for(int i=0;i<shots;i++){
        float ang = -arc*0.5f + step*i; Vector3 dir = Quaternion.Euler(0,ang,0)*ctx.transform.forward;
        float t=0; float dur=0.35f; float range=10f;
        while(t<dur){ t+=Time.deltaTime; var p = origin + dir* Mathf.Lerp(0, range, t/dur);
          BossActionHelpers.TryHitPlayerCircle(ctx, p, 0.5f, Data.damage); yield return null; }
        yield return new WaitForSeconds(0.05f);
      }
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime*0.25f));
      base.StartRecover();
    }
  }
}