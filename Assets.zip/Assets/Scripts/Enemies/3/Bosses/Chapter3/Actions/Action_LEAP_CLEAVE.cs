using System.Collections;
using UnityEngine;
namespace FD.Bosses.C3.Actions {
  public class Action_LEAP_CLEAVE : BaseBossAction {
    public override void StartActive(){
      base.StartActive();
      if (ctx) ctx.StartCoroutine(Do()); else { done = true; }
    }
    IEnumerator Do(){
      Vector3 start = ctx.transform.position; Vector3 dir = BossActionHelpers.FlatDirTo(ctx, start);
      float dist = 3.2f; Vector3 end = start + dir * dist; float h = 2.8f; float t = 0f; float dur = 0.45f;
      while (t < dur){
        t += Time.deltaTime; float k = t / dur; Vector3 pos = Vector3.Lerp(start, end, k);
        pos.y = Mathf.Sin(k * Mathf.PI) * h * 0.35f; ctx.transform.position = pos; yield return null;
      }
      BossActionHelpers.TryHitPlayerCircle(ctx, end, 1.2f, Data.damage);
      yield return new WaitForSeconds(Mathf.Max(0.01f, Data.recoverTime * 0.25f)); base.StartRecover();
    }
  }
}