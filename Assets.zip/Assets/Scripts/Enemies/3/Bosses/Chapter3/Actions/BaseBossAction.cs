using UnityEngine;
using FD.Bosses.C3.Core;
using FD.Bosses.C3.Data;
using FD.Bosses.C3.Orbs;
// 避免属性 Data 与命名空间 Data 冲突
using DataNS = FD.Bosses.C3.Data;

namespace FD.Bosses.C3.Actions
{
    public abstract class BaseBossAction : MonoBehaviour, IBossAction
    {
        [Header("Data")]
        [SerializeField] protected BossActionData data;

        [Header("Orb Patterns (optional overrides)")]
        public OrbPatternData orbPatternTell;
        public OrbPatternData orbPatternActive;
        public OrbPatternData orbPatternRecover;

        [Header("Fallback / Flare")]
        [Tooltip("当未找到主动段编舞时，是否用一个简易的 flare 兜底，避免完全静止")]
        public bool autoFlareOnActive = true;
        [Range(1.0f, 1.6f)] public float flareAmplitude = 1.15f;
        public float flareDuration = 0.4f;

        [Header("Debug")]
        public bool debugLogs = true;

        protected BossChapter3Controller ctx;
        protected bool done;

        public BossActionData Data => data;
        public bool IsDone => done;

        // 你的接口是两参数版本
        public virtual void Init(BossChapter3Controller controller, BossActionData actionData)
        {
            ctx = controller;
            data = actionData;
        }

        public virtual bool CanStart() => data != null;
        public virtual void Abort() { done = true; }

        public virtual void StartTell()
        {
            done = false;

            if (ctx && ctx.orbRing)
                ctx.orbRing.PreBlendColor(data != null ? data.color : BossColor.Red,
                                          Mathf.Max(0.18f, (data != null ? data.tellTime : 0.3f) * 0.6f));

            var tell = orbPatternTell ? orbPatternTell : (data ? data.orbPattern : null);

            bool fed = TryApplyPatternSegment(tell, Segment.Tell, data);
            if (!fed && ctx && ctx.orbRing)
            {
                var flare = MakeFlarePattern(ctx.phase == BossPhase.P2,
                                             data ? data.color : BossColor.Red,
                                             1.10f,
                                             Mathf.Max(0.18f, SafeTime(data?.tellTime)));
                ctx.orbRing.ApplyPattern(flare);
                if (debugLogs) Debug.Log("[BOSS][Action] Tell fallback flare.");
            }

            if (debugLogs) Debug.Log($"[BOSS][Action] {data?.displayName} -> TELL");
        }

        public virtual void StartWindup()
        {
            if (debugLogs) Debug.Log($"[BOSS][Action] {data?.displayName} -> WINDUP");
        }

        public virtual void StartActive()
        {
            var active = orbPatternActive ? orbPatternActive : (data ? data.orbPattern : null);

            bool fed = TryApplyPatternSegment(active, Segment.Active, data);

            if (!fed && autoFlareOnActive && ctx && ctx.orbRing)
            {
                var flare = MakeFlarePattern(ctx.phase == BossPhase.P2,
                                             data ? data.color : BossColor.Red,
                                             flareAmplitude,
                                             Mathf.Max(flareDuration, Mathf.Max(0.24f, SafeTime(data?.activeTime) * 0.6f)));
                ctx.orbRing.ApplyPattern(flare);
                if (debugLogs) Debug.Log("[BOSS][Action] Active fallback flare (no active pattern).");
            }

            if (debugLogs) Debug.Log($"[BOSS][Action] {data?.displayName} -> ACTIVE");
        }

        public virtual void StartRecover()
        {
            var rec = orbPatternRecover ? orbPatternRecover : (data ? data.orbPattern : null);

            TryApplyPatternSegment(rec, Segment.Recover, data);
            done = true;

            if (debugLogs) Debug.Log($"[BOSS][Action] {data?.displayName} -> RECOVER (done)");
        }

        // ----------------- Segment 裁剪核心 -----------------

        enum Segment { Tell, Active, Recover }

        bool TryApplyPatternSegment(OrbPatternData p, Segment seg, BossActionData timings)
        {
            if (ctx == null || ctx.orbRing == null || p == null || p.keyframes == null || p.keyframes.Length == 0)
                return false;

            // 1) notes
            var list = SliceByNotes(p, seg);
            string mode = "notes";

            // 2) t range
            if (list == null || list.Count == 0)
            {
                list = SliceByTRange(p, seg);
                mode = "t";
            }

            // 3) duration timeline
            if (list == null || list.Count == 0)
            {
                list = SliceByDurationTimeline(p, seg, timings);
                mode = "duration";
            }

            // 4) index fallback
            if (list == null || list.Count == 0)
            {
                list = SliceByIndexRatio(p, seg);
                mode = "index";
            }

            // ✅ 新增保险：如果只切出很少（≤2）帧，用 duration 再切一次
            if (list != null && list.Count <= 2)
            {
                var byDur = SliceByDurationTimeline(p, seg, timings);
                if (byDur != null && byDur.Count > list.Count)
                {
                    list = byDur;
                    mode = "duration*"; // 代表索引切太少，回退到按时长
                }
            }

            if (list == null || list.Count == 0) return false;

            var clone = ScriptableObject.CreateInstance<OrbPatternData>();
            clone.phase2SixOrbs = (ctx.phase == BossPhase.P2);
            clone.keyframes = list.ToArray();

            // 诊断信息：帧数 / 上锁数量
            int locked = 0;
            foreach (var k in list) if (k.lockFormation) locked++;

            if (debugLogs) Debug.Log($"[BOSS][Action] Apply {seg} pattern via {mode} ({clone.keyframes.Length} keys, locked={locked}).");

            ctx.orbRing.ApplyPattern(clone);
            return true;
        }

        // a) 通过 note 关键字识别
        System.Collections.Generic.List<DataNS.OrbKeyframe> SliceByNotes(OrbPatternData p, Segment seg)
        {
            var list = new System.Collections.Generic.List<DataNS.OrbKeyframe>();
            bool anyTagged = false;

            foreach (var k in p.keyframes)
            {
                string n = k.note ?? string.Empty;
                if (n.Length == 0) continue;
                anyTagged = true;

                bool pick = (seg == Segment.Tell && Contains(n, "TELL"))
                         || (seg == Segment.Active && (Contains(n, "ACTIVE") || Contains(n, "MAIN")))
                         || (seg == Segment.Recover && (Contains(n, "RECOVER") || Contains(n, "END")));
                if (pick) list.Add(k);
            }
            return anyTagged ? list : null;

            static bool Contains(string s, string tag)
                => s.IndexOf(tag, System.StringComparison.OrdinalIgnoreCase) >= 0
                || s.IndexOf($"[{tag}]", System.StringComparison.OrdinalIgnoreCase) >= 0;
        }

        // b) 通过 t 窗口
        System.Collections.Generic.List<DataNS.OrbKeyframe> SliceByTRange(OrbPatternData p, Segment seg)
        {
            float tMin, tMax;
            switch (seg)
            {
                case Segment.Tell: tMin = 0f; tMax = 0.51f; break;
                case Segment.Active: tMin = 0.51f; tMax = 0.95f; break;
                default: tMin = 0.95f; tMax = 99f; break;
            }

            bool anyNonZeroT = false;
            foreach (var k in p.keyframes) { if (k.t > 0.0001f) { anyNonZeroT = true; break; } }
            if (!anyNonZeroT) return null;

            var list = new System.Collections.Generic.List<DataNS.OrbKeyframe>();
            foreach (var k in p.keyframes)
                if (k.t >= tMin && k.t <= tMax) list.Add(k);
            return list;
        }

        // c) 通过累计 duration 的“时间线”切分
        System.Collections.Generic.List<DataNS.OrbKeyframe> SliceByDurationTimeline(OrbPatternData p, Segment seg, BossActionData t)
        {
            float tell = SafeTime(t?.tellTime);
            float wind = SafeTime(t?.windupTime);
            float act = SafeTime(t?.activeTime);
            float recv = SafeTime(t?.recoverTime);

            if (tell + wind + act + recv <= 0.0001f) { tell = 0.3f; wind = 0f; act = 0.5f; recv = 0.2f; }

            float sTell = 0f;
            float eTell = tell;
            float eWind = eTell + wind;
            float eAct = eWind + act;
            float eRecv = eAct + recv;

            float segStart = seg switch
            {
                Segment.Tell => sTell,
                Segment.Active => eTell + wind,
                _ => eAct
            };
            float segEnd = seg switch
            {
                Segment.Tell => eTell,
                Segment.Active => eAct,
                _ => eRecv + 999f
            };

            var list = new System.Collections.Generic.List<DataNS.OrbKeyframe>();
            float cursor = 0f;

            for (int i = 0; i < p.keyframes.Length; i++)
            {
                var k = p.keyframes[i];
                float d = k.duration > 0f ? k.duration : 0.1f;
                float mid = cursor + d * 0.5f;

                if (mid >= segStart && mid <= segEnd) list.Add(k);
                cursor += d;
            }
            return list;
        }

        // d) 最后兜底：按索引比例粗切
        System.Collections.Generic.List<DataNS.OrbKeyframe> SliceByIndexRatio(OrbPatternData p, Segment seg)
        {
            int n = p.keyframes.Length;
            if (n == 0) return null;

            int iTellEnd = Mathf.Clamp(Mathf.RoundToInt(n * 0.34f), 0, n);
            int iActEnd = Mathf.Clamp(Mathf.RoundToInt(n * 0.84f), 0, n);

            int i0 = seg switch { Segment.Tell => 0, Segment.Active => iTellEnd, _ => iActEnd };
            int i1 = seg switch { Segment.Tell => iTellEnd, Segment.Active => iActEnd, _ => n };

            var list = new System.Collections.Generic.List<DataNS.OrbKeyframe>(Mathf.Max(0, i1 - i0));
            for (int i = i0; i < i1; i++) list.Add(p.keyframes[i]);
            return list;
        }

        protected OrbPatternData MakeFlarePattern(bool six, BossColor color, float amplitude, float duration)
        {
            var pat = ScriptableObject.CreateInstance<OrbPatternData>();
            pat.phase2SixOrbs = six;

            Color c = (color == BossColor.Red)
                ? new Color(1f, 0.35f, 0.35f, 1f)
                : new Color(0.35f, 1f, 0.35f, 1f);

            pat.keyframes = new DataNS.OrbKeyframe[]
            {
                new DataNS.OrbKeyframe {
                    t = 0f,
                    motion = DataNS.OrbMotion.Gather,
                    duration = Mathf.Clamp(duration * 0.35f, 0.06f, 0.30f),
                    radius = six ? 2.6f : 2.2f,
                    angleOffset = 0f,
                    color = c,
                    brightness = 0.9f,
                    lockFormation = true,
                    note = "flare: freeze"
                },
                new DataNS.OrbKeyframe {
                    t = 0.35f,
                    motion = DataNS.OrbMotion.Pulse,
                    duration = Mathf.Clamp(duration * 0.65f, 0.12f, 0.80f),
                    radius = (six ? 2.6f : 2.2f) * Mathf.Clamp(amplitude, 1.0f, 1.6f),
                    angleOffset = 0f,
                    color = c,
                    brightness = 1.15f,
                    lockFormation = true,
                    note = "flare: pulse"
                }
            };
            return pat;
        }

        protected static float SafeTime(float? t) => (t.HasValue && t.Value > 0f) ? t.Value : 0f;
    }
}
