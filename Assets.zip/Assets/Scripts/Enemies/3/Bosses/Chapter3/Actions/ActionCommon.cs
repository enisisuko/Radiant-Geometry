using UnityEngine;

namespace FD.Bosses.C3.Actions
{
    public static class ActionCommon
    {
        /// <summary>Hit players in a circle. Returns number of hits.</summary>
        public static int HitCircle(Vector2 center, float radius, float damage, int playerLayerMask)
        {
            var arr = Physics2D.OverlapCircleAll(center, radius, playerLayerMask);
            int hits = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                var c = arr[i];
                if (!c) continue;
                bool pass = (playerLayerMask != 0) ? true : c.CompareTag("Player");
                if (!pass) continue;
                var dmg = c.GetComponent<IDamageable>();
                if (dmg != null)
                {
                    dmg.TakeDamage(damage);
                    hits++;
                }
            }
            return hits;
        }

        /// <summary>Sweep a line (capsule-like) by sampling multiple circles between a and b.</summary>
        public static int HitCapsule(Vector2 a, Vector2 b, float radius, float damage, int playerLayerMask, int samples = 5)
        {
            int total = 0;
            for (int i = 0; i < samples; i++)
            {
                float t = samples <= 1 ? 0.5f : (i / (samples - 1f));
                Vector2 p = Vector2.Lerp(a, b, t);
                total += HitCircle(p, radius, damage, playerLayerMask);
            }
            return total;
        }
    }

    // Minimal local IDamageable forward decl if your project doesn't already define one.
    public interface IDamageable
    {
        void TakeDamage(float amount);
        bool IsDead { get; }
    }
}
