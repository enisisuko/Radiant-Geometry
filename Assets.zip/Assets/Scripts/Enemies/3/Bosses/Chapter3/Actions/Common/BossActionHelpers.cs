using UnityEngine;

namespace FD.Bosses.C3.Actions
{
    /// <summary>
    /// Small, dependency-light utilities used by Chapter3 boss actions.
    /// Goal: make actions actually "do something" in your current project
    /// without tightly coupling to a specific Player API.
    /// </summary>
    public static class BossActionHelpers
    {
        /// <summary>
        /// Circle hit test around <paramref name="center"/> with <paramref name="radius"/>.
        /// If hit, tries to deal damage and apply a small knockback using whatever
        /// components the Player currently has (Rigidbody2D/3D, custom scripts, etc.).
        /// Returns true when the player is inside the circle (even if no receiver consumed the damage).
        /// </summary>
        public static bool TryHitPlayerCircle(Core.BossChapter3Controller ctx, Vector3 center, float radius, int damage)
        {
            if (!ctx || !ctx.player) return false;

            var p = ctx.player.position;
            if ((p - center).sqrMagnitude > radius * radius)
                return false;

            // ---- Deal damage in a decoupled way ----
            // We avoid hard dependencies by using SendMessage with common method names.
            // Replace/extend if you have a strong type like PlayerHealth.
            var go = ctx.player.gameObject;
            // Try the most common names first. If your project uses another name,
            // keep this list or add your own overload in your Player script.
            go.SendMessage("ApplyDamage", damage, SendMessageOptions.DontRequireReceiver);
            go.SendMessage("TakeDamage", damage, SendMessageOptions.DontRequireReceiver);
            go.SendMessage("Damage", damage, SendMessageOptions.DontRequireReceiver);

            // Optional: inform VFX/SFX listeners (hook up on the player or a global bus).
            var hitInfo = new BossHitInfo
            {
                worldPos = center,
                source = ctx ? ctx.gameObject : null,
                damage = damage
            };
            go.SendMessage("OnBossHit", hitInfo, SendMessageOptions.DontRequireReceiver);
            go.SendMessage("OnHit", hitInfo, SendMessageOptions.DontRequireReceiver);

            // ---- Apply a tiny knockback so hits are perceivable even without VFX ----
            Vector3 dir = (p - center).normalized;
            float impulse = Mathf.Clamp(damage * 0.1f, 1f, 8f);

            if (ctx.player.TryGetComponent<Rigidbody2D>(out var rb2))
            {
                rb2.AddForce((Vector2)dir * (impulse * 2f), ForceMode2D.Impulse);
            }
            else if (ctx.player.TryGetComponent<Rigidbody>(out var rb3))
            {
                rb3.AddForce(dir * impulse, ForceMode.Impulse);
            }
            else
            {
                // Fallback: small positional nudge (non-physics controllers).
                ctx.player.position += dir * (impulse * 0.1f);
            }

            return true;
        }

        /// <summary>
        /// Pulls the player toward <paramref name="center"/>.
        /// Uses physics if available; otherwise, moves transform smoothly.
        /// <paramref name="step"/> should be "units per second".
        /// </summary>
        public static void PullPlayerTowards(Core.BossChapter3Controller ctx, Vector3 center, float step)
        {
            if (!ctx || !ctx.player) return;

            Vector3 delta = center - ctx.player.position;
            float dist = delta.magnitude;
            if (dist < 0.0001f) return;
            Vector3 dir = delta / dist;

            if (ctx.player.TryGetComponent<Rigidbody2D>(out var rb2))
            {
                // Use gentle force so it feels like a magnet, not a teleport.
                float force = Mathf.Clamp(step * 20f, 5f, 200f);
                rb2.AddForce((Vector2)dir * force, ForceMode2D.Force);
            }
            else if (ctx.player.TryGetComponent<Rigidbody>(out var rb3))
            {
                float force = Mathf.Clamp(step * 20f, 5f, 200f);
                rb3.AddForce(dir * force, ForceMode.Force);
            }
            else
            {
                // Fallback: non-physics movement (frame-rate independent).
                float move = Mathf.Min(step * Time.deltaTime, dist);
                ctx.player.position += dir * move;
            }
        }

        /// <summary>
        /// Pushes the player away from <paramref name="center"/> with an impulse-like effect.
        /// Uses physics if available; otherwise, moves transform.
        /// </summary>
        public static void PushPlayerAway(Core.BossChapter3Controller ctx, Vector3 center, float strength)
        {
            if (!ctx || !ctx.player) return;

            Vector3 dir = (ctx.player.position - center).normalized;
            float impulse = Mathf.Clamp(strength * 20f, 5f, 400f);

            if (ctx.player.TryGetComponent<Rigidbody2D>(out var rb2))
            {
                rb2.AddForce((Vector2)dir * impulse, ForceMode2D.Impulse);
            }
            else if (ctx.player.TryGetComponent<Rigidbody>(out var rb3))
            {
                rb3.AddForce(dir * (impulse * 0.5f), ForceMode.Impulse);
            }
            else
            {
                ctx.player.position += dir * (strength * 0.5f);
            }
        }

        /// <summary>
        /// Horizontal (XZ / XY plane) direction from <paramref name="from"/> to player.
        /// </summary>
        public static Vector3 FlatDirTo(Core.BossChapter3Controller ctx, Vector3 from)
        {
            var t = ctx?.player ? ctx.player.position : from + Vector3.right;
            var d = (t - from);
#if UNITY_2D
            d.y = 0f; // If you use a top-down 2D setup, you may remove this.
#else
            d.y = 0f;
#endif
            return d.sqrMagnitude > 0.0001f ? d.normalized : Vector3.right;
        }

        /// <summary>
        /// Lightweight payload for hit callbacks without creating hard dependencies.
        /// </summary>
        public struct BossHitInfo
        {
            public Vector3 worldPos;
            public GameObject source;
            public int damage;
        }
    }
}
