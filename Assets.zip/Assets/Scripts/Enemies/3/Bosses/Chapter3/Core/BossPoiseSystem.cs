using UnityEngine;
using FD.Bosses.C3.Data;

namespace FD.Bosses.C3.Core
{
    public class BossPoiseSystem : MonoBehaviour
    {
        public int Max { get; private set; }
        public int Current { get; private set; }
        float regenTimer;
        BossChapter3Controller ctx;
        BossTuningData tuning;

        [Header("Debug")] public bool debugLogs = true;

        public void Init(BossChapter3Controller c, BossTuningData t)
        {
            ctx = c; tuning = t;
            SetMax(t != null ? t.poiseP1 : 100);
            if (debugLogs) Debug.Log($"[BOSS][Poise] Init max={Max}");
        }

        public void SetMax(int v)
        {
            Max = v; Current = v; regenTimer = 0f;
            if (debugLogs) Debug.Log($"[BOSS][Poise] SetMax {Max}");
        }

        public void AddPoiseDamage(int v)
        {
            int prev = Current;
            Current = Mathf.Max(0, Current - v);
            regenTimer = 0f;
            if (debugLogs) Debug.Log($"[BOSS][Poise] Hit {v} -> {prev}->{Current}");
            if (Current <= 0)
            {
                if (ctx && ctx.fsm != null) { if (debugLogs) Debug.Log("[BOSS][Poise] Stagger"); ctx.fsm.PushStagger(); }
                Current = Max;
            }
        }

        public void Tick(float dt)
        {
            if (tuning == null || ctx == null) return;

            regenTimer += dt;
            if (regenTimer >= tuning.poiseRegenDelay)
            {
                var r = (ctx.phase == BossPhase.P1) ? tuning.poiseRegenP1 : tuning.poiseRegenP2;
                int before = Current;
                Current = Mathf.Min(Max, Current + Mathf.RoundToInt(r * dt));
                if (debugLogs && Current != before) Debug.Log($"[BOSS][Poise] Regen {before}->{Current}");
            }
        }
    }
}