using UnityEngine;
using System.Collections.Generic;
using FD.Bosses.C3.Data;
using FD.Bosses.C3.Actions;

namespace FD.Bosses.C3.Core
{
    public class BossActionExecutor : MonoBehaviour
    {
        BossChapter3Controller ctx;

        readonly Queue<BossActionData> queue = new();
        IBossAction current;
        float phaseT;
        enum Step { Idle, Tell, Windup, Active, Recover }
        Step step = Step.Idle;

        readonly Dictionary<int, float> _cooldowns = new();

        [Header("Debug")]
        public bool debugLogs = true;
        public bool selfUpdate = false; // ������Ĭ�� false������ Controller ����

        public bool IsIdle => step == Step.Idle && current == null;

        public void Init(BossChapter3Controller c)
        {
            ctx = c;
            if (debugLogs) Debug.Log("[BOSS][Executor] Init");
        }

        void CleanupLeakedActions()
        {
            // ֻ���� current��������������������������ȫ�����
            var all = ctx.GetComponents<BaseBossAction>();
            for (int i = 0; i < all.Length; i++)
            {
                var cpt = all[i];
                if (current != null && ReferenceEquals(current, cpt)) continue;
                Destroy(cpt);
            }
        }

        void DestroyCurrent()
        {
            if (current is Component comp) Destroy(comp);
            current = null;
        }

        public void Tick(float dt)
        {
            // �ƽ���ȴ ���� ��Ϊ������ʱ�䣬������������ CD
            if (_cooldowns.Count > 0)
            {
                _tmpKeys ??= new List<int>(8);
                _tmpKeys.Clear();
                _tmpKeys.AddRange(_cooldowns.Keys);
                for (int i = 0; i < _tmpKeys.Count; i++)
                {
                    int k = _tmpKeys[i];
                    float left = _cooldowns[k] - Time.unscaledDeltaTime;
                    _cooldowns[k] = left <= 0f ? 0f : left;
                }
            }

            // �������ж��� �� ������
            if (current == null && queue.Count > 0)
            {
                CleanupLeakedActions(); // <== ������ǰ�Ȱ���ʷ�������

                var data = queue.Dequeue();

                if (data.cooldown > 0f)
                {
                    _cooldowns.TryGetValue(data.actionId, out var old);
                    _cooldowns[data.actionId] = Mathf.Max(old, data.cooldown);
                }

                current = ActionsRegistry.SpawnFor(data, ctx);  // �Ḵ��/Ψһ��
                if (!current.CanStart())
                {
                    if (debugLogs) Debug.Log($"[BOSS][Executor] CannotStart {data.displayName}({data.actionId})");
                    current.Abort();
                    DestroyCurrent(); // <== ���ܿ���ֱ������
                    return;
                }

                step = Step.Tell; phaseT = 0f;
                if (debugLogs) Debug.Log($"[BOSS][Executor] Start {current.Data.displayName}({current.Data.actionId}) -> TELL");
                current.StartTell();
            }

            if (current == null) return;

            phaseT += dt;

            switch (step)
            {
                case Step.Tell:
                    if (phaseT >= Mathf.Max(0f, current.Data.tellTime))
                    {
                        step = Step.Windup; phaseT = 0;
                        if (debugLogs) Debug.Log($"[BOSS][Executor] {current.Data.displayName} -> WINDUP");
                        current.StartWindup();
                    }
                    break;

                case Step.Windup:
                    if (phaseT >= Mathf.Max(0f, current.Data.windupTime))
                    {
                        step = Step.Active; phaseT = 0;
                        if (debugLogs) Debug.Log($"[BOSS][Executor] {current.Data.displayName} -> ACTIVE (activeTime={current.Data.activeTime})");
                        current.StartActive();
                    }
                    break;

                case Step.Active:
                    {
                        float at = current.Data.activeTime;
                        if (at > 0f)
                        {
                            if (phaseT >= at)
                            {
                                step = Step.Recover; phaseT = 0;
                                if (debugLogs) Debug.Log($"[BOSS][Executor] {current.Data.displayName} -> RECOVER");
                                current.StartRecover();
                            }
                        }
                        else
                        {
                            if (current.IsDone)
                            {
                                if (debugLogs) Debug.Log($"[BOSS][Executor] {current.Data.displayName} DONE (self-finished) -> IDLE");
                                step = Step.Idle; phaseT = 0;
                                DestroyCurrent();           // <== ����
                                CleanupLeakedActions();     // <== �ٱ���
                            }
                        }
                    }
                    break;

                case Step.Recover:
                    if (phaseT >= Mathf.Max(0f, current.Data.recoverTime))
                    {
                        if (debugLogs) Debug.Log($"[BOSS][Executor] {current?.Data.displayName} finished -> IDLE");
                        step = Step.Idle; phaseT = 0;
                        DestroyCurrent();           // <== ����
                        CleanupLeakedActions();
                    }
                    break;
            }
        }

        void Update() { if (selfUpdate) Tick(Time.deltaTime); } // ���� selfUpdate=true ʱ����

        public void Queue(BossActionData data)
        {
            if (data == null) return;
            queue.Enqueue(data);
            if (debugLogs) Debug.Log($"[BOSS][Executor] Queued {data.displayName}({data.actionId})");
        }

        public bool IsCastingAction(int id) => current != null && current.Data.actionId == id;
        public bool IsOnCooldown(int actionId) =>
            _cooldowns.TryGetValue(actionId, out var left) && left > 0f;

        List<int> _tmpKeys;
    }
}
