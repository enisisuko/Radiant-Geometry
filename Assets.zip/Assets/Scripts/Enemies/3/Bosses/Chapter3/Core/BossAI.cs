using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using FD.Bosses.C3.Data;

namespace FD.Bosses.C3.Core
{
    [DisallowMultipleComponent]
    public class BossAI : MonoBehaviour
    {
        BossChapter3Controller ctx;
        BossTuningData tuning;

        [Header("Sense/Env")]
        public LayerMask losBlockMask;
        public float thinkHz = 6f;
        public float nearDist = 4.0f;
        public float midDist = 12.0f;

        [Header("Selection")]
        [Range(0.1f, 3f)] public float temperature = 0.75f;
        [Range(0f, 1f)] public float diversityBoost = 0.15f;

        [Header("Anti-Repeat")]
        public int maxSameRepeat = 2;           // ԭ 1 �� 2
        public float dynamicCooldownMul = 1.1f; // ԭ 1.2 �� 1.1
        public float dynCdFallPerSec = 0.3f;

        [Header("Combos")]
        public bool enableCombos = true;
        [Range(0f, 1f)] public float followUpChance = 0.5f;
        public int maxFollowUps = 1;

        [Header("Teleport (New)")]
        public bool enableTeleport = true;
        [Tooltip("�����˾��뽫˲�Ƶ���Ҹ���")]
        public float teleportFarDist = 18f;
        [Tooltip("�������ҵ���С�뾶")]
        public float teleportMinRadius = 3.5f;
        [Tooltip("�������ҵ����뾶")]
        public float teleportMaxRadius = 6.5f;
        [Tooltip("���ڼ������Ƿ��ڵ����ڵ�̽��뾶")]
        public float teleportProbeRadius = 0.5f;
        [Tooltip("Ϊ�Ҹɾ���㳢�Ե�������")]
        public int teleportMaxTries = 12;
        [Tooltip("˲�ƺ����ȴ���룬������ʱ�䣩")]
        public float teleportCooldown = 2.0f;
        [Tooltip("����/�赲�㣨��㲻�������ص���")]
        public LayerMask teleportBlockMask;

        [Header("Debug")]
        public bool debugLogs = true;
        public bool selfUpdate = false;        // Ĭ�� false������ Controller ����

        float _thinkAccu;
        float _dist;
        bool _hasLOS;
        bool _playerIsRed = true;
        int _lastId = -1;
        int _repeatCount = 0;

        readonly Dictionary<int, float> _nextReadyAt = new();
        readonly Dictionary<int, float> _dynCdMul = new();
        readonly Queue<int> _recent = new();
        const int RECENT_KEEP = 4;

        Transform _player;
        Rigidbody2D _playerRB;

        // ��ϣ���ѡ�仯ʱ�������
        bool _lastHadCandidates = true;
        int _lastPhaseOut = 0, _lastCdOut = 0;

        // ˲�ƽ���
        float _nextTeleportAt = 0f;

        public void Init(BossChapter3Controller c)
        {
            ctx = c; tuning = c.tuning;
            _player = c.playerProvider?.PlayerTransform ?? c.player;
            if (_player) _playerRB = _player.GetComponent<Rigidbody2D>();
            if (debugLogs) Debug.Log("[BOSS][AI] Init");
        }

        void Update()
        {
            if (!selfUpdate) return; // ���� Controller ͳһ����
            float hz = (tuning != null && tuning.thinkHz > 0f) ? tuning.thinkHz : Mathf.Max(thinkHz, 0.1f);
            _thinkAccu += Time.deltaTime;
            if (_thinkAccu >= 1f / hz)
            {
                float dt = _thinkAccu;
                _thinkAccu = 0f;
                Tick(dt);
            }
        }

        public void Tick(float dt)
        {
            if (ctx == null || ctx.executor == null) return;
            Sense();
            DecayDynamicCooldown(dt);
            //if (debugLogs) Debug.Log($"[BOSS][AI] Think dist={_dist:0.00} phase={ctx.phase} color={ctx.color}");

            // ===== ������Զ��/������˲�ƣ�������ʱ������ =====
            if (enableTeleport && ctx.executor.IsIdle)
            {
                bool tooFar = (_dist > teleportFarDist);
                bool insideTerrain = IsInsideTerrain(ctx.transform.position);

                if (Time.unscaledTime >= _nextTeleportAt && (tooFar || insideTerrain))
                {
                    if (TryPickLanding(out Vector2 landing))
                    {
                        DoTeleport(landing, reason: insideTerrain ? "inside" : "far");
                        // ���¸�֪�����Ȿ֡ʹ�þɾ�������
                        Sense();
                        // ˲�ƺ�֡���ٳ��У�����һ֡������Ȼ��
                        return;
                    }
                    else if (debugLogs)
                    {
                        Debug.LogWarning("[BOSS][AI] Teleport failed to find valid landing spot.");
                    }
                }
            }
            // ===== ˲���߼����� =====

            if (!ctx.executor.IsIdle) return;

            var set = ctx.actionSet ?? System.Array.Empty<BossActionData>();
            if (set.Length == 0) { if (debugLogs) Debug.Log("[BOSS][AI] No actions in set"); return; }

            float now = Time.unscaledTime; // ������ʱ�䣬��������������ȴ

            // ͳ�� phase/cooldown ��̭
            int phaseOut = 0, cdOut = 0;

            var cands = set.Where(a =>
            {
                if (a == null) return false;
                if (a.phase != ctx.phase) { phaseOut++; return false; }
                if (_nextReadyAt.TryGetValue(a.actionId, out var nr) && now < nr) { cdOut++; return false; }
                if (ctx.executor.IsOnCooldown(a.actionId)) { cdOut++; return false; }
                return true;
            }).ToList();

            bool hadCandidates = cands.Count > 0;
            if (hadCandidates != _lastHadCandidates || phaseOut != _lastPhaseOut || cdOut != _lastCdOut)
            {
                if (debugLogs) Debug.Log($"[BOSS][AI] candidates={cands.Count}, phaseOut={phaseOut}, cdOut={cdOut}");
                _lastHadCandidates = hadCandidates; _lastPhaseOut = phaseOut; _lastCdOut = cdOut;
            }

            if (!hadCandidates) return;

            var scored = new List<(BossActionData a, float s)>(cands.Count);
            foreach (var a in cands) scored.Add((a, Score(a, now)));

            if (debugLogs)
            {
                var top3 = scored.OrderByDescending(x => x.s).Take(3)
                    .Select(x => $"{x.a.displayName}#{x.a.actionId}({x.s:0.##})");
                Debug.Log("[BOSS][AI] Top: " + string.Join(" | ", top3));
            }

            int idx = SoftmaxPick(scored, temperature);
            if (idx < 0) return;
            var picked = scored[idx].a;

            if (picked.actionId == _lastId && _repeatCount >= maxSameRepeat)
            {
                var alt = scored.Where(x => x.a.actionId != _lastId && x.s > 0f).OrderByDescending(x => x.s).FirstOrDefault().a;
                if (alt != null) picked = alt;
            }

            Fire(picked, now);

            // ���Σ�������ԭ�е� chainFollowUps ����
            if (enableCombos && picked.chainFollowUps != null && picked.chainFollowUps.Length > 0)
            {
                int follow = Mathf.Clamp(maxFollowUps, 0, 2);
                int chained = 0;
                while (chained < follow && Random.value <= followUpChance)
                {
                    var follows = scored
                        .Where(x => picked.chainFollowUps.Contains(x.a.actionId))
                        .OrderByDescending(x => x.s).Select(x => x.a).ToList();
                    if (follows.Count == 0) break;
                    var next = follows[0];
                    Fire(next, now + 0.01f);
                    chained++;
                }
            }
        }

        void Fire(BossActionData a, float now)
        {
            if (debugLogs) Debug.Log($"[BOSS][AI] Pick {a.displayName}#{a.actionId}");
            ctx.RequestAction(a.actionId);

            if (!_dynCdMul.TryGetValue(a.actionId, out var m)) m = 1f;
            m *= Mathf.Max(1f, dynamicCooldownMul);
            _dynCdMul[a.actionId] = Mathf.Clamp(m, 1f, 3.5f);

            float cd = Mathf.Max(0f, a.cooldown);
            _nextReadyAt[a.actionId] = now + cd * _dynCdMul[a.actionId];

            if (a.actionId == _lastId) _repeatCount++;
            else { _lastId = a.actionId; _repeatCount = 0; }

            _recent.Enqueue(a.actionId);
            while (_recent.Count > RECENT_KEEP) _recent.Dequeue();
        }

        void Sense()
        {
            _player = ctx.playerProvider?.PlayerTransform ?? ctx.player;
            if (_player)
            {
                Vector3 bossPos = ctx.transform.position;
                Vector3 p = _player.position;
                _dist = (p - bossPos).magnitude;
                _hasLOS = !Physics2D.Linecast(bossPos, p, losBlockMask);
                if (ctx.playerProvider != null)
                    _playerIsRed = (ctx.playerProvider.CurrentColor == PlayerColor.Red);
                if (!_playerRB) _playerRB = _player.GetComponent<Rigidbody2D>();
            }
            else { _dist = 999f; _hasLOS = false; }
        }

        void DecayDynamicCooldown(float dt)
        {
            if (_dynCdMul.Count == 0) return;
            var keys = _dynCdMul.Keys.ToArray();
            foreach (var k in keys)
            {
                float m = _dynCdMul[k];
                m = Mathf.MoveTowards(m, 1f, dynCdFallPerSec * dt);
                _dynCdMul[k] = Mathf.Clamp(m, 1f, 3.5f);
            }
        }

        float Score(BossActionData a, float now)
        {
            int baseW = _dist <= nearDist ? a.weightClose : _dist <= midDist ? a.weightMid : a.weightFar;

            bool colorMatch = (_playerIsRed && a.color == BossColor.Red) || (!_playerIsRed && a.color == BossColor.Green);
            if (!colorMatch) baseW -= 4;

            float ideal = _dist <= nearDist ? (nearDist * 0.6f) : _dist <= midDist ? ((nearDist + midDist) * 0.5f) : (midDist + 4f);
            baseW -= Mathf.RoundToInt(Mathf.Clamp01(Mathf.Abs(_dist - ideal) / 8f) * 2f);

            if (!_hasLOS && NeedsLOS(a)) baseW -= 3;

            bool nearWall = (ctx != null && ctx.transform.position.magnitude > 14f);
            if (nearWall && IsLongMelee(a)) baseW -= 2;

            float pSpeed = (_playerRB != null)
#if UNITY_6000_0_OR_NEWER
                ? _playerRB.linearVelocity.magnitude
#else
                ? _playerRB.velocity.magnitude
#endif
                : 0f;

            if (pSpeed < 1.2f) { if (IsMelee(a)) baseW += 1; if (IsFast(a)) baseW += 1; }
            else { if (IsProjectile(a)) baseW += 1; if (IsRiposte(a)) baseW += 1; }

            if (diversityBoost > 0f && _recent.Count > 0 && !_recent.Contains(a.actionId))
                baseW += Mathf.RoundToInt(2f * diversityBoost);

            if (a.actionId == _lastId && _repeatCount >= 1) baseW -= 2;

            if (_nextReadyAt.TryGetValue(a.actionId, out var nr))
            {
                float remain = Mathf.Max(0f, nr - now);
                if (remain <= 0.2f) baseW += 1;
            }

            return Mathf.Max(0, baseW);
        }

        int SoftmaxPick(List<(BossActionData a, float s)> scored, float temp)
        {
            if (scored.Count == 0) return -1;
            float t = Mathf.Max(0.01f, temp);
            float max = scored.Max(x => x.s);
            double sum = 0;
            double[] probs = new double[scored.Count];
            for (int i = 0; i < scored.Count; i++)
            {
                double v = (scored[i].s - max) / t;
                double e = System.Math.Exp(v);
                probs[i] = e; sum += e;
            }
            if (sum <= 0) return scored.FindIndex(x => x.s == max);
            double r = Random.value * sum, acc = 0;
            for (int i = 0; i < probs.Length; i++)
            {
                acc += probs[i]; if (r <= acc) return i;
            }
            return scored.Count - 1;
        }

        // ====== Teleport helpers ======
        bool IsInsideTerrain(Vector2 pos)
        {
            return Physics2D.OverlapCircle(pos, teleportProbeRadius, teleportBlockMask) != null;
        }

        bool TryPickLanding(out Vector2 landing)
        {
            landing = ctx.transform.position;
            if (_player == null) return false;

            Vector2 playerPos = _player.position;
            float minR = Mathf.Max(0.1f, Mathf.Min(teleportMinRadius, teleportMaxRadius));
            float maxR = Mathf.Max(minR + 0.1f, Mathf.Max(teleportMinRadius, teleportMaxRadius));
            float minSeparation = 1.1f; // �������С���룬�����ص�

            for (int i = 0; i < Mathf.Max(1, teleportMaxTries); i++)
            {
                float ang = Random.value * Mathf.PI * 2f;
                float r = Random.Range(minR, maxR);
                Vector2 pos = playerPos + new Vector2(Mathf.Cos(ang), Mathf.Sin(ang)) * r;

                // ���ڵ����ڣ�������ұ���һ�ξ���
                if (!IsInsideTerrain(pos) && Vector2.Distance(pos, playerPos) >= minSeparation)
                {
                    landing = pos;
                    return true;
                }
            }
            return false;
        }

        void DoTeleport(Vector2 target, string reason)
        {
            var tf = ctx.transform;
            tf.position = target;

            // ���ٶȣ�����˲�ƺ������
            var rb = tf.GetComponent<Rigidbody2D>();
            if (rb)
#if UNITY_6000_0_OR_NEWER
                rb.linearVelocity = Vector2.zero;
#else
                rb.velocity = Vector2.zero;
#endif

            _nextTeleportAt = Time.unscaledTime + Mathf.Max(0f, teleportCooldown);
            if (debugLogs) Debug.Log($"[BOSS][AI] Teleport ({reason}) -> {target}");
        }
        // ====== Teleport helpers end ======

        static bool Has(BossActionData a, string kw) => (a.displayName ?? string.Empty).ToLowerInvariant().Contains(kw);
        static bool IsMelee(BossActionData a) => Has(a, "sweep") || Has(a, "thrust") || Has(a, "whirl") || Has(a, "cleave");
        static bool IsProjectile(BossActionData a) => Has(a, "laser") || Has(a, "missile") || Has(a, "orb") || Has(a, "ring") || Has(a, "beam");
        static bool IsRiposte(BossActionData a) => Has(a, "riposte") || Has(a, "counter") || Has(a, "dodge");
        static bool IsLongMelee(BossActionData a) => Has(a, "thrust") || Has(a, "leap") || Has(a, "dash");
        static bool NeedsLOS(BossActionData a) => IsProjectile(a) || Has(a, "beam") || Has(a, "laser");
        static bool IsFast(BossActionData a) => Has(a, "jab") || Has(a, "quick") || Has(a, "fast") || Has(a, "riposte") || Has(a, "stab");
    }
}
