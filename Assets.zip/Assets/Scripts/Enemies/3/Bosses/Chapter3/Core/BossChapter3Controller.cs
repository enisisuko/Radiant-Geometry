﻿using UnityEngine;
using FD.Bosses.C3.Data;
using FD.Bosses.C3.Orbs;

namespace FD.Bosses.C3.Core
{
    [RequireComponent(typeof(BossPoiseSystem))]
    public class BossChapter3Controller : MonoBehaviour
    {
        [Header("Data")]
        public BossTuningData tuning;
        public BossActionData[] actionSet;

        [Header("Refs")]
        public Transform modelRoot;
        public Transform player; // fallback if provider missing
        public IPlayerColorProvider playerProvider;
        public OrbRingController orbRing;
        public BossPhaseController phaseCtrl;
        public BossColorSystem colorSys;
        public BossActionExecutor executor;
        public BossAI ai;
        public SM.BossStateMachine fsm;
        public BossHealth bossHealth;

        [Header("Runtime")]
        public BossPhase phase = BossPhase.P1;
        public BossColor color = BossColor.Red;

        [Header("Debug")]
        public bool diagLogs = false;
        float _diagTimer = 0f;

        BossPoiseSystem poise;

        void Awake()
        {
            if (!orbRing) orbRing = GetComponentInChildren<OrbRingController>(true);
            if (!phaseCtrl) phaseCtrl = GetComponent<BossPhaseController>();
            if (!colorSys) colorSys = GetComponent<BossColorSystem>();
            if (!executor) executor = GetComponent<BossActionExecutor>();
            if (!ai) ai = GetComponent<BossAI>();
            if (!fsm) fsm = GetComponent<SM.BossStateMachine>();
            if (!bossHealth) bossHealth = GetComponent<BossHealth>();
            poise = GetComponent<BossPoiseSystem>();

            // auto resolve player color provider
            if (playerProvider == null)
            {
                if (player) playerProvider = player.GetComponentInParent<PlayerColorBridge>();
                if (playerProvider == null)
                {
#if UNITY_2023_1_OR_NEWER
                    var any = Object.FindAnyObjectByType<PlayerColorBridge>();
#else
                    var any = Object.FindObjectOfType<PlayerColorBridge>();
#endif
                    if (any) { playerProvider = any; player = any.transform; }
                }
            }

            // init subsystems
            if (phaseCtrl) phaseCtrl.Init(this, tuning);
            if (colorSys) colorSys.Init(this, tuning);
            if (executor) executor.Init(this);
            if (ai) ai.Init(this);
            if (orbRing) orbRing.Init(this);
            if (fsm) fsm.Init(this);
            if (poise) poise.Init(this, tuning);
            if (!modelRoot) modelRoot = transform;

            // ★ 关键：按当前相位同步环绕体数量（P1=4 / P2=6）
            SyncOrbsWithPhase();
        }

        void Update()
        {
            float dt = Time.deltaTime;

            // 单一驱动：这里驱动 AI/Executor（确保它们自身不再各自 Update 一次）
            if (fsm) fsm.Tick(dt);
            if (ai) ai.Tick(dt);
            if (executor) executor.Tick(dt);
            if (poise) poise.Tick(dt);
            if (colorSys) colorSys.Tick(dt);

            // 环绕体用 unscaled，以免慢放影响视觉
            if (orbRing) orbRing.Tick(Time.unscaledDeltaTime);

            if (diagLogs && executor)
            {
                _diagTimer += dt;
                if (_diagTimer >= 1f)
                {
                    _diagTimer = 0f;
                    Debug.Log($"[BOSS] idle={executor.IsIdle} phase={phase} color={color} set={(actionSet != null ? actionSet.Length : 0)}");
                }
            }
        }

        /// <summary>
        /// Phase 系统调用：相位变化时同步环绕体数量与半径。
        /// </summary>
        public void OnPhaseChanged(BossPhase newPhase)
        {
            if (phase == newPhase) return;
            phase = newPhase;
            SyncOrbsWithPhase();
        }

        /// <summary>
        /// 按当前相位把环绕体切到 4/6 颗，并重置到 Idle 阵位半径。
        /// </summary>
        public void SyncOrbsWithPhase()
        {
            if (!orbRing) return;
            bool six = (phase == BossPhase.P2);
            float r = six ? 2.4f : 2.0f;   // 可按美术期望微调
            orbRing.SetPhase(six, r);
        }

        public void RequestAction(int actionId)
        {
            var data = FindAction(actionId);
            if (data != null && executor != null) executor.Queue(data);
        }

        BossActionData FindAction(int id)
        {
            if (actionSet == null) return null;
            for (int i = 0; i < actionSet.Length; i++)
                if (actionSet[i] != null && actionSet[i].actionId == id) return actionSet[i];
            return null;
        }
    }
}
