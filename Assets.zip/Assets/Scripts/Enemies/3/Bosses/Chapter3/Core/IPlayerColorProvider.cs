using UnityEngine;

namespace FD.Bosses.C3.Core {
  public enum PlayerColor { Red, Green }
  public interface IPlayerColorProvider {
    PlayerColor CurrentColor { get; }
    bool IsHealing { get; }
    Transform PlayerTransform { get; }
  }
}
