using UnityEngine;
using FD.Bosses.C3.Data;

namespace FD.Bosses.C3.Core
{
    public class BossPhaseController : MonoBehaviour
    {
        BossChapter3Controller ctx; BossTuningData tuning;
        int hpMax; int hpCurrent;
        BossPoiseSystem poise;

        [Header("Debug")] public bool debugLogs = true;

        public void Init(BossChapter3Controller c, BossTuningData t)
        {
            ctx = c; tuning = t; poise = GetComponent<BossPoiseSystem>();
            hpMax = t.hpP1; hpCurrent = hpMax;
            if (debugLogs) Debug.Log($"[BOSS][Phase] Init HP={hpMax} phase={ctx.phase}");
        }
        public void ApplyDamage(int v)
        {
            int prev = hpCurrent;
            hpCurrent = Mathf.Max(0, hpCurrent - v);
            if (debugLogs) Debug.Log($"[BOSS][Phase] Damage {v} -> {prev}->{hpCurrent}");
            if (ctx.phase == BossPhase.P1 && hpCurrent <= (tuning.hpP1 * 0.5f))
            {
                EnterP2();
            }
        }
        void EnterP2()
        {
            ctx.phase = BossPhase.P2;
            if (debugLogs) Debug.Log("[BOSS][Phase] Enter P2");
            poise.SetMax(tuning.poiseP2);
            ctx.orbRing.SwitchToSixOrbs();
            ctx.fsm.PushPhaseShift();
        }
    }
}