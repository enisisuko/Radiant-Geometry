// Assets/Scripts/Bosses/Chapter3/Core/PlayerColorBridge.cs
using UnityEngine;
using System.Reflection;

// 你的玩家脚本命名空间：示例为 FadedDreams.Player（若不一致无需修改，这里只用类型名）
namespace FD.Bosses.C3.Core
{
    /// <summary>
    /// 全自动桥接：在 Start() 时自动查找 PlayerColorModeController，
    /// 订阅其 OnModeChanged/OnEnergyChanged 事件，实时给 Boss 提供颜色与回血状态。
    /// 无需任何手动配置。
    /// </summary>
    [DisallowMultipleComponent]
    public class PlayerColorBridge : MonoBehaviour, IPlayerColorProvider
    {
        // —— 对 Boss 暴露的只读属性 ——
        public PlayerColor CurrentColor { get; private set; } = PlayerColor.Red;
        public bool IsHealing { get; private set; } = false;
        public Transform PlayerTransform => transform;

        // —— 内部状态 —— 
        private object _pcm;                    // PlayerColorModeController 实例（用 object 降耦）
        private System.Type _pcmType;
        private float _lastRed, _lastGreen;     // 用于判断能量是否回升（回血）
        private float _healingFlagUntil = 0f;   // 回血判定持续到的时间点
        [SerializeField] private float healingGraceSec = 0.6f; // 能量上升后，判定“正在回血”的时间窗

        void Start()
        {
            // 1) 在自己或父物体上寻找 PlayerColorModeController
            _pcmType = System.Type.GetType("FadedDreams.Player.PlayerColorModeController, Assembly-CSharp")
                       ?? System.Type.GetType("PlayerColorModeController")
                       ?? FindPCMTypeByName();
            if (_pcmType == null)
            {
                Debug.LogWarning("[PlayerColorBridge] 未找到 PlayerColorModeController 类型。将保持默认红色/无回血。");
                return;
            }

            _pcm = GetComponentInParent(_pcmType);
            if (_pcm == null)
            {
                Debug.LogWarning("[PlayerColorBridge] 场景中未在该玩家对象父层找到 PlayerColorModeController。将保持默认红色/无回血。");
                return;
            }

            // 2) 读取一次初始 Mode / Energy
            ReadInitialColorAndEnergy();

            // 3) 订阅 OnModeChanged / OnEnergyChanged 事件（反射订阅，不增加编译期依赖）
            SubscribeEvent(_pcm, "OnModeChanged", (System.Action<object>)OnModeChangedBoxed);
            SubscribeEvent(_pcm, "OnEnergyChanged", (System.Action<float, float, float, float>)OnEnergyChanged);
        }

        void Update()
        {
            // 回血判定超时自动复位
            if (IsHealing && Time.unscaledTime >= _healingFlagUntil)
            {
                IsHealing = false;
            }
        }

        // —— 事件回调：模式变化（枚举入参装箱传来，统一走 boxed） ——
        private void OnModeChangedBoxed(object modeEnum)
        {
            // 你的枚举叫 FadedDreams.Player.ColorMode（Red/Green）
            var s = modeEnum.ToString();
            CurrentColor = s.Contains("Red") ? PlayerColor.Red : PlayerColor.Green;
        }

        // —— 事件回调：能量变化（red, redMax, green, greenMax） ——
        private void OnEnergyChanged(float red, float redMax, float green, float greenMax)
        {
            // 只要任一能量相较上次“上升”，则判定为在回血；维持 healingGraceSec 秒
            bool redUp = red > _lastRed + 0.001f;
            bool greenUp = green > _lastGreen + 0.001f;
            if (redUp || greenUp)
            {
                IsHealing = true;
                _healingFlagUntil = Time.unscaledTime + healingGraceSec;
            }
            _lastRed = red;
            _lastGreen = green;
        }

        // —— 工具：读一次初始颜色与能量 —— 
        private void ReadInitialColorAndEnergy()
        {
            // 读 Mode 字段/属性
            var modeMember = _pcmType.GetField("Mode", BindingFlags.Public | BindingFlags.Instance)
                            ?? (MemberInfo)_pcmType.GetProperty("Mode", BindingFlags.Public | BindingFlags.Instance);
            if (modeMember != null)
            {
                object modeVal = (modeMember is FieldInfo fi) ? fi.GetValue(_pcm) : ((PropertyInfo)modeMember).GetValue(_pcm, null);
                OnModeChangedBoxed(modeVal);
            }

            // 调用 Red01/Green01 或 OnEnergyChanged 的当前值（优先走事件后备：尝试获取 red/green 私有值不可靠）
            // 这里我们用反射尝试属性 Red01/Green01（如果存在的话），否则保持默认 1。
            float red01 = GetFloatProp(_pcm, "Red01", 1f);
            float green01 = GetFloatProp(_pcm, "Green01", 1f);
            // 假设 max=100，换算回粗略当前值仅用于初始比较，不影响实际逻辑
            _lastRed = red01 * 100f;
            _lastGreen = green01 * 100f;
        }

        // —— 反射订阅 UnityEvent<T> / UnityEvent 的工具 —— 
        private void SubscribeEvent(object target, string eventName, System.Delegate handler)
        {
            var evtField = _pcmType.GetField(eventName, BindingFlags.Public | BindingFlags.Instance);
            if (evtField == null)
            {
                Debug.LogWarning($"[PlayerColorBridge] 未找到事件 {eventName}，自动监听失败。");
                return;
            }
            var unityEvent = evtField.GetValue(target);
            if (unityEvent == null) return;

            // UnityEvent 的 AddListener 方法
            var addListener = unityEvent.GetType().GetMethod("AddListener");
            if (addListener == null)
            {
                Debug.LogWarning($"[PlayerColorBridge] 事件 {eventName} 不支持 AddListener。");
                return;
            }
            try
            {
                addListener.Invoke(unityEvent, new object[] { handler });
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"[PlayerColorBridge] 订阅 {eventName} 失败：{e.Message}");
            }
        }

        private static System.Type FindPCMTypeByName()
        {
            // 兜底：遍历所有已加载程序集，找名为 PlayerColorModeController 的类型
            foreach (var asm in System.AppDomain.CurrentDomain.GetAssemblies())
            {
                var t = asm.GetType("FadedDreams.Player.PlayerColorModeController") ?? asm.GetType("PlayerColorModeController");
                if (t != null) return t;
            }
            return null;
        }

        private static float GetFloatProp(object obj, string prop, float defVal)
        {
            if (obj == null) return defVal;
            var pi = obj.GetType().GetProperty(prop, BindingFlags.Public | BindingFlags.Instance);
            if (pi != null && pi.PropertyType == typeof(float))
            {
                try { return (float)pi.GetValue(obj, null); } catch { }
            }
            return defVal;
        }
    }
}
