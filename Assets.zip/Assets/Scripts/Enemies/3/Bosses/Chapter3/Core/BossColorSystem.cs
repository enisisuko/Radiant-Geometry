using UnityEngine;
using FD.Bosses.C3.Data;
using System.Collections;

namespace FD.Bosses.C3.Core
{
    public class BossColorSystem : MonoBehaviour
    {
        BossChapter3Controller ctx; BossTuningData tuning;
        float evalTimer, evalTarget;

        [Header("Debug")] public bool debugLogs = true;

        public void Init(BossChapter3Controller c, BossTuningData t) { ctx = c; tuning = t; ResetEvalTimer(); if (debugLogs) Debug.Log("[BOSS][Color] Init"); }
        void ResetEvalTimer() { evalTimer = 0f; evalTarget = Random.Range(tuning.colorEvalIntervalMin, tuning.colorEvalIntervalMax); }
        public void Tick(float dt)
        {
            evalTimer += dt;
            if (evalTimer >= evalTarget && ctx.executor.IsIdle)
            {
                if (debugLogs) Debug.Log("[BOSS][Color] Evaluate swap");
                TrySwapColorIfBetter();
                ResetEvalTimer();
            }
        }
        void TrySwapColorIfBetter()
        {
            var target = (ctx.color == BossColor.Red) ? BossColor.Green : BossColor.Red;
            StartCoroutine(SwapRoutine(target));
        }
        IEnumerator SwapRoutine(BossColor target)
        {
            if (debugLogs) Debug.Log($"[BOSS][Color] PreBlend -> {target}");
            ctx.orbRing.PreBlendColor(target, tuning.colorSwapBlendTime);
            yield return new WaitForSeconds(tuning.colorSwapBlendTime);
            ctx.color = target;
            if (debugLogs) Debug.Log($"[BOSS][Color] Swapped -> {ctx.color}");
        }
    }
}