using UnityEngine;

namespace FD.Bosses.C3.Data {
  [CreateAssetMenu(menuName = "FD/Bosses/C3/ActionData", fileName = "C3_Action_")]
  public class BossActionData : ScriptableObject {
    [Header("Identity")]
    public int actionId;
    public string displayName;
    public BossPhase phase;
    public BossColor color;
    [TextArea] public string designNotes;

    [Header("Timings")]
    public float tellTime = 0.6f;
    public float windupTime = 0.15f;
    public float activeTime = 0.25f;
    public float recoverTime = 0.30f;

    [Header("Damage/Poise")]
    public int damage = 24;
    public float knockback = 1.2f;
    public int poiseDamage = 0;
    public bool canBreakPlayerGuard = false;

    [Header("Kinetics")]
    public float moveSpeed = 0f;
    public AnimationCurve speedCurve = AnimationCurve.Linear(0,0,1,1);
    public bool faceTargetDuringActive = true;

    [Header("Hitbox")]
    public HitboxType hitboxType = HitboxType.Capsule;
    public Vector2 hitboxSize = new Vector2(3.2f, 0.8f);
    public float range = 3.0f;

    [Header("Orbs Pattern")]
    public OrbPatternData orbPattern;
    public bool usesDualColorCadence = false;

    [Header("Cooldown & AI")]
    public float cooldown = 2.0f;
    [Range(0, 10)] public int weightClose = 5;
    [Range(0, 10)] public int weightMid = 5;
    [Range(0, 10)] public int weightFar = 5;
    public int[] chainFollowUps;

    [Header("FX")]
    public string vfxKeyTell;
    public string vfxKeyFire;
    public string sfxTell;
    public string sfxFire;
    public float cameraFovKick = 0f;
  }
}
