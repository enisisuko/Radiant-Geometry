using UnityEngine;

namespace FD.Bosses.C3.Data {
  [CreateAssetMenu(menuName = "FD/Bosses/C3/Tuning", fileName = "C3_Tuning")]
  public class BossTuningData : ScriptableObject {
    [Header("Health/Poise")]
    public int hpP1 = 1000;
    public int hpP2 = 1200;
    public int poiseP1 = 120;
    public int poiseP2 = 160;
    public float poiseRegenP1 = 14f;
    public float poiseRegenP2 = 18f;
    public float poiseRegenDelay = 1.2f;
    public float staggerDurationP1 = 3.5f;
    public float staggerDurationP2 = 3.0f;

    [Header("Color Swap")]
    public float colorEvalIntervalMin = 8f;
    public float colorEvalIntervalMax = 12f;
    public float colorSwapBlendTime = 0.45f;
    public float chromaLockDuration = 0.8f;

    [Header("Kinetics")]
    public float glideSpeedRed = 4.0f;
    public float glideSpeedGreen = 3.6f;
    public float surgeSpeedRed = 7.5f;
    public float surgeSpeedGreen = 6.0f;
    public float turnRateP1 = 360f;
    public float turnRateP2 = 540f;
    public float hoverHeightP1 = 1.6f;
    public float hoverHeightP2 = 1.8f;

    [Header("Dodge")]
    public float dodgeDistance = 7.5f;
    public float dodgeTime = 0.18f;
    public float dodgeIFrameDelay = 0.08f;
    public float dodgeIFramePadding = 0.04f;
    public float dodgeGlobalCooldown = 0.9f;

    [Header("AI")]
    public float thinkHz = 10f;
    public float arenaEdgeBias = 2.0f;

    [Header("Camera")]
    public float bigActionFovKick = 0.08f;
  }
}
