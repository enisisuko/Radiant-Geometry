using UnityEngine;

namespace FD.Bosses.C3.Data {
  public enum OrbMotion { Idle, Gather, Spread, Spin, Lift, Drop, Pulse, Jump, StretchLine, DetachPair, Triangle, HexFlower }

  [System.Serializable]
  public struct OrbKeyframe {
    public float t;
    public int[] orbs;
    public OrbMotion motion;
    public float radius;
    public float angleOffset;
    public float duration;
    public Color color;
    [Range(0f,1f)] public float brightness;
    public bool lockFormation;
    public string note;
  }

  [CreateAssetMenu(menuName = "FD/Bosses/C3/OrbPattern", fileName = "C3_Orb_")]
  public class OrbPatternData : ScriptableObject {
    public bool phase2SixOrbs = false;
    public OrbKeyframe[] keyframes;
  }
}
