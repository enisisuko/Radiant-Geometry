namespace FD.Bosses.C3.Data {
  public enum BossColor { Red, Green }
  public enum BossPhase { P1, P2 }
  public enum HitboxType { Capsule, Circle, Box, Ray }
}
