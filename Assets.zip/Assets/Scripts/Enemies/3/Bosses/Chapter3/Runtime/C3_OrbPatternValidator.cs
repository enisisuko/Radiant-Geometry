﻿#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using FD.Bosses.C3.Data;

public static class C3_OrbPatternValidator
{
    [MenuItem("FD/Boss/Validate Tell Patterns (lockFormation)")]
    public static void ValidateTellLock()
    {
        string[] guids = AssetDatabase.FindAssets("t:FD.Bosses.C3.Data.BossActionData");
        int ok = 0, bad = 0;
        var lines = new List<string>();

        foreach (var g in guids)
        {
            var path = AssetDatabase.GUIDToAssetPath(g);
            var data = AssetDatabase.LoadAssetAtPath<BossActionData>(path);
            if (!data) continue;

            var p = data.orbPattern;
            if (!p || p.keyframes == null || p.keyframes.Length == 0)
            {
                bad++;
                lines.Add($"✖ {data.actionId} {data.displayName} — TELL pattern MISSING or EMPTY");
                continue;
            }

            bool locked = p.keyframes[0].lockFormation;
            if (!locked)
            {
                bad++;
                lines.Add($"✖ {data.actionId} {data.displayName} — first keyframe lockFormation = FALSE");
            }
            else
            {
                ok++;
            }
        }

        Debug.Log($"[C3][Orbs] Tell lockFormation check — OK:{ok}  BAD:{bad}\n" + string.Join("\n", lines));
        if (bad > 0)
            EditorUtility.DisplayDialog("Tell 验证结果", $"OK:{ok}  BAD:{bad}\n详见 Console。", "OK");
    }
}
#endif
