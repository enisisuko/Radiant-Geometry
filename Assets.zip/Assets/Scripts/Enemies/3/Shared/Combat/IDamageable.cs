using UnityEngine;

namespace FD.Shared.Combat {
    public interface IDamageable {
        void TakeDamage(float amount);
        bool IsDead { get; }
    }
}
